# Step 3 release ZIP — v0.4, apply-ready

## Scope
This is the user-approved five-part revision of the v0.3 packaging candidate. Further Claude review was waived by the user for this bounded change.

The single .github/workflows/prove-project-build-windows-x64.yml workflow is the ONLY production file to replace.

- ZIP root contains exactly `Mpeg2BlockInspector.exe`, `mpeg2Deblock.dll`, `LICENSE`, `NOTICE.md`.
- EXE and DLL come from the retained CI proof artifact's `Release_Binaries` directory.
- LICENSE and NOTICE.md come directly from the checked-out repository root (`GITHUB_WORKSPACE`).
- Each input must exist and be nonempty. After compression, every ZIP entry is verified by unpacked SHA-256 against its own source file.
- `System.IO.Compression.FileSystem` is loaded before `ZipFile.OpenRead`.
- Header, step title and PASS messages refer to all four files.

## What remains unchanged
The single job, manual any-branch trigger, formal Release main-ancestry guard, only-on-Release attachment, all 256 switch token verification, eight HostX64 groups, both Release PE/security checks, and PDB retention. No production source/project edits or CSV edits.

## Apply
The currently installed workflow was Step 3 v0.2; the v0.3 packaging update was only a review candidate. Therefore the package includes `BASELINE_STEP3_v0_2_INSTALLED_REVIEW_ONLY.yml` for an exact-byte comparison before copying v0.4. Do not copy either baseline, the diffs, validation notes, or manifest to the repository. Stage only `.github/workflows/prove-project-build-windows-x64.yml`.

## Tests and acceptance
Offline YAML/structure/hash test results are in OFFLINE_VALIDATION.txt. Windows PowerShell runtime and actual GitHub Actions run are **not** verified by these offline checks. Run manually from main first; if that succeeds, test published GitHub Release only by user decision. No new Release was created.
