# Stage B+ Step 4 CI proving candidate v0.1 — for Claude independent review

**Not yet ratified. Do not copy into production or dispatch a workflow.**

Baseline: repository main commit `40fb6dd` (Stage B+ local-gate snapshot). The
Step 1 proving workflow and historical A3 expected CSV were already committed
before this snapshot. The included previous workflow copy comes from the
Step 1 accepted application package; it is review-only, not a deploy file.
Current GitHub raw workflow at `40fb6dd` was inspected to verify the active
checker shape and 113-token A3 reference. Before applying, verify the actual
Git blob against the supplied preimage SHA-256 below.

## Only TWO files to deploy AFTER Claude review and Dave ratification

1. `.github/workflows/prove-project-build-windows-x64.yml` (replace).
2. `.github/workflows/expected_stage_bplus_switches.csv` (new).

Do not change/remove `.github/workflows/expected_a3_v0_10_switches.csv`.
Do not add `CHECKER_FOR_CLAUDE_REVIEW_ONLY.py`, diff, README or any manifest to
`.github/workflows/`: checker is embedded in the workflow as before.

## Candidate commitments

- Manual `workflow_dispatch` on `main` only; zero on-push/release triggers.
- Builds solution Debug and Release x64, BOTH inspector EXE and plugin DLL.
- Exact expected switches: **256** token rows over ten keys: inspector CL/LINK
  117 (vs original A3 113 plus four EHCONT); DLL CL/LINK/RC 139.
- Preserve Windows `CommandLineToArgvW` parsing and strict native command tlogs;
  ensure ten distinct traces, stable per-source CL command settings; accept only
  expected argument kinds, including DLL resource object on LINK and RC source.
- Match tokens using the same existing case policy: LINK case-insensitive;
  other tools case-sensitive. A **missing or extra token is fatal**.
- Retain `/D _WINDLL` and `/TLBID:1` in measured CSV, accepted as
  **toolchain-inherited** by Claude 2026-10-11; never silently omit them.
- Require actual diagnostic compiler AND linker invocations for each of the
  two projects and both configurations (eight positive project/tool/config
  groups). Enforce x64 HostX64 paths under selected VS installation.
- Retain 64-bit MSBuild runtime, no environment override, no injected flags;
  toolset guard is still enforced by each project's own project XML.
- Inspect BOTH Release binaries for x64, ASLR/DEP/CET/CFG, EHCONT positive
  tables/count, KERNEL32-only imports, basename-only PDB and manifests.
  DLL additionally: one `VapourSynthPluginInit2` export and VERSIONINFO.
- Retain automatic evidence capture after failures.
- **Do not run six-index regression in CI**: O7 reserves it for Dave's
  local Windows environment. These passed locally for Stage B+.
- Retain the historical A3 CSV unchanged for audits.

## Evidence & review files (NOT to deploy)

- `CHECKER_FOR_CLAUDE_REVIEW_ONLY.py`: verbatim Python extracted from YAML;
  permits independent static inspection, but workflow version prevails.
- `PREVIOUS_PROVING_WORKFLOW_STEP1_FOR_REVIEW_ONLY.yml`: accepted Step 1 preimage.
- `WORKFLOW_CHANGE_REVIEW.diff`: plain text workflow changes.
- `PACKAGE_SHA256.txt`: package content hash inventory.
- `StageBPlus_GateC_Measured_Switches.csv` is the source of all 256 rows;
  candidate new CSV preserves these 256 tokens and ordinals verbatim,
  adding a `disposition` column to mark the four inherited DLL rows.

## Local preparation validation performed

- New workflow parsed with YAML 1.2, manual dispatch verified.
- Embedded Python successfully compiled with Python 3 on Linux.
- Expected CSV validated: 256 contiguous ordinal rows and ten exact keys.
- Original A3 CSV remains entirely untouched.
- **Not Windows CI-tested yet**; CI host invocation and Release checks need
  validation on the hosted runner after reviewed candidate application.

Preimage SHA-256 (`.github/workflows/prove-project-build-windows-x64.yml`):
`8388a445d12e30e0b564f48ff20720e882d75a161eb14f9e75f4c3b15bd2646f`

### Review questions for Claude

1. Does ten-key tlog discovery remain robust across hosted runner project
   intermediate path variation (`Mpeg2Blo.*` and `mpeg2Deblock`)?
2. Does the HostX64 diagnostic line classifier positively establish BOTH
   projects in both configurations without false positives?
3. Is the extended binary validation correctly scoped; is any requirement
   too strict for valid CI output (especially DLL manifest and PDB regex)?
4. Is the existing G5/G7 strictness retained, including B6 inherited settings?
5. Any concerns about this candidate relative to Stage B+ O1-O7 and K1/K2?

**No production project modifications; no Git or GitHub actions performed.**
