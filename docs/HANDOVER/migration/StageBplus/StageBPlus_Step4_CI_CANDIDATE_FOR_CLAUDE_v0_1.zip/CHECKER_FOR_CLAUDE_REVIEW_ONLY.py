import collections, csv, ctypes, os, pathlib, re, struct, sys
# The entire checker remains embedded in this ONE workflow. No independent
# flag map, checker copy or injected CL/LINK/RC options are maintained.
if os.name != 'nt' or struct.calcsize('P') != 8:
    raise SystemExit('FAIL: requires 64-bit Windows Python (N1)')
from ctypes import wintypes
shell32 = ctypes.WinDLL('shell32', use_last_error=True)
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
shell32.CommandLineToArgvW.argtypes = (wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int))
shell32.CommandLineToArgvW.restype = ctypes.POINTER(wintypes.LPWSTR)
kernel32.LocalFree.argtypes = (ctypes.c_void_p,)
kernel32.LocalFree.restype = ctypes.c_void_p

def win_split(line):
    n = ctypes.c_int()
    p = shell32.CommandLineToArgvW(line, ctypes.byref(n))
    if not p: raise OSError(ctypes.get_last_error(), 'CommandLineToArgvW')
    try: return [p[i] for i in range(n.value)]
    finally: kernel32.LocalFree(ctypes.cast(p, ctypes.c_void_p))

root = pathlib.Path(os.environ['GITHUB_WORKSPACE'])
ev = pathlib.Path(os.environ['EVIDENCE_DIR'])
expected = root / '.github/workflows/expected_stage_bplus_switches.csv'
if not expected.is_file(): raise SystemExit('FAIL: Stage B+ expected-switch CSV missing')

expected_counts = {
    ('INSPECTOR','Debug','CL'):34, ('INSPECTOR','Debug','LINK'):24,
    ('INSPECTOR','Release','CL'):33, ('INSPECTOR','Release','LINK'):26,
    ('DLL','Debug','CL'):42, ('DLL','Debug','LINK'):23,
    ('DLL','Debug','RC'):4, ('DLL','Release','CL'):41,
    ('DLL','Release','LINK'):25, ('DLL','Release','RC'):4,
}

def load_expected(path):
    out = collections.defaultdict(list)
    with path.open(encoding='utf-8-sig',newline='') as f:
        rd = csv.DictReader(f)
        if rd.fieldnames != ['project','configuration','tool','ordinal','token','disposition']:
            raise SystemExit(f'FAIL: unexpected expected-switch CSV schema: {rd.fieldnames!r}')
        for row in rd:
            key = (row['project'],row['configuration'],row['tool'])
            if not row['token'] or not row['ordinal'].isdigit():
                raise SystemExit(f'FAIL: incomplete expected-switch row: {row!r}')
            inherited = key[0]=='DLL' and row['token'] in ('/D _WINDLL','/TLBID:1')
            expected_disposition = 'toolchain-inherited, accepted 2026-10-11' if inherited else ''
            if row['disposition'] != expected_disposition:
                raise SystemExit(f'FAIL: unexpected inherited/default switch annotation: {row!r}')
            if int(row['ordinal']) != len(out[key])+1:
                raise SystemExit(f'FAIL: duplicate/misordered CSV ordinal: {row!r}')
            out[key].append(row['token'])
    if {k:len(v) for k,v in out.items()} != expected_counts:
        raise SystemExit('FAIL: wrong expected-switch key/count inventory (must be exactly 256 rows)')
    return out

baseline = load_expected(expected)
base = root / 'vs/VapourSynth-mpeg2Deblock'
tool_files = {'CL':'CL.command.1.tlog','LINK':'link.command.1.tlog','RC':'rc.command.1.tlog'}

def project_for_trace(path):
    rel = path.relative_to(base).parts
    if len(rel) < 5: raise SystemExit(f'FAIL: malformed tlog path: {path}')
    top = rel[0].lower()
    if top == 'mpeg2deblock': return 'DLL'
    if top.startswith('mpeg2blo.'): return 'INSPECTOR'
    raise SystemExit(f'FAIL: unknown project tlog directory: {path}')

paths = collections.defaultdict(list)
for tool, filename in tool_files.items():
    for p in base.rglob(filename):
        project = project_for_trace(p)
        rel = p.relative_to(base).parts
        cfgs = [cfg for cfg in ('Debug','Release') if cfg.lower() in [part.lower() for part in rel]]
        if len(cfgs) != 1 or 'x64' not in [part.lower() for part in rel]:
            raise SystemExit(f'FAIL: incorrect x64/configuration path: {p}')
        key = (project,cfgs[0],tool)
        if key not in expected_counts: raise SystemExit(f'FAIL: extra/unexpected trace: {p}')
        paths[key].append(p)
if {k:len(v) for k,v in paths.items()} != {k:1 for k in expected_counts}:
    raise SystemExit(f'FAIL: expected exactly ten CL/LINK/RC traces; found {dict(paths)!r}')

# Native MSBuild tlog command lines, with the original Windows quoting rules.
def normalize_arg(arg,tool):
    up=arg.upper()
    if up.startswith(('/FO','/FD')): return arg[:3]+'<PATH>'
    for prefix in ('/OUT:','/PDB:','/IMPLIB:','/MANIFESTINPUT:'):
        if up.startswith(prefix): return arg[:len(prefix)]+'<PATH>'
    if tool=='CL' and up.startswith('/I'): return arg[:2]+'<PATH>'
    return arg

def parse_command(line, tool, key):
    argv=win_split(line)
    got=[]; libs=[]; sources=[]
    i=0
    while i<len(argv):
        a=argv[i]; up=a.upper()
        if tool in ('CL','RC') and up=='/D':
            if i+1>=len(argv): raise SystemExit(f'FAIL: malformed /D: {key}')
            got.append(a+' '+argv[i+1]); i+=2; continue
        if a.startswith('/'):
            got.append(normalize_arg(a,tool))
        elif tool=='LINK' and up.endswith('.LIB'):
            libs.append(a)
        elif ((tool=='LINK' and up.endswith(('.OBJ','.RES'))) or
              (tool=='CL' and up.endswith(('.C','.CPP','.CC'))) or
              (tool=='RC' and up.endswith('.RC'))):
            sources.append(a)
        else:
            raise SystemExit(f'FAIL: unclassified {key} argument: {a!r}')
        i+=1
    if not sources: raise SystemExit(f'FAIL: no {key} source/object/resource')
    if tool=='LINK':
        if not libs: raise SystemExit(f'FAIL: {key} missing libraries')
        if key[0]=='DLL' and not any(x.upper().endswith('.RES') for x in sources):
            raise SystemExit(f'FAIL: DLL linker missing VERSIONINFO resource object: {key}')
        pos=next((i for i,v in enumerate(got) if v.lower()=='/nologo'),None)
        if pos is None: raise SystemExit(f'FAIL: {key} missing /NOLOGO')
        got.insert(pos+1,'LIBS='+';'.join(libs).lower())
    return got

actual={}
for key in expected_counts:
    p=paths[key][0]
    (ev / ('_'.join(key)+'_'+p.name)).write_bytes(p.read_bytes())
    lines=p.read_text(encoding='utf-16').splitlines()
    commands=[l for l in lines if l and not l.startswith('^')]
    if not commands: raise SystemExit(f'FAIL: no commands for {key}')
    tool=key[2]
    parsed=[parse_command(c,tool,key) for c in (commands if tool=='CL' else commands[:1])]
    first=parsed[0]
    if tool=='CL' and any(record!=first for record in parsed[1:]):
        raise SystemExit(f'FAIL: inconsistent source CL commands for {key}')
    if tool=='RC' and len(commands)!=1:
        raise SystemExit(f'FAIL: expected exactly one RC command for {key}')
    actual[key]=first

with (ev/'actual_stage_bplus_switches.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.writer(f); w.writerow(('project','configuration','tool','ordinal','token'))
    for key in sorted(actual):
        for ordinal,token in enumerate(actual[key],1): w.writerow((*key,ordinal,token))
failures=[]
for key in sorted(expected_counts):
    tool=key[2]
    canon=(lambda t:t.lower()) if tool=='LINK' else (lambda t:t)
    want=collections.Counter(map(canon,baseline[key]))
    got=collections.Counter(map(canon,actual[key]))
    for kind,diff in (('MISSING',want-got),('EXTRA',got-want)):
        for token,count in sorted(diff.items()):
            failures.append(f'{key} {kind} {token} (x{count})')
    if not (want-got) and not (got-want):
        print(f'PASS: {key} {sum(got.values())} reviewed switches')

# K2: Positive host-architecture proof for BOTH CL and LINK on BOTH projects,
# in BOTH configurations. Diagnostic INVOCATIONS, not property declarations.
invocation_pattern=re.compile(
    r'(?im)^\s*(?:\d+>\s*)?([A-Z]:\\[^\r\n]*?\\bin\\Host(?:X64|X86)\\(?:x64|x86)\\(?:CL|link)\.exe)\s+([^\r\n]+)\r?$')
for cfg in ('Debug','Release'):
    log=(ev/f'MSBuild_{cfg}_x64_diagnostic.log').read_text(encoding='utf-8-sig',errors='replace')
    matches=invocation_pattern.findall(log)
    inv=collections.defaultdict(list)
    for path,command in matches:
        tool='CL' if path.lower().endswith('\\cl.exe') else 'LINK'
        payload=command.lower()
        if tool=='CL':
            inspector=('\\src\\mpeg2blockinspector\\' in payload)
            plugin=('\\src\\mpeg2deblock\\plugin.cpp' in payload)
        else:
            inspector=bool(re.search(r'/out:\s*"?[^\s"]*mpeg2blockinspector\.exe',payload))
            plugin=bool(re.search(r'/out:\s*"?[^\s"]*mpeg2deblock\.dll',payload))
        if inspector==plugin:
            failures.append(f'{cfg}: unclassified/ambiguous {tool} invocation: {command[:160]}')
            continue
        project='INSPECTOR' if inspector else 'DLL'
        inv[(project,tool)].append(path)
        if not re.search(r'(?i)\\bin\\HostX64\\x64\\(?:CL|link)\.exe$',path):
            failures.append(f'{cfg}/{project}/{tool}: not HostX64\\x64: {path}')
        if not path.lower().startswith(os.environ['VS_INSTALL'].lower().rstrip('\\')+'\\'):
            failures.append(f'{cfg}/{project}/{tool}: outside selected VS: {path}')
    for project in ('INSPECTOR','DLL'):
        for tool in ('CL','LINK'):
            key=(project,tool)
            if not inv[key]: failures.append(f'{cfg}/{project}/{tool}: actual host tool invocation missing')
            print(f'{cfg}/{project}/{tool}: {len(inv[key])} real diagnostic invocation(s)')

for item in failures: print('FAIL:',item)
if failures: raise SystemExit(1)
print('PASS: all 256 CL/LINK/RC switches and all eight HostX64 project/tool/config groups')
