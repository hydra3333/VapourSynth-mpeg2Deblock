# Stage B+ migration Step 3 - release-workflow candidate v0.1

**Status:** DRAFT FOR CLAUDE INDEPENDENT CANDIDATE REVIEW; NOT APPLIED.
**Date:** 2026-10-11
**Author:** ChatGPT migration chat
**Basis:** GitHub Actions Step 4 successfully proven workflow at commit `3ccfa182c295bcade7ddacf653d6db218c3f2172`, CI run `38092449456`, and ratified `Migration_Status.md` v0.6.
**Review policy:** ChatGPT drafts; Claude independently reviews; Dave ratifies before application and manual CI test. No project/source changes.

## Production delta

Exactly ONE production file changes:
`.github/workflows/prove-project-build-windows-x64.yml`.

The reviewed `.github/workflows/expected_stage_bplus_switches.csv` remains **byte-for-byte unchanged** (256 tokens, ten groups). The historical A3 CSV stays unchanged. The production project files, G5 tool ownership and O7 six-local-index rule are unchanged.

## Changes (all start from proven Step 4 workflow)

1. Keep `workflow_dispatch` on main and add `release: types: [published]`; validate ref/event and checkout SHA. Published release events target a tag, not `refs/heads/main`, so the Step 4 manual-only guard is now event-aware.
2. S6: `actions/checkout@v7` and `actions/upload-artifact@v7`, both Node 24 majors. The published Step 4 run used runner version 2.337.0; official action minimum for Node24 is 2.327.1. Do not pin `runs-on: windows-latest` to a toolchain release.
3. G5/G7: retain the EXACT ten-key inventory. Read per-key expected switch counts from the unchanged CSV; accept only blank or the already-reviewed B6 disposition string. Remove executable checker copies of `'/D _WINDLL'`, `'/TLBID:1'` and fixed per-key counts. The total 256 now comes from the CSV, not code. Switch differences still FAIL and print missing/extra; LINK remains case-insensitive. CSV is authoritative.
4. G7: insert a COMMENT-ONLY, NON-EXECUTING reference containing all ten local Stage B+ normalized CL/LINK/RC command lines, plus dated local and successful CI toolchain versions. It is generated from the reviewed CSV and exactly token-identical to it. The reference is NOT runnable and NOT another build route; `<PATH>`, `LIBS=` and `[inputs]` are placeholders. A legitimate switch change updates the CSV and this reference in ONE reviewed commit.
5. S4: preserve `Mpeg2BlockInspector.exe`, `Mpeg2BlockInspector.pdb`, `mpeg2Deblock.dll` and `mpeg2Deblock.pdb` under `Release_Binaries/` in the always-uploaded diagnostic artifact. Create `release_binary_hashes.txt` with size and SHA-256 for each available file. Binary collection runs even after an earlier step fails; release publication does not.
6. G4/G8 release attachment: after successful strict checks and artifact upload, published-Release events only attach all four binary/symbol files using GitHub CLI `gh release upload`. The release ID/tag/ref are cross-checked; files must be present and nonempty. No `--clobber`: if a Release already contains any named assets, the upload fails instead of silently overwriting them. Grant `contents: write` for this release-upload capability while retaining `persist-credentials: false` in checkout. Manual runs do not attach release assets.
7. Rename PowerShell `$matches` (automatic variable name) to `$versionDefines`; remove 13 pre-existing whitespace-only lines, so `git diff --check` should pass.

## Preserved protections

- Use newest installed RELEASED VS via vswhere; x64 MSBuild; no auto-response files, environment/ancestor overrides, or VsDevCmd contamination during build.
- `.slnx` builds Debug and Release x64, exact project-owned CL/LINK/RC settings, Windows CommandLineToArgvW tokenization, all eight HostX64 CL/LINK invocation groups.
- Release PE/x64/AVX2-related compiler settings, CFG/EHCONT, LAA, CET, NX, HEVA, KERNEL32-only imports, manifests, one unmangled plugin export and canonical VERSIONINFO from `plugin_version.h`.
- Only LOCAL six-index regression tests under O7. Do not assert that CI-built binaries are byte-identical to locally tested binaries; SDK difference 10.0.26100.0 vs 10.0.28000.0 is recorded, not normalized away.
- No wheels or PyPI work.

## Offline validation (see STATIC_VALIDATION.txt)

- ASCII with CRLF, no trailing whitespace; YAML parsing and embedded Python AST parsing.
- The CSV-driven loader parsed the unchanged ten-key 256-token expected CSV, and its results matched the actual 256-token CI proof artifact by key and token (LINK case-insensitive).
- All ten G7 comment switch references exactly equal the approved CSV.
- Negative cases (unknown expected key, duplicate ordinal, unapproved disposition) correctly fail.
- Release attachment paths and guard logic inspected statically. **A release.published event and the new GitHub CLI upload have NOT been exercised on the actual runner**. Nor have the new Node24 action majors been executed under this candidate.

## Caveats / proposed Step 3 gate

- A MANUAL proving run on `main` should be done first. It will prove the new action majors, both builds, strict switches, HostX64, binary evidence upload including 4 new files, and no accidental release attachment.
- A real `release.published` test is a separate publishing action with externally visible release effects, potentially creating a public Release before binary verification finishes. It requires Dave's explicit authorization and planning. Merely passing a manual run does NOT establish that release attachment worked.
- `contents: write` is job-wide because this is the agreed single-job self-contained workflow. `GITHUB_TOKEN` is not persisted by checkout and is only passed as `GH_TOKEN` to the publication step. Claude should assess this tradeoff.
- GitHub CLI is expected on the runner, but the release-only step is not validated by the manual test. Duplicate names deliberately cause failure; we do not delete or replace published assets.
- The published release may point to an older tag commit; checkout is pinned to `github.sha` for the actual triggering commit. Existing strict CSV checks can fail on historical project configurations; this is fail-closed behavior, not binary compatibility evidence.

## Questions for Claude

1. Is this a suitably limited, correct Step 3 delta from the proven Step 4 workflow, particularly the event/ref/checkout SHA logic?
2. Do the Node24 action upgrades and job-scoped `contents: write` meet S6/security expectations? Do you want a two-job permissions split, despite G3's one-workflow simplicity?
3. Are the G7 normalized comment references sufficiently faithful to the ratified record, without becoming a competing build route?
4. Is removing the hard-coded per-key counts/B6 tokens from executable checker correct and strict enough? Is the CSV disposition whitelist adequate?
5. Does collecting 4 Release binary/PDB files and attaching 4 files on `release.published` correctly satisfy S4 and G4, with intentional failure on duplicate asset names?
6. What explicit real-release (potentially public) test is required for Step 3 final acceptance, distinct from the ordinary manual proof run?

## Package contents

- `prove-project-build-windows-x64.yml` - the ONE proposed production file, to replace the file of the same name in `.github/workflows/` ONLY AFTER ratification.
- `BASELINE_STEP4_PROVING_WORKFLOW_REVIEW_ONLY.yml` - the accepted preimage for independent diff verification.
- `REFERENCE_ONLY_expected_stage_bplus_switches.csv` - unchanged reference, NOT a production replacement.
- `STEP3_v0_1_CHANGE.diff` - complete focused preimage-to-candidate diff.
- `STATIC_VALIDATION.txt` - offline test results and explicitly untested boundaries.
- `README_FOR_CLAUDE_REVIEW.md` - this file.
- `PACKAGE_SHA256.txt` - SHA inventory of the six above, excluding itself.

**Do not apply, commit, trigger a Release, or modify project files before Claude review and Dave ratification.**
