# Step 3 distribution packaging revision v0.3 — independent review requested

## Why
Dave expected GitHub Release to display **one downloadable Windows x64 ZIP with only `Mpeg2BlockInspector.exe` and `mpeg2Deblock.dll`**, rather than four individually attached binaries/PDBs. The PDBs remain in the Actions proof artifact. GitHub adds the source ZIP and tar.gz automatically and those are not our upload assets.

## Proven preimage
`STEP3_v0_2_REVIEWED_PREIMAGE.yml` is byte-for-byte the Claude-approved one-job Step 3 v0.2 workflow deployed at `0c9bf90`. Existing trigger guard, any-branch manual policy, Release main ancestry check, exact 256-token verification, HostX64 checks, PE/security checks, compiler/linker discovery, R1 one-job `contents:write` decision, and Debug/Release builds are unchanged.

## Proposed changes
1. Add one `success()`-gated packaging step after S4 preservation and before evidence upload. It builds `mpeg2Deblock-<tag>-win-x64.zip` for published Releases, and `mpeg2Deblock-manual-<shortsha>-win-x64.zip` inside Actions evidence for manual runs; tag/identifier characters outside `[A-Za-z0-9._-]` are replaced with underscore.
2. Both EXE and DLL must exist and be nonempty. Open ZIP with .NET ZipFile, enforce exactly two root member names, hash decompressed member contents against actual verified build outputs, and record ZIP SHA-256 and size in `release_distribution_zip_sha256.txt`. The ZIP itself and this manifest reside in Actions proof evidence.
3. Published-Release attach step checks current GitHub Release identity as before, verifies ZIP against manifest, and uploads **one ZIP only** using `gh release upload` (no `--clobber`). Manual runs cannot execute attach.
4. PDBs remain in the proof artifact, never in the distribution ZIP. The existing individual binary/PDB hash manifest is unchanged.

## Review questions
- Verify PowerShell 7 `Compress-Archive -LiteralPath $inputs` supports two path strings on windows-latest and produces exactly the two root names; the runtime archive member audit should fail if not.
- Verify SHA256 zip-entry stream logic, resource disposal, and `Compare-Object` semantics.
- Verify failure behavior: no ZIP or no release attach on any build/proof/package failure, while existing proof evidence always uploads.
- Verify tag sanitisation and naming; no second packaging path or build-options injection.
- Should `release_distribution_zip_sha256.txt` also be a public second Release asset, or stay in Actions evidence? Candidate keeps it ONLY in Actions evidence to satisfy Dave's preference for a single user-facing ZIP.

## Test gate after approval
Manual run on main (plus optional another branch) must PASS, and Actions proof ZIP must include Release_Package ZIP, hash manifest, and 4 separate internal binary/PDB files. A newly published test pre-release must PASS, upload exactly one user-facing ZIP, and display the ZIP SHA-256; both decompressed bytes must match the Release-run's manifest. Existing GitHub auto source links remain. Previous `TESTONLYTOBEDELETED` release already includes four individual attachments and is not mutated by this candidate. Deletion, if desired, remains Dave's decision.

## Scope
Only `.github/workflows/prove-project-build-windows-x64.yml` changes upon application. **DO NOT** apply before Claude review / Dave ratification. Do not copy the reference/preimage/diff/manifest into the repository. No source, .vcxproj, .slnx, expected CSV, tag, or Release modifications.
