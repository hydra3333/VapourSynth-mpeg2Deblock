# Stage B+ applyable project candidate - v0.2 (for Claude diff review only)

**Date:** 2026-10-10
**Status:** DRAFT / NOT RATIFIED / NOT APPLIED / NOT BUILT.
**Authority:** Dave decides, Claude independently reviews, ChatGPT prepares.
**Source base:** the exact accepted Stage A3 v0.10 inspector and x64 solution, verified against Dave's SHA-256 identities after Windows CRLF normalisation.

## Scope

Four project/solution files and three new plugin scaffolding files, delivered FLAT (no nested ZIP). The new DLL has exactly one passthrough VapourSynth API4 function (`Identity`) with no frame processing. It is not Stage 2 technical implementation. O1-O7 dispositions are from living Migration_Status v0.5. No existing inspector C/H source or analyzer changes.

| Candidate file in this archive | Intended location in REPO (only after ratification) |
|---|---|
| `Mpeg2BlockInspector.vcxproj` | `vs\VapourSynth-mpeg2Deblock\Mpeg2BlockInspector.vcxproj` |
| `mpeg2Deblock.vcxproj` | `vs\VapourSynth-mpeg2Deblock\mpeg2Deblock.vcxproj` |
| `mpeg2Deblock.vcxproj.filters` | `vs\VapourSynth-mpeg2Deblock\mpeg2Deblock.vcxproj.filters` |
| `VapourSynth-mpeg2Deblock.slnx` | `vs\VapourSynth-mpeg2Deblock\VapourSynth-mpeg2Deblock.slnx` |
| `plugin.cpp`, `plugin_version.h`, `mpeg2Deblock.rc` | `src\mpeg2Deblock\` |

## Intended build changes

1. Inspector: two `PlatformToolset=v145` settings become `$(DefaultPlatformToolset)` (Debug+Release). Add a numeric MSBuild minimum v145 gate; use proposed MSBuild `VersionLessThan` with a leading v (UNVERIFIED until local scratch test). Enable `/guard:ehcont` in BOTH configurations via the native VS2026 `GuardEHContMetadata` (ClCompile) and `LinkGuardEHContMetadata` (conditioned PropertyGroup) properties, not AdditionalOptions. Preserve all other accepted flags.
2. DLL: copied from accepted inspector pin set; pin explicit Debug/Release preprocessor definitions (NOMINMAX, _DEBUG/NDEBUG, _WINDOWS, _USRDLL), native C++ RTTI (RuntimeTypeInfo=true), switch to C++20 DynamicLibrary; `/permissive-` (`ConformanceMode`), `/sdl` ON, no `_CRT_SECURE_NO_WARNINGS`; x64 AVX2, `/favor:blend`, Debug `/MDd`, Release `/MT`, `/GS`, CFG, CET, EHCONT, `/LARGEADDRESSAWARE`, `/fp:precise` without automatic FMA contraction. Pin DLL Windows subsystem and `EnableUAC=false` (no EXE asInvoker request); omit EXE-only SegmentHeap. DLL imports and export must be checked on Windows.
3. Version: `plugin_version.h` is the ONE authority for number fields, resource `mpeg2Deblock.rc` and C++ source include that header. Version `0.1.0.0` is **provisional scaffold version**; no public numbering policy or PyPI publication is implied. Both the VERSIONINFO numeric value and formatted version string derive automatically from the four version-number macros in the same header; no manually repeated version literal exists.
4. API: plugin name set per Dave O1; exports `VapourSynthPluginInit2`, registers `Identity(clip:vnode)->clip:vnode`. `Identity` only transfers a `VSNode` reference using VapourSynth's API functions. Header source is the **already vendored VapourSynth R78** under `third_party\vapoursynth\include`; no new API headers shipped or altered.
5. DLL ResourceCompile: Debug `_DEBUG` / Release `NDEBUG`, `Culture=0x0409`, and `SuppressStartupBanner=true`; the RC file is compiled into the DLL and is not separately distributed.
6. `.slnx`: registers second project. Same x64-only configuration. No separate DLL wheel, CPU-dispatch modules, or technical experimentation.

## REQUIRED Windows evidence BEFORE Gate acceptance

**These checks have NOT BEEN RUN by ChatGPT (no Visual Studio or VapourSynth runtime in the current environment).** Candidate is for Claude's *design/source review* first. Do not represent XML-parsing PASS as an MSBuild build PASS.

A. First independently verify `DefaultPlatformToolset` resolves to VS2026's current installed value in both project configurations **after** `Microsoft.Cpp.Default.props`. Validate the `v145` numeric guard with actual `v145`, a lower test value (in a disposable scratch copy), and the observed Visual Studio current value. This is a project setting candidate, **NOT yet locally proved**, notwithstanding external documentation supporting the mechanism. If it does not resolve before imports or the numeric guard does not execute in VS GUI, repair candidate BEFORE production application. Never silently fall back to v145 when undefined.

B. Verify the native VS2026 `GuardEHContMetadata=true` ClCompile and `LinkGuardEHContMetadata=true` conditioned PropertyGroup settings are recognised in Property Pages AND emit `/guard:ehcont` on both actual CL and LINK invocations in Debug and Release. Note legacy C Debug `/Gy-`; Microsoft documents possible LNK4291 with conservative EH metadata from CRT objects. Record any linker warnings without `/IGNORE`. Check `dumpbin /loadconfig` for an EH Continuation table and count for BOTH inspector EXE and DLL (count may legitimately be zero). New Guard Flags may differ from A3. Do not claim protection if metadata is absent.

C. Compile inspector and DLL through VS2026 GUI (`Debug|x64` and `Release|x64`). Compare inspector deltas with A3 (only toolset and native EHCONT); independently capture and reconcile the DLL CL, LINK AND RC effective switches, including `rc.command.1.tlog`. Audit all C++ CL/LINK tokens (including `/GR`, `/EHsc`, `/Zc:*`, `/std:c++20`, modules/scanning switches) against pins or explicitly accepted toolchain outputs. The 113-token A3 CSV stays immutable history. Do not manufacture new expected CSVs before actual local measurement. Update active CI baselines only from measured, reviewed outputs; project files own every executed flag.

D. Inspect actual HostX64 CL/link, warning signatures, Release inspector `KERNEL32.dll` imports, DLL release imports (no dynamic VC/UCRT dependency under `/MT`), x64, /GS, CFG, CET, LAA, ASLR, NX, PDB basename, segment heap **EXE only**; verify API4 export `VapourSynthPluginInit2`. Check `VERSIONINFO` in actual DLL, and extract/inspect its embedded manifest to verify `/MANIFESTUAC:NO` and declared UAC behaviour; no additional distributed resource file.

E. With locally installed VapourSynth, load DLL in Python and invoke `core.mpeg2deblock.Identity(core.std.BlankClip())`; ensure an output frame is retrievable and the input clip remains valid. No algorithm work. The sample identity invocation is a staging gate, not a shipping API specification.

F. Run **all six** inspector index regressions **locally**, because inspector `.vcxproj` is edited, regardless of whether selected exact compiler happens to be unchanged. O7: no such testing in GitHub Actions. A3 v0.10 waiver remains WAIVED, not a PASS.

G. Existing manual-only GitHub proving workflow will need its two-project token logic/expected data amended and re-proved for the resulting Stage B+ inspector + DLL commands. This candidate DOES NOT modify the current YAML or expected CSV, because their correct values (including DLL RC switches) depend on locally measured actual switches. Stage 3 subsequently completes release-triggered one-file workflow and S4-S6; do not accidentally enable release triggers during B+.

## Disposition of Claude v0.1 review (B1-B6, Q1-Q2)

- **B1:** Replaced all EHCONT `AdditionalOptions` with native `GuardEHContMetadata=true` (within each ClCompile group) and `LinkGuardEHContMetadata=true` (in each conditioned PropertyGroup, NOT within Link) in both project files. The remaining `/favor:blend`, `/HIGHENTROPYVA` and Release `/PDBALTPATH` AdditionalOptions are unchanged.
- **B2:** Pinned DLL C/C++ Debug and Release preprocessor definitions exactly as Claude requested (with inherited definitions retained).
- **B3:** Pinned DLL `SubSystem=Windows` in both Link groups.
- **B4:** Pinned DLL `EnableUAC=false` in both Link groups; the DLL manifest still gets generated/embedded, subject to Windows verification.
- **B5:** Added conditioned ResourceCompile settings for RC definitions, culture, and suppression; actual RC tlogs must be captured for the gate.
- **B6:** Pinned DLL `RuntimeTypeInfo=true` in both configurations. Existing C++20, `ConformanceMode`, `ExceptionHandling=Sync` remain explicit; the Windows gate audits EVERY actual CL/LINK/RC token (no unsupported claim of complete C++ pin coverage before first build).
- **Q1 (Dave-ratified O2):** EHCONT ON for BOTH inspector and DLL. This is an explicit Dave decision, not an assumption drawn from Claude's earlier DLL-only recommendation.
- **Q2 (Dave-ratified O4):** `LargeAddressAware=true` explicitly ON for BOTH inspector and DLL in both configurations. This deliberately overrides Claude's earlier suggestion to omit the DLL setting.
- **N1:** `$(DefaultPlatformToolset)` means Visual Studio's designated DEFAULT toolset (minimum v145), not necessarily newest installed. This vocabulary clarification requires no additional project change.
- **N2:** The guard remains UNVERIFIED; scratch probe cases required: `v145` pass, `v143` fail, `v150` pass, `vX` fail, empty fail.
- **N3:** Observe LNK4291 or any EHCONT warnings; require EH continuation table evidence/count for both EXE and DLL. The count is allowed to be zero.
- **N4:** Do not modify active Step 1 GitHub workflow or CSV until measured local build data exists.
- **N5:** `VS_FF_DEBUG` file flags in Debug were optional/cosmetic and deliberately NOT added to keep the v0.2 changes limited to B1-B6.

**Status remains DRAFT / NOT APPLIED / NOT BUILD-VERIFIED.** Claude may review just the v0.1 -> v0.2 diff. The v0.2 candidate is not approved for production application until the independent review and Dave's ratification.

## Source/review caveats (candidates for Claude disposition)

- `PlatformToolset=$(DefaultPlatformToolset)` and `VersionLessThan('v###','v145')` are externally documented but **unverified in Dave's VS2026 GUI**. Note Microsoft documentation says selecting the current default toolset does not itself install updates. No explicit `VCToolsVersion` pin is added.
- `/guard:ehcont` may reveal C/C++ linker incompatibility; full build/gate results must distinguish support from mere switch presence. Dave chose to skip a separate O2 experimental campaign, **not** to label the mandatory Stage B+ acceptance regressions PASS if omitted.
- The plugin version has four numeric fields in its one header; its string is generated by macro stringification. `VS_MAKE_VERSION` supports major/minor only for VapourSynth configPlugin, so patch/build components intentionally do not appear there; version header remains canonical.
- `.vcxproj.filters` controls only Solution Explorer grouping, not build semantics. The previously accepted inspector `.filters` is UNCHANGED.
- Candidate exports API4 entrypoint via documented `VS_EXTERNAL_API`, but exact MSVC mangling/export spelling MUST be verified on Windows.
- C++ RTTI is now explicitly pinned ON (`RuntimeTypeInfo=true`), along with C++20, conformance and synchronous exceptions. The exact generated C++ and RC switches are still unverified pending actual VS2026 tlogs. The accepted baseline zip does not include the complete CNR3 `.vcxproj`; no 57-row CNR3 reconciliation claim is made.
- The original accepted inspector/solution SHA identities were verified from `VapourSynth-mpeg2Deblock-main.zip`, which predates the Step 1/Step 1 gate-document commits but includes the identical accepted project and solution. No assumption is made that the local repo currently has already installed this candidate.

## References

- Living Migration_Status.md v0.5; Claude_RESPONSE_TO_ChatGPT_Agreed_Remaining_Plan_v0_1.md (G2/G9/G10).
- Microsoft: https://learn.microsoft.com/en-us/cpp/build/reference/guard-enable-eh-continuation-metadata
- Microsoft: https://learn.microsoft.com/en-us/visualstudio/msbuild/property-functions
- VapourSynth API4: https://www.vapoursynth.com/doc/api/vapoursynth4.h.html
