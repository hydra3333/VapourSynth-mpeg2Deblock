# S2-I3 P0 Windows run - updated status, verified results, hygiene, and continuation (v0.2)

Date: 2026-10-17; P0 run STILL IN PROGRESS
Project: VapourSynth-mpeg2Deblock
Prepared by: ChatGPT for owner continuity and Claude independent evaluation
Status: OBSERVATIONAL HANDOVER - NOT THE S2-I3 EVIDENCE/GATE REPORT; NOT P1 AUTHORISATION
Supersedes: `S2_I3_P0_WINDOWS_RUN_STATUS_AND_RESULTS_v0_1_FOR_CLAUDE_2026-10-17.md` as an interim communication file
Verified by: Claude, 2026-10-17, independently against its own run records and a fresh GitHub check.
**No content change was required.** Every figure was confirmed correct: the eight index identities on
all four values, XP's 54 qualifying P pictures, the seven expected P-picture counts, the four pair
decisive counts, the BestSource DLL hash equality with the accepted S2-I2 evidence, the NumPy 2.5.3 to
2.5.4 difference, the 58-file / 181-to-239 / 158.8 MB snapshot audit, the two commit identities and
HEAD, and the Commit A/B/C paths with their expected staged shapes. Claude added only this
verification note and the storage guidance below.
Recommended storage: `docs/HANDOVER/`, as role continuity rather than repository authority. It is
transient: retire it under D-23 v1.2 once P0 completes and the S2-I3 Evidence and Gate Report exists.
Leaving it untracked is also defensible, since the two role handovers carry the durable content.

**TO CLAUDE / SUCCESSOR CHAT:** This v0.2 merges the owner's actual CMD results, Claude's independent v0.1 verification, and Claude's separately discovered URGENT repository hygiene findings. Neither ChatGPT nor Claude has inspected the COMPLETE final P0 `results/` evidence yet. The next Windows P0 operation is **XP_blocky admission**, not rerunning P0A, P0B or XP. The identity-carrier cleanup is a separate, time-sensitive path and does not block P0. This note must never be swept into the repository by a snapshot `git add -A` operation; storing it deliberately, by exact named path in its own bounded commit, is a different thing and is what the header recommends. Keep the two workstreams and their permissions separate.

## 1. Executive status - unambiguous checkpoint

| Work unit | Status, at last supplied console output | Evidence boundary |
|---|---|---|
| S2-I3 P0 implementation clearance | DONE, including S4 and isolated-Python corrective BAT | Claude cleared both, 0 MUST / 0 SHOULD |
| P0A scratch preparation | **PASS**, Windows ERRORLEVEL=0 | six frozen index regressions, negative cases, 9/9 + 5/5 tests, runtime preflight |
| P0B generation | **6 of 6 PASS** | six new indexes have reference-equal SHA-256 |
| P0B LP_blocky copy | **PASS** | verified source S2-I2 and destination bytes match |
| P0B LP original | **FROZEN BASELINE** | never regenerated; eighth index available in repository |
| P0C source admission | **XP REGISTERED, 1 of 8** | 1619/1619 P skips, 54 P pictures, 228 decoded frames, ERRORLEVEL=0 |
| P0C other seven | **NOT RUN** | begin with XP_blocky; expected P-picture counts in section 6 |
| P0D diagnostics | NOT RUN | eight source-level runs later |
| P0D pair correspondence | NOT RUN | four pair runs later |
| Global P0 summary and owner/Claude evidence review | NOT RUN | no READY or gate acceptance claimed |
| Seven-index tracking commit | NOT MADE | may occur only after P0 evidence acceptance |
| P1/filter implementation | NOT AUTHORISED | none of this is a quality/filter test |

**Do not delete or reset P0 scratch, regenerate verified indexes, re-admit XP, or access the protected hold-out media.** EP, TEST_2A and TEST_4A, and all `_blocky` variants, remain locked until S2-I8 **regardless of filename or aliases**. The new 6A/7A home media is not part of P0's allow-list, has no assigned experiment role and must not be substituted.

## 2. Baseline and actual Git state; urgent parallel issue

Reviewed design/candidate baseline: `35cd543b459a5856688f7c3795f73226e72311f8`.

Actual owner-reported and independently Claude-verified pushed HEAD at time of this status:

    3f8f45a77a8bbdd9d6bbc42718e6e74a2abd5e21

Intervening pushed commits:

- `6b7acc38168d0dea9278d1ba930bc09a174a50fe`: `SNAPSHOT after handovers updated`, 58 new files by Claude's GitHub audit; tracked tree grew from 181 to 239 files, 158.8 MB.
- `3f8f45a77a8bbdd9d6bbc42718e6e74a2abd5e21`: deletion of ONE identity-bearing handover review ZIP from current tree. The ZIP remains in the historical `6b7acc3` commit.

The snapshot **did preserve both reviewed current handovers**: ChatGPT v0.8 and Claude v0.10. Claude compared their committed LF-normalised bytes with the cleared install candidates and found exact matches. But D-23 v1.2 predecessor deletion was NOT completed: ChatGPT v0.7 and Claude v0.9 still appear in `docs/HANDOVER/`, so the CURRENT tree contains both superseded and current handovers.

Snapshot also committed the four TEST_6A/7A media files, 48 review-only artefacts (16 ZIPs), and a >50 MB repository-within-repository archive duplicating Restricted Media. Claude has separately confirmed **four more identity-bearing current-tree paths**, one plaintext, three ZIPs. Exact paths and remediation in section 8; handle urgently without changing the installed P0 overlay. **Repository tree removal does NOT scrub public Git history or third-party copies.** The Development Closure scrub is the policy-planned stage for history removal; changing that schedule requires the owner's separate decision.

At last observed status, the 15 P0 overlay files in `experiments/stage2/` were untracked; `experiments/S2-I3/Claude_DIFF_CLEARANCE_S2_I3_P0_S4_Candidate_v0_1.md` was also untracked. Do NOT assume current Git status without rerunning `git status`. The changed Git HEAD alone did not modify the pre-cleared P0 algorithms or scratch indexes.

## 3. P0A Windows failure, diagnosis and corrected PASS

Initially installed S4 overlay: 15 files = 7 BATs, 3 VPYs and 5 Python modules. First P0A run passed all six frozen-index regressions and four negative index tests, then failed in the P-skip suite:

    ModuleNotFoundError: No module named 'stage2_i3_pskip_core_v0_1'
    ERROR: S2-I3 P-skip unit tests failed
    Final ERRORLEVEL=2

Owner's diagnostic test established: portable `D:\TEST\Vapoursynth_x64_R81\python.exe` is CPython 3.14 embedded/isolated (`sys.flags.isolated=1`, `sys.flags.safe_path=True`, `python314._pth` present); module exists; Python's default search path excludes the sibling script directory; explicit `sys.path.insert(0,...)` makes import succeed; P0 scratch ROOT WAS ABSENT after failure. Isolated Python ignores `PYTHONPATH`, so setting it would not solve the problem. Claude acknowledged its original S4 testing mistakenly used a non-isolated interpreter even though earlier `-I` tests had exposed the failure.

Claude reviewed and **CLEARED** a one-BAT-only correction (`S2_I3_P0A_WINDOWS_ISOLATED_PYTHON_FIX_v0_1_FOR_CLAUDE_REVIEW.zip`): the two NumPy-dependent suites are launched through the actual VapourSynth Python using `-c` with `runpy.run_path`, explicit script-directory insertion in `sys.path` and `sys.argv=[script]`. Python modules, VPYs, and other six BATs remained byte-identical to fully rehearsed S4. No modifications were made to Python itself or `_pth`. Claude independently reproduced isolated failure and both repaired suites under Linux CPython `-I`; the **owner's Windows rerun** is the real platform proof.

Owner's corrected P0A output:

- Six accepted frozen S2-I1 `.idx` regressions PASS (LG LP, EP, MLS, TEST 2A original/blocky, TEST 4A original). Merely reading frozen metadata for regression does **not** admit or decode hold-out media.
- Four invalid-index negative tests PASS.
- The message `EXPECTED NEXT S2-I1 ACTION: TEST_4A_A003_blocky.idx is absent` is **EXPECTED**, is not a failure, and is **not** permission to generate a protected hold-out index.
- P-skip suite `Ran 9 tests ... OK`; pair suite `Ran 5 tests ... OK`.
- S2-I2 synthetic runtime preflight PASS; `vspipe` produced RGB24 16x16, one frame.
- `PASS: P0A; scratch ... Run P0B for six named sources.`; final ERRORLEVEL=0. P0A owns an existing scratch directory and `P0A_READY.txt` marker.

Recorded Windows runtime:

| Component | Observed Windows P0A | Prior accepted S2-I2 / independent Claude comparison |
|---|---|---|
| VapourSynth | R81 | same context |
| BestSource plugin | `PluginVersion(major=22, minor=0)` | SAME version |
| BestSource DLL SHA-256 | `fa5b9016ac55724843300e5a87d988c01a98eee87b679759d0e3f4ff3617f69c` | **Identical DLL SHA-256 to committed S2-I2 run_manifest.json**, checked by Claude |
| Python | embedded `3.14.8`, MSC v.1944, x64 | isolated Windows environment; not the Linux rehearsal runtime |
| NumPy | `2.5.4` | prior committed S2-I2 and Claude rehearsal: **2.5.3** |

Claude assessed the NumPy patch difference as immaterial to P0 identity checks (uint8 equality and integer-promoted pair differences). Record it in final evidence for P0D provenance anyway. It has NOT been concealed or called an identical entire software environment. DLL binary identity is particularly relevant for comparison to the committed S2-I2 diagnostics CSVs.

**Handover lesson pending future revision:** test Python invocation under both plain and isolated/embeddable conditions; script-directory imports cannot be assumed. This correction and its full Windows evidence belong in operational knowledge, not as a new deblocking mechanism.

## 4. P0B: all index identities and cross-platform reference comparison

Actual owner P0B calls: six individual frozen-inspector generation invocations, each PASS and ERRORLEVEL=0; independently expected full SHA, frame count, geometry and skip count in generated JSON. `LP_blocky` source from accepted S2-I2 scratch verified, exact byte-copy to P0 scratch verified, ERRORLEVEL=0. Original LP index remains frozen in `VHSC_samples` and was NOT regenerated.

| Label | Frame count | Pixel geometry | P skips | Exact SHA-256 | Provenance / Windows observation |
|---|---:|---|---:|---|---|
| XP | 228 | 720x576 | 1619 | `4f3821b5086a98b6c1b9f36f1ad2fac187e3b852602b740d15ffd72ba162f127` | generated PASS |
| XP_blocky | 228 | 720x576 | 25635 | `8d0326b5975b19b36742717a80be9eaf11bc21f379f2855eb22651e94dd16b20` | generated PASS |
| SP | 192 | 720x576 | 1764 | `40a97ce1a9920cd63e45da13371e0b41ff1619fed688d6145899a300463cc5d9` | generated PASS |
| SP_blocky | 192 | 720x576 | 19010 | `7e19ca6078075e7bf7a3a34bcda0816267e4d38ad02a56e01b6b0ed726ace746` | generated PASS |
| LP | 204 | 720x576 | 1533 | `849b6a9c411a7db837268af3ac54501a06f5f1158e68d5245ce2b3ec40a0d011` | FROZEN repository original, NOT generated in P0B |
| LP_blocky | 204 | 720x576 | 20300 | `b3f1d71483bf8a1376584019a020bd476b8d43dbc431a0a13eaa3795996b5238` | S2-I2 exact-copy PASS |
| 3A | 300 | 704x576 | 8812 | `9a60a8d24a7e4a45cbe82b4f41d232ede0e5c00624e82a8f8099f61351957f33` | generated PASS |
| 3A_blocky | 300 | 704x576 | 18190 | `e6f556dd4aaed0f4709b7c011fcf045193dccbb8abd2a01c646dddf0da893c83` | generated PASS |

**Claude independently compared all EIGHT rows on ALL FOUR values** against its prior Linux reference outputs; exact agreement. SIX new Windows indexes were generated with MSVC frozen inspector and are SHA-identical to Linux gcc frozen inspector outputs. This is strong evidence of cross-compiler, cross-platform deterministic index encoding (within these samples), and of no machine-dependent serialized fields; it is not a proof for every possible MPEG-2 stream. SEVEN indexed artefacts were checked during P0B (six generated plus LP_blocky copy); LP original is the eighth, pre-existing frozen baseline. This is the critical distinction to preserve in later evidence reports.

LP_blocky copy source: `%TEMP%\VapourSynth-mpeg2Deblock_S2_I2\LP_blocky\LG_576i_3_LP_blocky.idx`.
LP_blocky copy destination: `%TEMP%\VapourSynth-mpeg2Deblock_S2_I3_P0_v0_1\indexes\LG_576i_3_LP_blocky.idx`.

Six accepted Stage 1 frozen baseline indexes are NEVER to be rewritten. In particular `VHSC_samples\LG_576i_3_LP.idx` stays intact. No seven-index tracking commit has occurred or been authorised yet.

## 5. P0C completed source: XP, with independent extra structural check

Owner's P0C XP execution returned:

    PASS: XP exact P-skip admission
    ERRORLEVEL=0
    S2-I3 P-skip XP: REGISTERED, exact=1619/1619, P pictures=54

VapourSynth BestSource decoded 228 frames, 720x576 YUV420P8, 25 fps. `results\XP\admission.log` was displayed and matches these values. Expected per-source generated files: `index_validation.json`, `source_manifest.json`, `pskip_identity.json`, and `admission.log`; the full three JSON files have not been supplied or independently inspected in this chat yet.

**Claude independently cross-checked XP with its Linux rehearsal:** REGISTERED, 1619/1619, **54 qualifying P pictures**, 228 frames, and 720x576 YUV420P8 all match. The P-picture count is independent evidence beyond the prepublished P-skip allow-list: it follows the actual display-order anchor derivation, supporting that Windows and Linux chose the same P-picture structure. Do not downgrade this useful observation to merely a second copied hash check.

No other P0C source has been run. No P0D work has been run.

## 6. Exact next operation and remaining P0 sequence

**MANDATORY CMD practice:** begin every new owner CMD command block with `cd /d` to the repository root. Simple operations may be grouped, but each source admission is a separate gated run. Current installed overlay comprises 15 files: original cleared S4 six BATs + eight Python/VPY files, with **only the P0A BAT replaced** by Claude-cleared isolated-Python correction. Never copy `REVIEW_ONLY/` into `experiments/stage2/`. DO NOT repeat existing successful stages.

NEXT UNEXECUTED operation:

```bat
cd /d "E:\SOFTWARE-Win11\MULTIMEDIA\VapourSynth-mpeg2Deblock\VapourSynth-mpeg2Deblock"
call "experiments\stage2\S2_I3_P0C_admit_source_v0_1.bat" XP_blocky
echo P0C_XP_BLOCKY_ERRORLEVEL=%errorlevel%
if exist "%TEMP%\VapourSynth-mpeg2Deblock_S2_I3_P0_v0_1\results\XP_blocky\admission.log" type "%TEMP%\VapourSynth-mpeg2Deblock_S2_I3_P0_v0_1\results\XP_blocky\admission.log"
```

Expected remaining admissions from Claude's Linux rehearsal, including previously unpublished P-picture counts:

| Order | Source | Exact P skips expected | P pictures with qualified skips expected | Frames expected |
|---:|---|---|---:|---:|
| 1 | `XP_blocky` | 25635 / 25635 | **55** | 228 |
| 2 | `SP` | 1764 / 1764 | **46** | 192 |
| 3 | `SP_blocky` | 19010 / 19010 | **46** | 192 |
| 4 | `LP` | 1533 / 1533 | **46** | 204 |
| 5 | `LP_blocky` | 20300 / 20300 | **50** | 204 |
| 6 | `3A` | 8812 / 8812 | **133** | 300 |
| 7 | `3A_blocky` | 18190 / 18190 | **73** | 300 |

Every one must give exact **REGISTERED** and ERRORLEVEL=0. **STOP** if FAIL, INCONCLUSIVE, nonzero exit code, or unexpected P-picture count even if the formal identity count is exact; investigate anchor divergence before proceeding. Original LP uses frozen repository index; LP_blocky uses byte-copied S2-I2 scratch index.

**Evidence delivery policy updated per Claude:** Console output after EACH source suffices to continue; do NOT send all JSON to Claude individually. At the end of ALL eight admissions, eight diagnostics, four pairs and summary, send Claude the COMPLETE `results\` tree and summary/logs ONCE for independent full evidence review. If any source reports other than REGISTERED, immediately stop and send that source's JSON/logs for failure analysis.

After all eight P0C admissions:

1. Execute `S2_I3_P0D_diagnostics_v0_1.bat` once per allowed source (8 total). Diagnostics are descriptive, not substituted as hard admission gates; historical INCONCLUSIVE diagnostics are not automatically P0 failure.
2. Execute `S2_I3_P0D_pair_v0_1.bat` for XP, SP, LP, 3A, only when both original and `_blocky` versions are already admitted. Each must PASS with **zero decisive violations**; Claude's Linux P0 rehearsal had four passes (XP 140/228 decisive, SP 175/192, LP 81/204, 3A 268/300, subject to exact reviewer evidence interpretation). Fail/INCONCLUSIVE => stop and examine.
3. Execute `S2_I3_P0D_summary_v0_1.bat`; inspect `P0_summary.json`, source JSON evidence, diagnostics and pairs. A numerical `READY_FOR_P1=true` DOES NOT constitute owner/Claude authorisation to start P1/filter code.
4. Send complete evidence tree to Claude once for independent review/owner acceptance. ONLY after acceptance: separate, exact-path seven-index tracking procedure and bounded commit, no baseline replacement, no incidental media or review assets.

P0 scratch root: `%TEMP%\VapourSynth-mpeg2Deblock_S2_I3_P0_v0_1`; expected owned subdirs `indexes\`, `results\`, `P0A_READY.txt`. Preserve all files until gate review. P0C refuses to overwrite existing output directories; never delete an admitted source folder just to force rerun.

## 7. Source and reproducibility boundaries

Observed Windows quantities are transcribed from the owner's CMD output, including six verifier JSONs, copied LP_blocky source/destination JSONs, P0A stdout, and XP admission.log. Claude supplied its independent Linux hash references, per-source P-picture counts, DLL hash comparison and continuity assessment in `Claude_VERIFICATION_OF_S2_I3_P0_Windows_Run_Status_v0_1.md`. This document does NOT claim ChatGPT mounted the owner's Windows P0 scratch tree. FULL evidence verification is still pending.

Referenced cleared implementation reviews: `Claude_DIFF_CLEARANCE_S2_I3_P0_S4_Candidate_v0_1.md` and `Claude_REVIEW_OF_ChatGPT_P0A_Windows_Isolated_Python_Fix_v0_1_v0_1.md`.

The currently authoritatively accepted S2-I3/Stage2 design documents and Stage 1 frozen index invariants remain controlling. This status is not an amendment to thresholds, objectives or hold-out assignment.

## 8. URGENT parallel repository remediation (new Claude verification)

Claude scanned every GitHub-tracked text file AND the members of tracked ZIPs, and identified FOUR **still-current** paths bearing owner-identifying geographic text. Do NOT copy the identifying text into another committed report. All four are review artefacts, not accepted implementation or ratified design. The one earlier ZIP deletion does not cover them.

### Commit A: remove four remaining identity carriers FIRST

Expected staged shape: **0 ADD / 0 MODIFY / 4 DELETE**; exact tracked paths:

```
experiments/S2-I3/S2_I3_Full_Data_Multi_Source_Experimental_Design_v0_1_FOR_CLAUDE_REVIEW.md
experiments/S2-I3/S2_I3_v0_2_STAGE2_v0_7_FOR_CLAUDE_REVIEW.zip
experiments/S2-I3/S2_I3_v0_3_STAGE2_v0_7_FOR_CLAUDE_REVIEW.zip
experiments/S2-I3/ChatGPT_Handover_v0_8_FOR_CLAUDE_REVIEW.zip
```

First path contains plain searchable text; ZIP 1 includes the v0.2 design draft, ZIP 2 contains a review patch with the REMOVED identifying line, ZIP 3 contains the pre-correction ChatGPT v0.8 draft. **Important:** review diffs can carry the very text their reviewed versions successfully removed. Deleting just plaintext drafts is not enough. Use exact named `git rm -- <paths>`, inspect `git diff --cached --name-status --no-renames` for EXACTLY 4 D, then commit/push as a bounded separate change. Avoid `git add -A` and wildcards. This affects no installed P0 code, no scratch or accepted handovers.

### Commit B: remove D-23 superseded handover predecessors

Expected staged shape: **0 ADD / 0 MODIFY / 2 DELETE**; exact paths:

```
docs/HANDOVER/ChatGPT_Handover_To_Future_ChatGPT_MPEG2_Deblocking_Project_v0_7.md
docs/HANDOVER/Claude_HANDOVER_TO_Future_Claude_Chat_v0_9.md
```

**KEEP** their independently verified current successors `..._v0_8.md`, `..._v0_10.md` and the role continuity-purpose file. Predecessor deletion is required by D-23 v1.2, and prevents a new chat loading old handover material. A distinct bounded commit from A is recommended.

### Commit C: remaining review-only artefacts after an agreed exact pathlist

Claude reports **44 further review-only paths** to delete, after Commit A, including 16 ZIPs in the original snapshot inventory and review requests/patches. In particular `experiments/S2-I3/VapourSynth-mpeg2Deblock-main.zip` is ~54.1 MB and embeds a COPY OF THE REPOSITORY including 16 `.mpg` (~49 MB) and frozen indexes - duplication of Restricted Media. FIVE review artefacts were also committed under `experiments/stage2/`, which otherwise holds **accepted implementation code**: DO NOT delete accepted code with a blanket `git rm` or delete `experiments/stage2` as a folder. Claude will supply/check the specific remaining paths for owner agreement. Do NOT perform Commit C by wildcard; file classification and exact list remain pending. The four authorised 6A/7A recordings, both cleaned successor handovers, and all files already present at 35cd543 should be retained under Claude's current recommendation.

The history caveat applies to all above: the original snapshot `6b7acc3` retains deleted blobs in Git history; a push of deletion commits only cleans CURRENT HEAD. The existing Development Closure history scrub under D-23 is intended also to remove historical owner-identifying text; third-party clones/forks/caches may nevertheless retain it. If owner judges immediate public exposure unacceptable, a present-day history rewrite is a SEPARATE, disruptive owner decision; do not silently rewrite. Mark all five identity carriers (four above and the previously deleted corrected handover review ZIP) for that future scrub. The four recorded media in `6b7acc3` also have historical permanence implications independent of their current tree presence.

**Prevention lesson for next role handovers:** a review ZIP/diff/superseded draft often retains removed sensitive text; untracked working directories must not be swept into commits (`git add -A`). Inspect ZIP members and member names, not only loose text. After cleanup, consider an agreed `experiments/*.zip` ignore pattern or other targeted rule (a new rule needs bounded proposal and owner approval), and continue exact-path staging.

## 9. Parallel knowledge-preservation obligation; not a P0 gate

The owner's prior concern is that corrected Stage 2 empirical knowledge might disappear before its planned authority transfer. Route A was ratified: corrected measurements and provenance to eventual S2-I3 Evidence and Gate Report; accepted mechanism evidence to K-03, K-07, K-08 in next controlled `06_DEBLOCK_CONCEPT` revision. This transfer was **NOT yet performed**.

To prevent loss, the owner has explicitly requested ONE temporary consolidated knowledge document, beginning `interim_`, to be reviewed/expanded ONCE by Claude with Claude's own independent knowledge ADDED TO THE SAME DOCUMENT, then ratified and installed as temporary bridge. Candidate name:

`interim_S2_I3_Stage2_Knowledge_Preservation_and_Transfer_v0_1.md`

This temporary document is NOT a substitute for the authority transfer or the P0 report, and must be retired through D-23 after all recorded items have permanent homes. It is independent of the urgent hygiene Commit A/B/C and should be committed only after Claude's one-pass consolidation and the owner's acceptance. Do not mix it into a snapshot or a review-artefact cleanup commit.

## 10. Instructions for receiver / next developer chat

1. Check CURRENT Git HEAD and exact repo status; use reviewed controlling repository docs and the installed P0A fixed BAT, not superseded handovers or S4's uncorrected P0A.
2. Prioritise URGENT hygiene Commit A with exact four paths; the owner can separately continue P0. Commit B follows; Commit C requires Claude-checked exact pathlist. Do not claim history purged.
3. Continue from P0C XP_blocky, using section 6's `cd /d` CMD block and expected counts. Stop on unexpected P-picture result as well as formal FAIL. Console per source suffices unless failure; aggregate full results once later.
4. Retain P0 scratch, raw evidence, six immutable indexes and frozen LP original; track seven additional indexes only after full evidence acceptance.
5. Have Claude perform ONE consolidation of `interim_` knowledge material with its own additions; install only ratified final version under exact path, then transfer to evidence report + K-items at the proper stage.
6. Do not start P1, a filter, protected hold-out trials, fresh media roles or an index-format extension without separate owner authorisation.

**Reporting rule:** PASS/REGISTERED/READY are different. P0A/P0B passed; XP P0C REGISTERED; overall P0 completion/READY and independent gate acceptance have NOT happened.
