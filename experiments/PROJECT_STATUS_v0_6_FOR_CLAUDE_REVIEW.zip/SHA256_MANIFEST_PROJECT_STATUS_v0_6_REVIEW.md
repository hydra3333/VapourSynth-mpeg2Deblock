# SHA-256 Manifest - Project Status v0.6 Review Bundle

All hashes are for exact packaged bytes.

- `00_PROJECT_STATUS_v0_6_FOR_CLAUDE_REVIEW.md`: `b922b498d38e5d8ece1c3d5090a2e5b6b86f69e874360b81861ba6a180152985` (30978 bytes)
- `S2_I2_Project_Status_v0_5_to_v0_6_Diff_FOR_CLAUDE_REVIEW.patch`: `05332ea866f0ac548715bb299d330ca77726148bc6c9209972f310c93fa9e274` (17097 bytes)
- `S2_I2_Project_Status_v0_6_Change_Trace_v0_1_FOR_CLAUDE.md`: `d15bee593fe7323b434aaafb9549a8cd9ed3c590a7d62f28694b12b20a343cc7` (2583 bytes)
- `CLAUDE_REVIEW_REQUEST_PROJECT_STATUS_v0_6_v0_1.md`: `f82d778f19adb24d77a2ca06b42bf29a7d2ecf52aa2061693f3de053ac4c19a1` (2053 bytes)
- `00_PROJECT_STATUS_v0_5(1).md`: `a5f19fa8c9dfd83b8d701b4e327f48555be613f75558938f328e6c53f61881da` (23242 bytes)
