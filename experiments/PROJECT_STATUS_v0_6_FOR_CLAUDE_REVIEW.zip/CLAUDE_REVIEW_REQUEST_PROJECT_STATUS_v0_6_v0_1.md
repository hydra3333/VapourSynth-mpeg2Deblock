# Claude Review Request - Project Status v0.6

**Date:** 2026-10-16
**Status:** Review only. No new owner commands, Step-B commit or S2-I3 authorisation.

Please review `00_PROJECT_STATUS_v0_6_FOR_CLAUDE_REVIEW.md` against the enclosed SHA-verified *ratified* v0.5 source; do not use another historical v0.5 draft. Also use the already-issued S2-I2 closure v0.4 / Step-B placement v0.3 for current evidence/placement details.

## Specific checks requested

- Is v0.6 a conservative delta on the ratified status, leaving historical entries intact?
- Is the commit chain through `190bd06` correct, distinguishing the completed S2-I2 code commit from the pending Step-B documentation/evidence commit?
- Are the owner-ratified S2-I2 gate result, seven offset controls, LP primary, LP_blocky diagnostic-only role, scratch-index non-baseline status and limitations accurate?
- Does the authority/current-status wording remain accurate both during Step-B review and after installation? Identify any text that could become false when Step B is complete.
- Are the D-23 UTF-8 historical-record exceptions and narrowly scoped `experiments/stage2/results/** -text` rule correctly treated as owner decisions still pending, not silently adopted?
- Are material/hold-out roles and the S2-I3 NOT AUTHORISED boundary preserved?
- Does the source ZIP/status note correctly state that the 25 files are NOT YET EXTRACTED and must be individually hash-checked before staging?
- Check ASCII/CRLF; check the diff for unintended changes. Assign MUST/SHOULD/OPTIONAL findings with exact lines.

## Step-B sequencing

This is a status draft, not Step-B command authorisation. After Claude review, the owner may ratify the amended status, the two narrow UTF-8 exceptions and evidence attribute. Claude would then prepare the single exact Step-B Windows command sequence, including extraction, hash checks, attribute check, named staging, scoped whitespace checks, commit/push and GitHub round-trip verification. No source/media artefacts should be included.
