# Project Status v0.6 - Source, Minimal Delta and Review Trace

**Date:** 2026-10-16
**Status:** Claude review support; no owner ratification or Git operation implied.

## Authoritative baseline

- Ratified source document: owner attachment `00_PROJECT_STATUS_v0_5(1).md` (internally `00_PROJECT_STATUS_v0_5.md`).
- Working-copy form: US-ASCII, CRLF; SHA-256 `a5f19fa8c9dfd83b8d701b4e327f48555be613f75558938f328e6c53f61881da`.
- NOT used: the separately available `00_PROJECT_STATUS_v0_5.md` with SHA-256 `5596052a195ef7ed08279ca5cf9c35a414678297b502d02a9ed7d13976a1cf6b` (unratified draft).
- The original v0.5 remains unchanged. v0.6 is a separate proposed new file.

## Exact bounded edits (16 replacement regions)

1. header.
2. last verified commit.
3. commit history.
4. verified/not head.
5. stage2 chronology.
6. s2i2 accepted.
7. authority index.
8. later housekeeping.
9. current restart narrative.
10. current gate matrix.
11. future gate.
12. eol waiver and evidence pin.
13. handover note.
14. material roles.
15. role caveat.
16. change log.

## Draft constraints to check

1. No previous ratified version's change-log prose rewritten. Root SHA/tree, historical reset, Restricted Media requirements and Stage 1 baseline preserved.
2. S2-I2 PASS is already owner-ratified; code at `190bd06` is already pushed and independently GitHub-verified.
3. Step B is a **separate pending** documentation/evidence commit. Evidence remains inside the owner-reported `experiments/stage2/Z/VapourSynth-mpeg2Deblock_S2_I2.zip`; neither extraction nor Step-B staging is claimed.
4. The proposed `-text` line and two historical UTF-8 exceptions are NOT silently ratified; owner must explicitly approve before Step-B command issuance.
5. S2-I3 and later implementation/design increments remain NOT AUTHORISED.
6. Proposed installed path: `docs/REPOSITORY/00_PROJECT_STATUS_v0_6.md`; remove tracked v0.5 in same bounded Step-B commit per D-23, only after review/ratification.
7. Accepted status is a concise current-state index, not an authority superseding `05_DECISIONS`, Stage 2 v0.6 or `NOTICE.md`.

## Quality checks

- The original and draft are US-ASCII with CRLF line endings.
- SHA-256 values are for Windows CRLF bytes; a future Git/GitHub LF Markdown form has a different SHA-256.
- The accompanying diff is between the ratified v0.5 and the proposed v0.6; history and old change logs are retained.
- Claude should review the exact v0.6 text against the supplied v0.5, the latest closure v0.4 and the latest Step-B inventory v0.3.
