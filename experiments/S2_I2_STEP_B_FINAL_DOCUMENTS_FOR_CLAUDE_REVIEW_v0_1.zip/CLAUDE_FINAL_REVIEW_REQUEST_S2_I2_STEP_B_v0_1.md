# Claude - final Step-B report and status review request

**Date:** 2026-10-16
**Status:** for independent review; no Step-B changes have been applied or committed.

The owner explicitly ratified **YES** to both remaining decisions on 2026-10-16:

1. Evidence preservation: append exactly `experiments/stage2/results/** -text` to the root `.gitattributes` **before staging any evidence**, and verify via `git check-attr`.
2. Narrow D-23 exception for *only* the two original verbatim UTF-8 Copilot records: `docs/ChatGPT_Review_of_Copilot_Grok_MPEG2_Block_Detection_v0_1_FOR_CLAUDE.md` and `docs/COPILOT-MPEG2_Deblocking_VHS_DVD_Research.md`. Do not edit their historical content; this exception does not confer technical authority.

## Review targets

- `00_PROJECT_STATUS_v0_6.md`: review against the attached ratified Windows-CRLF `00_PROJECT_STATUS_v0_5(1).md` (SHA-256 a5f19fa8...81da) and the earlier v0.6 draft. Only the two owner decisions should be new since the last v0.6 draft; v0.5 and all older change-log entries must remain unchanged. **Status v0.6 is a draft, not yet owner-ratified or installed.**
- `S2_I2_Evidence_and_Gate_Report_v0_1.md`: exact proposed installation content for `docs/REPOSITORY/S2_I2_Evidence_and_Gate_Report_v0_1.md`. Compare against the Claude-cleared closure draft v0.4. Only the header/status, the now-approved decisions, Step-B execution wording and a provenance/change-log note should change; numerical results, hashes, reported limitations and thresholds must be identical. The S2-I2 **gate result** was owner-ratified 2026-10-16, but the exact report file is still presented for your review before installation.
- The previously cleared Step-B inventory v0.3 and pathlist v0.3 remain the intended file scope: **40 A / 1 M / 1 D** with both decisions approved. The research source is identity/NOTICE-cleared but **not** technical authority.

## Hard safety/verification points

- Source evidence still resides only in `experiments/stage2/Z/VapourSynth-mpeg2Deblock_S2_I2.zip` (SHA-256 0bce9022...34d6). It is **not unpacked**, staged, or committed. Extract and SHA-check all 25 evidence files at Step B; omit the scratch `.idx`. Do not delete the `Z/` source archive before verifying the pushed evidence.
- The nine-file code commit `190bd06ded88130ffddac7bb9adde4175d82f9f8` is DONE and must not be repeated. Frozen indexes remain immutable.
- `git diff --cached --check -- .gitattributes` is the only whitespace STOP check; expected CR/trailing-space reports for historical Markdown/evidence are informative only. Do not rewrite evidence or historical sources to silence them.
- After reviewing these exact files, provide the owner with the single Step-B CMD procedure, as agreed. No S2-I3 implementation is authorised.

Please report findings as MUST/SHOULD/OPTIONAL and verify the SHA-256 manifest.
