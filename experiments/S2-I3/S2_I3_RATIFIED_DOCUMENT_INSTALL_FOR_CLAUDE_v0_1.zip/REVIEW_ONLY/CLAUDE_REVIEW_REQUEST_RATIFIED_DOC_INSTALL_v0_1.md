# Claude Review Request - Ratified S2-I3 / Stage 2 Documentation Installation v0.1

Date: 2026-10-17
Base HEAD: 6e7b5c53df1c65775524936fc945c449cc9fa100
Owner RATIFIED 2026-10-17: Stage2_Experiment_Design_v0_7 and
S2_I3_Full_Data_Multi_Source_Experimental_Design_v0_3, after Claude clearance.
Owner also approved documentation-only installation with Project Status v0.7.
No implementation, admission preflight, filtering run or index commit is authorised.

## Review scope

1. `INSTALL_TARGETS/docs/REPOSITORY/Stage2_Experiment_Design_v0_7.md`:
   compare strictly against Claude-cleared final-wording v0.7. Changes should be
   authorisation/header/status/change-log wording only. Inspect any non-header
   replacements for truth as at commit. Preserve v0.6 and earlier history.
2. `INSTALL_TARGETS/docs/REPOSITORY/S2_I3_Full_Data_Multi_Source_Experimental_Design_v0_3.md`:
   same treatment vs cleared v0.3, including correcting stale operative v0.2/draft
   language. No scientific criteria, folds or decisions may change.
3. `INSTALL_TARGETS/docs/REPOSITORY/00_PROJECT_STATUS_v0_7.md`:
   IMPORTANT: this is a STATUS CANDIDATE for reconciliation, not yet cleared for
   named staging. The available local v0.6 copy predates Claude's Step-B M1 edits.
   The owner approved preparing a status update, NOT ratification of its unseen
   final content; seek owner ratification of status v0.7 after review.
   The live GitHub `docs/REPOSITORY/00_PROJECT_STATUS_v0_6.md` at the base HEAD
   is the ONLY valid authoritative predecessor. Independently compare the entire
   v0.6 history and unrelated content against the GitHub predecessor; transplant
   v0.7 changes onto the exact committed source if any unreviewed difference.
   Do not ratify or stage a status candidate on an unverified baseline.
4. Check D-23 ASCII/CRLF, no identity leaks, hash files; review-only patches
   stay OUT OF GIT. Install three final MD files in docs/REPOSITORY/ and remove
   only superseded Stage2 v0.6 and Project Status v0.6 in the same bounded commit.
   Expected named staging (if all three docs are cleared): 3 A / 2 D, Git may
   display renames; `git diff --cached --name-status --no-renames` is authoritative.
5. The seven approved non-baseline development indexes are EXCLUDED; six frozen
   Stage 1 indexes remain immutable. No untracked bulk staging.

After resolving the status-source check, issue the exact small Windows CMD
steps one at a time (unpack, place named files, verify hash, stage, status/check,
commit, push); then independently verify GitHub archive. No owner action now.
