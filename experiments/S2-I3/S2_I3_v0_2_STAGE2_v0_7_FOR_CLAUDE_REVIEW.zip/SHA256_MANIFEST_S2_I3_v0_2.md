# S2-I3 / Stage 2 v0.7 review package SHA-256 (WINDOWS-delivery bytes)

Ratified v0.6 source (mounted Project file), SHA-256: `6178a4f1d16e31b49b2794f7e6b3b06c5fec6a07d49872d0c6ebd4246bfb0b77` (LF form).

- `91ec335318c643c8bba62be3f4aa51870c958a33e2a174ba63c54f0e9127efc5`  CLAUDE_REVIEW_REQUEST_S2_I3_v0_2_AND_STAGE2_v0_7.md (2701 bytes)
- `73a24a224fc4c59c410b7575797c2afbcce76f1e3040c6beba0c349bc3e0937e`  S2_I3_Full_Data_Multi_Source_Experimental_Design_v0_2_FOR_CLAUDE_REVIEW.md (21964 bytes)
- `ff04dfec03871aafcf7f837758fabf63829cc6e66e06df79a64e7f79ccf9c90a`  SHA256_MANIFEST_S2_I3_v0_2.md (883 bytes)
- `1fec28fa7d375e69078c03633fa53033223402570955678ff083b16cfaa3f7cd`  Stage2_Experiment_Design_v0_7_FOR_CLAUDE_REVIEW.md (66018 bytes)
- `d81b6ddb93dcb92252dfab3ed6ec1e62e9786d3cb913a6d617e3405ad6c93ad4`  Stage2_v0_6_to_v0_7_FOR_CLAUDE_REVIEW.patch (39519 bytes)
