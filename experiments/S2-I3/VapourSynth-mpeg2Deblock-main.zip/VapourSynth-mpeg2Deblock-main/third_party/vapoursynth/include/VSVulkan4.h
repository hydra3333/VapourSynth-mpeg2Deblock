/*
* Copyright (c) 2026 Fredrik Mellbin
*
* This file is part of VapourSynth.
*
* VapourSynth is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* VapourSynth is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with VapourSynth; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

/* The GPU side of the API, obtained through VSAPI::getVulkanAPI. It has no version of its own and
 * grows with the core API instead, so there is nothing to negotiate and the call cannot fail. It
 * is also organised for reading rather than for offsets: a new entry point goes with the ones it
 * belongs to, which moves every pointer after it, so everything built against this header is
 * rebuilt when it changes -- the same lockstep the core API already asks for. Nothing warns about
 * getting that wrong, because nothing can: a plugin left over from an older header still links and
 * still runs, and simply calls the neighbouring function. It
 * is deliberately a raw exposure: the core hands out its Vulkan handles and per plane buffers, and
 * a GPU filter brings its own pipelines, command buffers and synchronization on top of them. The
 * contract in short:
 *
 * - Resolve every entry point through getInstanceProcAddr/vkGetDeviceProcAddr from the handles;
 *   nothing is linked.
 * - vkQueueSubmit on the shared queues must happen with the matching queue lock held.
 * - Before reading a plane on the GPU, wait for its (readySemaphore, readyValue) pair; after
 *   producing one, publish your own pair through setGPUPlaneProducer, whose timeline is a
 *   counted VSGPUTimeline the plane keeps alive by itself. A null semaphore means host produced
 *   content that is ready immediately.
 * - Hold references to every frame a submission touches until that submission has completed.
 * - GPU producing functions declare "vnode:gpu" returns and create their nodes with ffGPUOutput.
 */

#ifndef VSVULKAN4_H
#define VSVULKAN4_H

#include "VapourSynth4.h"

#ifndef VULKAN_CORE_H_
/* Only types are needed; including Vulkan yourself first, with or without prototypes, is fine. */
#define VK_NO_PROTOTYPES
#endif
#include <vulkan/vulkan_core.h>


/* Vulkan 1.4 is required rather than negotiated. It brings timeline semaphores, synchronization2,
   descriptor indexing, buffer device address, push descriptors and maintenance5/6 into core,
   which is what lets this table be almost entirely unconditional. */
#define VS_VULKAN_API_VERSION VK_API_VERSION_1_4

/* Which handle a function is resolved against. Device level entry points are deliberately fetched
   with vkGetDeviceProcAddr: resolving them through the instance yields a loader trampoline that
   has to dispatch on the first argument of every single call. */
enum VSVulkanLevel {
    VS_VK_GLOBAL,   /* resolved from a null instance, before one exists */
    VS_VK_INSTANCE,
    VS_VK_DEVICE
};

/* Optional entries are allowed to stay null and must be null checked at the call site. Everything
   else is core 1.4 and its absence means the device lied about its version, which is fatal. */
enum VSVulkanRequirement {
    VS_VK_REQUIRED,
    VS_VK_OPTIONAL
};

#define VS_VK_FUNCTION_LIST(FN) \
    /* ---- Global ---- */ \
    FN(VS_VK_GLOBAL,   VS_VK_REQUIRED, EnumerateInstanceVersion) \
    FN(VS_VK_GLOBAL,   VS_VK_REQUIRED, EnumerateInstanceExtensionProperties) \
    FN(VS_VK_GLOBAL,   VS_VK_REQUIRED, EnumerateInstanceLayerProperties) \
    FN(VS_VK_GLOBAL,   VS_VK_REQUIRED, CreateInstance) \
    \
    /* ---- Instance ---- */ \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, DestroyInstance) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, EnumeratePhysicalDevices) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetPhysicalDeviceProperties2) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetPhysicalDeviceFeatures2) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetPhysicalDeviceMemoryProperties2) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetPhysicalDeviceQueueFamilyProperties2) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetPhysicalDeviceFormatProperties2) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetPhysicalDeviceImageFormatProperties2) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, EnumerateDeviceExtensionProperties) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, CreateDevice) \
    FN(VS_VK_INSTANCE, VS_VK_REQUIRED, GetDeviceProcAddr) \
    /* Validation and tooling, present only when the layer or extension is enabled. */ \
    FN(VS_VK_INSTANCE, VS_VK_OPTIONAL, CreateDebugUtilsMessengerEXT) \
    FN(VS_VK_INSTANCE, VS_VK_OPTIONAL, DestroyDebugUtilsMessengerEXT) \
    \
    /* ---- Device ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyDevice) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DeviceWaitIdle) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetDeviceQueue2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, QueueSubmit2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, QueueWaitIdle) \
    \
    /* ---- Memory ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, AllocateMemory) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, FreeMemory) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, MapMemory2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, UnmapMemory2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, FlushMappedMemoryRanges) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, InvalidateMappedMemoryRanges) \
    \
    /* ---- Buffers ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetBufferMemoryRequirements2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, BindBufferMemory2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetBufferDeviceAddress) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetDeviceBufferMemoryRequirements) \
    \
    /* ---- Images ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateImage) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyImage) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetImageMemoryRequirements2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, BindImageMemory2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateImageView) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyImageView) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetImageSubresourceLayout2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetDeviceImageMemoryRequirements) \
    \
    /* ---- Samplers ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateSampler) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroySampler) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateSamplerYcbcrConversion) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroySamplerYcbcrConversion) \
    \
    /* ---- Descriptors ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateDescriptorSetLayout) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyDescriptorSetLayout) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateDescriptorPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyDescriptorPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, ResetDescriptorPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, AllocateDescriptorSets) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, FreeDescriptorSets) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, UpdateDescriptorSets) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateDescriptorUpdateTemplate) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyDescriptorUpdateTemplate) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, UpdateDescriptorSetWithTemplate) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetDescriptorSetLayoutSupport) \
    \
    /* ---- Pipelines ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreatePipelineLayout) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyPipelineLayout) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateComputePipelines) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyPipeline) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreatePipelineCache) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyPipelineCache) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetPipelineCacheData) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, MergePipelineCaches) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateShaderModule) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyShaderModule) \
    \
    /* ---- Command pools and buffers ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateCommandPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyCommandPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, ResetCommandPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, TrimCommandPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, AllocateCommandBuffers) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, FreeCommandBuffers) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, BeginCommandBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, EndCommandBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, ResetCommandBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdExecuteCommands) \
    \
    /* ---- Command recording. The 2 suffixed forms are the 1.4 core spellings. ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdBindPipeline) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdBindDescriptorSets2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdPushConstants2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdPushDescriptorSet) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdPushDescriptorSetWithTemplate) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdDispatch) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdDispatchBase) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdDispatchIndirect) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdPipelineBarrier2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdCopyBuffer2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdCopyImage2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdCopyBufferToImage2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdCopyImageToBuffer2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdBlitImage2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdFillBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdUpdateBuffer) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdClearColorImage) \
    \
    /* ---- Synchronisation ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateSemaphore) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroySemaphore) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, WaitSemaphores) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, SignalSemaphore) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetSemaphoreCounterValue) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateFence) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyFence) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, ResetFences) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, WaitForFences) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetFenceStatus) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateEvent) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyEvent) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdSetEvent2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdResetEvent2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdWaitEvents2) \
    \
    /* ---- Timestamp queries ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CreateQueryPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, DestroyQueryPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, GetQueryPoolResults) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, ResetQueryPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdResetQueryPool) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdWriteTimestamp2) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdCopyQueryPoolResults) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdBeginQuery) \
    FN(VS_VK_DEVICE,   VS_VK_REQUIRED, CmdEndQuery) \
    \
    /* ---- Debug labels, present only alongside the debug utils extension ---- */ \
    FN(VS_VK_DEVICE,   VS_VK_OPTIONAL, SetDebugUtilsObjectNameEXT) \
    FN(VS_VK_DEVICE,   VS_VK_OPTIONAL, CmdBeginDebugUtilsLabelEXT) \
    FN(VS_VK_DEVICE,   VS_VK_OPTIONAL, CmdEndDebugUtilsLabelEXT)

typedef struct VSVulkanFunctions {
#define VS_VK_DECLARE_MEMBER(level, req, name) PFN_vk##name vk##name;
    VS_VK_FUNCTION_LIST(VS_VK_DECLARE_MEMBER)
#undef VS_VK_DECLARE_MEMBER
} VSVulkanFunctions;

/* The two are NOT interchangeable, and Vulkan guarantees the implication one way only: a
 * compute queue always accepts transfer commands, while a dedicated transfer queue need not
 * accept compute ones -- a discrete card's DMA family typically reports VK_QUEUE_TRANSFER_BIT
 * alone. So vqCompute takes anything, and vqTransfer must be given copies only; recording a
 * dispatch against it is invalid usage wherever a real DMA family exists, and silently fine on
 * the hardware where vqTransfer resolves to a compute queue, which is what makes the mistake easy
 * to ship. When in doubt use vqCompute: the cost is losing overlap with the core's own
 * transfers, not correctness. */
typedef enum VSVulkanQueueType {
    vqCompute = 0,
    vqTransfer = 1 /* the transfer family's queue; without a transfer family the compute family's second
                      queue where it has one, and only failing both the same underlying queue as
                      vqCompute. The core's uploads always run on this queue, and its frame downloads
                      too unless the transfer family has a second queue, which is never handed out */
} VSVulkanQueueType;

/* What a host wait established. Returned by all three of them -- gpuExecPoolWaitIdle,
 * gpuExecWaitValue and gpuTimelineWaitValue -- because the question a caller asks after a wait
 * is the same one every time. Anything other than gdDrained is a failure for a caller that only
 * wants to know whether it can carry on, so `if (gpuExecWaitValue(...))` keeps meaning what it
 * always did. The distinction matters to one kind of caller: anything deciding whether resources
 * a submission might still be using are safe to destroy. A reset did not keep the promise the
 * wait makes, but it did abandon every submission, so for that decision it is as good as
 * drained, and treating it as an ordinary failure instead strands everything the pool held, the
 * pool, and the device with them.
 *
 * The half of gdDrained about release callbacks belongs to gpuExecPoolWaitIdle, the only one of
 * the three that promises anything about them; from the other two it means the submission
 * completed.
 *
 * gdDrained is as strong as the driver allows, which is not absolute. Behind it the core checks
 * the counter that actually satisfied the wait, which catches a reset that force-signals
 * timelines past everything, and it acts on any call that reports device loss outright. A
 * driver that answers a reset by signalling exactly the values the abandoned submissions were
 * going to signal produces neither, and no Vulkan query separates that from real completion:
 * the specification permits a wait to succeed after a loss, requires no report of the loss, and
 * has no reset status query. That behaviour has been measured, and on such a stack a reset
 * yields stale output under a gdDrained. A filter that must be certain of a result has to check
 * the result itself; there is nothing further the core can ask on its behalf. */
typedef enum VSGPUDrainResult {
    gdDrained = 0,     /* the wait established completion, and for a pool drain every release callback has run */
    gdIncomplete = 1,  /* the wait could not be established; submissions may still be running */
    gdDeviceLost = 2   /* the device was reset or lost, so nothing is executing any more */
} VSGPUDrainResult;

/* Whether a wait left it safe to destroy what a submission might still have been using. Say it
 * this way rather than `result != gdIncomplete`: written as the positive condition, a value
 * added to VSGPUDrainResult later is unsafe by default, where the negative form would silently
 * enrol it on the safe side and start destroying pipelines and buffers under a live dispatch. */
static inline int vsGPUDrainSafeToDestroy(int drainResult) {
    return drainResult == gdDrained || drainResult == gdDeviceLost;
}

/* Everything needed to run your own Vulkan work on the core's device. */
typedef struct VSVulkanCoreHandles {
    VkInstance instance;
    VkPhysicalDevice physicalDevice;
    VkDevice device;
    PFN_vkGetInstanceProcAddr getInstanceProcAddr;
    uint32_t computeQueueFamily;
    uint32_t computeQueueIndex;
    uint32_t transferQueueFamily; /* with transferQueueIndex, the compute family's second queue when there is
                                     no transfer family but the compute family has two queues, and equal to
                                     the compute values when it has only one */
    uint32_t transferQueueIndex;
} VSVulkanCoreHandles;

/* The device feature baseline. The core creates every device itself: Vulkan 1.4 with exactly
 * the features below, and no extensions but the platform's opaque memory and semaphore handle
 * export (VK_KHR_external_memory/_semaphore_win32 or _fd) where available,
 * VK_KHR_portability_subset where the device demands it and the two float atomic extensions
 * described at the end of this comment. Every REQUIRED entry is mandatory for a conformant 1.4
 * implementation. Sharing frames with another device or API goes through exportGPUPlane, not
 * device sharing.
 *
 *   required (VkPhysicalDeviceFeatures): shaderInt16, shaderImageGatherExtended,
 *     shaderStorageImageExtendedFormats, shaderUniformBufferArrayDynamicIndexing,
 *     shaderSampledImageArrayDynamicIndexing, shaderStorageBufferArrayDynamicIndexing,
 *     shaderStorageImageArrayDynamicIndexing
 *   required (Vulkan11Features): storageBuffer16BitAccess, variablePointersStorageBuffer,
 *     variablePointers, samplerYcbcrConversion
 *   required (Vulkan12Features): timelineSemaphore, hostQueryReset,
 *     uniformBufferStandardLayout, shaderSubgroupExtendedTypes, subgroupBroadcastDynamicId,
 *     bufferDeviceAddress, vulkanMemoryModel, vulkanMemoryModelDeviceScope,
 *     storageBuffer8BitAccess, shaderInt8, scalarBlockLayout
 *   required (Vulkan13Features): synchronization2, maintenance4, subgroupSizeControl,
 *     computeFullSubgroups, shaderIntegerDotProduct, shaderZeroInitializeWorkgroupMemory,
 *     inlineUniformBlock, pipelineCreationCacheControl, privateData
 *   required (Vulkan14Features): maintenance5, maintenance6, pushDescriptor,
 *     shaderSubgroupRotate, shaderSubgroupRotateClustered, shaderFloatControls2,
 *     shaderExpectAssume, pipelineRobustness
 *   optional, enabled when the device has it: shaderFloat16 (Vulkan12Features), shaderInt64 and
 *     shaderFloat64 (Features), shaderBufferInt64Atomics and shaderSharedInt64Atomics
 *     (Vulkan12Features) -- query the physical device to find out whether you got them
 *
 * Two more extensions are enabled beyond the handle export pair, under the same policy the
 * optional features above follow: VK_EXT_shader_atomic_float whenever the device offers it, and
 * VK_EXT_shader_atomic_float2 in addition whenever it offers that too, each with exactly the
 * feature bits the device reports. The two are independent: the first never waits for the
 * second, so shaderBufferFloat32AtomicAdd, say, needs only VK_EXT_shader_atomic_float and that
 * bit. That guarantee is the availability contract -- Vulkan cannot ask a created device what
 * was enabled, so enable-whatever-is-reported is what makes the physical device's own queries
 * authoritative. Check presence with vkEnumerateDeviceExtensionProperties and the bits with
 * vkGetPhysicalDeviceFeatures2; what they report is what is live. Resolve any extension entry
 * points you need yourself through the handles' getInstanceProcAddr -- the function table below
 * stays core 1.4 plus debug utils by design. */

/* One GPU resident plane: a linear pitched storage buffer laid out exactly like the equivalent
 * CPU plane, so getStride and the frame dimension functions apply unchanged. */
typedef struct VSVulkanPlaneInfo {
    VkBuffer buffer;
    VkDeviceSize bufferSize;    /* stride * height bytes */
    VkSemaphore readySemaphore; /* wait (semaphore, value) before reading; NULL means ready now */
    uint64_t readyValue;
} VSVulkanPlaneInfo;

/* A timeline semaphore for publishing producer pairs, reference counted and owned by the core.
 * A filter signals it and hands it to setGPUPlaneProducer; every plane it is published on keeps a
 * reference of its own until the plane is freed, so the semaphore lives for as long as something
 * might still wait on it.
 *
 * A filter's timeline therefore need not outlive its consumers: release your reference once you
 * are done signalling -- the free callback is the natural place -- and any frame still in flight
 * keeps the semaphore alive. Frames legitimately outlive the filter that made them (FrameEval
 * and ModifyFrame return one from a node they then drop, and the cache can hold one
 * indefinitely), which is what the counting is for.
 *
 * The semaphore is created exportable wherever the device supports it, so a foreign API can
 * signal the pairs you publish on it. */
typedef struct VSGPUTimeline VSGPUTimeline;

/* A scratch buffer from the core's pooled VRAM allocator, for filters needing memory that is
 * not a frame plane: reduction partials, lookup tables, intermediate rows. Owned through the
 * opaque handle; the info struct is everything a kernel or the host needs to use it. */
typedef struct VSGPUBuffer VSGPUBuffer;

typedef struct VSVulkanBufferInfo {
    VkBuffer buffer;
    VkDeviceAddress address;         /* nonzero when usage included SHADER_DEVICE_ADDRESS */
    void *mapped;                    /* nonnull when the memory ended up host visible; persistently mapped */
    VkDeviceSize size;               /* the requested size, unrounded */
    VkMemoryPropertyFlags memoryFlags; /* what the chosen memory type actually provides */
} VSVulkanBufferInfo;

/* A bare region of the same pooled VRAM, for resources the core has no constructor for. An
 * image is the case that motivates it: memory is never passed to vkCreateImage, it is bound
 * afterwards, so nothing is gained by wrapping image creation -- the filter creates the image
 * its own way and only the allocation comes from here. */
typedef struct VSGPUMemory VSGPUMemory;

typedef struct VSVulkanMemoryInfo {
    VkDeviceMemory memory;   /* the shared block; bind against it, never free it */
    VkDeviceSize offset;     /* where the region starts in that block; pass to vkBind*Memory2 */
    VkDeviceSize size;       /* what the region actually reserves, at least the requested size */
    void *mapped;            /* nonnull when host visible, already offset to the region */
    VkMemoryPropertyFlags memoryFlags; /* what the chosen memory type actually provides */
} VSVulkanMemoryInfo;

/* A declaration of GPU memory allocated outside the core -- by CUDA, another Vulkan device
 * ecosystem, a video session -- so the byte count takes part in the core's budgeting; see
 * reserveGPUMemory. Holds no memory itself, only the number. */
typedef struct VSGPUMemoryReservation VSGPUMemoryReservation;

/* A frame plane's backing memory exported as an opaque handle, so CUDA or another Vulkan
 * device in the process can wrap the allocation and read or write the plane zero copy. The
 * plane lives at offset within an allocation of memorySize bytes from memory type
 * memoryTypeIndex; import the whole allocation once and address planes by offset.
 *
 * memoryId is stable for the allocation's lifetime and never reused, while every export call
 * returns a NEW handle — so key cached imports by memoryId, never by handle value, and close
 * surplus handles. The handle belongs to the caller: an NT handle is not consumed by Vulkan or
 * CUDA import, so CloseHandle it once the import exists; a POSIX fd is consumed by a
 * successful import and must only be closed when the import failed.
 *
 * The OS reference-counts the memory, so a cached import may outlive the frames, and the core,
 * that led to it; VS_GPU_IMPORT_CHARGED_AGAIN says what holding one costs. Synchronization is
 * host side: call waitGPUFrame before reading through an import (a bare producer pair wait is
 * not enough, see there) and finish foreign writes before returning a frame containing them.
 *
 * A foreign API writes only into new frames. Exporting a plane nothing has written yet, of a
 * frame only you hold -- created and not yet returned, copied or otherwise shared -- hands it to
 * the foreign API to write: the queue family ownership transfer Vulkan requires of external
 * memory. The core takes it back the first time a frame containing it is returned from getFrame
 * or passed to cacheFrame, directly or through its properties (an _Alpha frame), ordered after
 * the plane's producer pair at that moment: publish the foreign side's completion with
 * setGPUPlaneProducer before that, or finish its work on the host. Until then the plane is the
 * foreign API's alone, whichever frames share it: declaring it in an exec context is fatal, and
 * so is returning or caching a frame containing it while holding an exec context, since taking
 * it back takes one of the core's. Input frames are handed over by taking them with
 * getExportableFrameFilter, for reading only, and never come back; exporting any other plane
 * fails. */
typedef struct VSVulkanExportedMemory {
    uint64_t memoryId;
    VkDeviceSize memorySize;
    /* The memory type the allocation was made from. An opaque handle carries no memory type
     * information of its own: Vulkan forbids asking which types it accepts, and requires it
     * to be imported with exactly the exporting allocation's memoryTypeIndex and
     * allocationSize. A Vulkan importer therefore passes this and memorySize to
     * vkAllocateMemory unchanged, which is well defined because type numbering is per
     * physical device and sharing is only defined with a core on the same one. CUDA
     * importers have no use for it. */
    uint32_t memoryTypeIndex;
    VkDeviceSize offset;
    VkDeviceSize size;   /* the plane's bytes, stride * height */
    int handleType;      /* the VkExternalMemoryHandleTypeFlagBits of the handle */
    intptr_t handle;     /* HANDLE on Windows, file descriptor elsewhere */
} VSVulkanExportedMemory;

/* Whether holding an import of memory exportGPUPlane handed out costs the process that memory a
 * second time, on top of the core's own allocation: 1 where it does, so an importer declares its
 * imports with reserveGPUMemory, and 0 where it doesn't, so declaring them would only make the
 * core cache fewer frames. Windows charges a shared allocation against the process's budget
 * again for every device that opens it. On Linux an import is the same kernel buffer object as
 * the core's allocation and takes no memory of its own, though the driver adds it to the
 * process's heap usage as Vulkan requires. Everywhere, an import of a block the core has since
 * freed keeps that memory alive by itself, and the core no longer counts it, so keep the number
 * of imports you hold bounded. */
#ifdef _WIN32
#define VS_GPU_IMPORT_CHARGED_AGAIN 1
#else
#define VS_GPU_IMPORT_CHARGED_AGAIN 0
#endif

/* An exec pool and one of its recording slots. The pool owns a timeline semaphore, a
   command pool and contextCount command buffers; a context is one recording, claimed by
   one thread from gpuExecAcquire until gpuExecSubmit or gpuExecAbandon.

   This is the plumbing every GPU filter needs regardless of what it records: waiting on the
   producers of the frames it reads, keeping those frames alive until the GPU is done,
   allocating timeline values in queue order, and publishing producer pairs on the planes it
   writes. Filters that record ordinary dispatches and filters that record indirect
   dispatches, custom barriers or their own query pools need it equally, so the context
   hands out its command buffer and imposes nothing on what goes into it. */
typedef struct VSGPUExecPool VSGPUExecPool;
typedef struct VSGPUExecContext VSGPUExecContext;

/* Cleanup a filter hands to an exec context, run once the submission it was recorded against
 * has completed; see gpuExecRetain. */
typedef void (VS_CC *VSGPUReleaseFunc)(void *object);

/* A runtime compiled shader as an opaque handle holding the SPIR-V words. Independent of
   everything else once returned: it stays valid after the core that compiled it is freed
   and is released with freeGPUShader. */
typedef struct VSGPUShader VSGPUShader;

typedef enum VSGPUShaderLanguage {
    slGLSL = 0 /* compute stage GLSL; the core pins the accepted dialect as a platform property: write #version 460, compiled for the Vulkan 1.4 client targeting SPIR-V 1.6 */
} VSGPUShaderLanguage;

/* A timeline semaphore exported as an opaque handle, from exportGPUSemaphore. Importing a
 * producer pair's semaphore lets a CUDA stream or another Vulkan device wait the pair on the
 * device, replacing waitGPUFrame's host wait and restoring full pipelining across the API
 * boundary; an external semaphore wait also carries the cross device memory dependency, so
 * no separate availability flush is needed on that path.
 *
 * Every call returns a NEW handle for the same semaphore. Cache imports keyed by the
 * VkSemaphore value from VSVulkanPlaneInfo, scoped to your filter instance: a plane holds a
 * reference to the timeline it names, so as long as you hold the frame the handle stays
 * live and the key cannot go stale. Handle ownership follows the same platform rules as memory
 * export (close NT handles after importing; fds are consumed by a successful import). */
typedef struct VSVulkanExportedSemaphore {
    int handleType;      /* the VkExternalSemaphoreHandleTypeFlagBits of the handle */
    intptr_t handle;     /* HANDLE on Windows, file descriptor elsewhere */
} VSVulkanExportedSemaphore;

typedef struct VSVulkanCoreInfo {
    char deviceName[256];
    int64_t deviceMemory; /* largest device local heap */
    int64_t budget;       /* what the driver says this process may reasonably use right now */
    /* Current VapourSynth use of device memory: frames, pooled buffers, reservations and
       any transfer staging the driver placed there. Staging in system RAM, the discrete card
       case, counts toward VSCoreInfo's usedFramebufferSize instead. */
    int64_t allocated;
    int64_t limit;        /* the eviction limit, settable through setMaxVRAMUse */
    /* Identity for matching against other APIs' device enumerations (CUDA exposes the same
       UUID; the LUID pairs with DXGI adapters and is only meaningful when luidValid). */
    uint8_t deviceUUID[VK_UUID_SIZE];
    uint8_t deviceLUID[VK_LUID_SIZE];
    uint32_t deviceNodeMask;
    int deviceLUIDValid;
    int exportHandleType; /* VkExternalMemoryHandleTypeFlagBits exportGPUPlane hands out, 0 when export is unavailable */
    int semaphoreExportHandleType; /* VkExternalSemaphoreHandleTypeFlagBits exportGPUSemaphore hands out, 0 when unavailable */
    /* Nonzero when the device's memory is the host's, which is the case for integrated and
       software devices. deviceMemory and budget then describe a share of system RAM rather
       than separate hardware, and limit is capped so it and the host memory limit together
       leave the machine some room; a plugin sizing its own pools should do likewise. */
    int unifiedMemory;
} VSVulkanCoreInfo;

/* One entry per physical device; the position in the enumeration is exactly the index
 * setVulkanDevice takes. Unusable devices are listed too and may be selected, which fails
 * with their reason, so a frontend can present everything and explain refusals. */
typedef struct VSVulkanDeviceListEntry {
    char deviceName[256];
    uint32_t apiVersion;
    int deviceType;       /* VkPhysicalDeviceType */
    int64_t deviceMemory; /* largest device local heap */
    int usable;           /* passes the Vulkan 1.4 and required feature gate */
    char unusableReason[256];
    uint8_t deviceUUID[VK_UUID_SIZE];
    uint8_t deviceLUID[VK_LUID_SIZE];
    uint32_t deviceNodeMask;
    int deviceLUIDValid;
} VSVulkanDeviceListEntry;

struct VSVULKANAPI {
    /* Unless an entry says otherwise, a status returning function returns 0 on success and
       nonzero on failure, and one returning a handle returns NULL on failure; either way the
       reason lands in errorMessage where the function takes one. */

    /* ---- Device selection and information ---- */

    /* Lists every physical device through a temporary instance, so it works before any device
       selection and needs no core. Returns the total device count, which may exceed
       maxEntries, or -1 with the error set; entries and maxEntries 0 just count. */
    int (VS_CC *enumerateVulkanDevices)(VSVulkanDeviceListEntry *entries, int maxEntries, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* Picks which of those this core runs on, only before the device is first used; -1 picks
       the most powerful one. */
    int (VS_CC *setVulkanDevice)(VSCore *core, int deviceIndex, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* What the core ended up with and where its VRAM budget stands. Brings the device up on
       first call, like the first GPU filter would. */
    int (VS_CC *getVulkanCoreInfo)(VSCore *core, VSVulkanCoreInfo *info, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    int64_t (VS_CC *setMaxVRAMUse)(int64_t bytes, VSCore *core) VS_NOEXCEPT; /* mirrors setMaxCacheSize for the VRAM pool */

    /* ---- Calling Vulkan on the core's device ---- */

    /* The instance, physical device, device and queue indices. Brings the device up on first
       call, like the first GPU filter would. */
    int (VS_CC *getVulkanHandles)(VSCore *core, VSVulkanCoreHandles *handles, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* The core's ready loaded dispatch table, the normal way for filters to call Vulkan; the
       handles' getInstanceProcAddr stays available for anything outside the curated set.
       Brings the device up on first call and stays valid for the core's lifetime. */
    const VSVulkanFunctions *(VS_CC *getVulkanFunctions)(VSCore *core, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* Mandatory around every vkQueueSubmit you make on the shared queues.

       This is one of the core's own locks, so treat it as a LEAF: submit between the two
       calls and do nothing else. In particular call nothing from this API inside the bracket
       -- allocating GPU memory, creating a frame, acquiring from or waiting on an exec pool,
       creating or freeing one all reach the core's exec registry, which the core's own frame
       path locks before this queue, so holding this across one of them deadlocks against an
       ordinary cache sweep on a worker thread. And do not hold both queues' locks at once:
       vqTransfer and vqCompute are the same non-recursive lock on a device with neither a
       dedicated transfer family nor a second compute queue, so on that hardware the second call
       never returns. Neither mistake can be diagnosed from inside the core, which is why they
       are rules here. */
    void (VS_CC *lockVulkanQueue)(VSCore *core, int queue) VS_NOEXCEPT;
    void (VS_CC *unlockVulkanQueue)(VSCore *core, int queue) VS_NOEXCEPT;

    /* ---- GPU resident frames ---- */

    /* GPU resident frames for filter output; identical semantics to newVideoFrame otherwise, except that
       NULL is returned when no Vulkan device is available. Note that newVideoFrame2 also supports GPU resident frames */
    VSFrame *(VS_CC *newGPUVideoFrame)(const VSVideoFormat *format, int width, int height, const VSFrame *propSrc, VSCore *core) VS_NOEXCEPT;
    int (VS_CC *getGPUPlane)(const VSFrame *frame, int plane, VSVulkanPlaneInfo *info) VS_NOEXCEPT; /* nonzero when the frame is not GPU resident or the plane does not exist */
    /* Publishes the producer pair of a plane you write; the plane takes its own reference and
       NULL publishes it as host ready. Fatal on a plane the frame shares with another, for the
       reason gpuExecWritesPlane gives.

       Publish a value whose signal is already on its way: one the semaphore has reached, or one
       that work you have already handed to a queue or a stream will signal on its own. Never a
       value you still have to signal yourself from the host. Whoever waits on this pair may be
       holding locks inside the core -- freeing a frame waits out its producer, and cache
       eviction frees frames -- so a signal that needs a host thread to get around to it can be
       waiting on the very thread it is blocking. A signal already in flight cannot be, since
       nothing the host does afterwards can hold it up. gpuExecSubmit gives you such a value by
       construction, which is why an exec pool's timeline is checked rather than trusted; on
       your own timeline the ordering is yours to keep. Signal, or enqueue the signal, and only
       then publish. On a plane you handed to a foreign API this pair is also what taking it
       back waits on; see VSVulkanExportedMemory. On a plane of a frame from
       getExportableFrameFilter it is recorded as the completion of your foreign reads instead,
       for the core to wait on before the memory is reused; see there. */
    void (VS_CC *setGPUPlaneProducer)(const VSFrame *frame, int plane, VSGPUTimeline *timeline, uint64_t value) VS_NOEXCEPT;

    /* ---- Timelines, the semaphores producer pairs are published on ---- */

    /* A timeline of your own, for filters recording and submitting without the core's exec
       pool. Created with an initial value of 0, exportable where the device allows it, and
       returned with one reference which is yours to release -- in the free callback, without
       waiting for consumers, since planes you published it on hold their own. Returns NULL
       on error. */
    VSGPUTimeline *(VS_CC *createGPUTimeline)(VSCore *core, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    void (VS_CC *freeGPUTimeline)(VSGPUTimeline *timeline) VS_NOEXCEPT;
    /* Takes another reference, for handing the same timeline to something with its own
       lifetime. Every added reference needs a matching freeGPUTimeline. */
    void (VS_CC *addGPUTimelineRef)(VSGPUTimeline *timeline) VS_NOEXCEPT;
    /* The raw handle, to signal in your own vkQueueSubmit and to pass to exportGPUSemaphore.
       Valid for as long as you hold a reference. */
    VkSemaphore (VS_CC *getGPUTimelineSemaphore)(VSGPUTimeline *timeline) VS_NOEXCEPT;

    /* Waits on the host for a value of this timeline, which is how a filter recording and
       submitting for itself waits: vkWaitSemaphores on the raw handle is not, for the reason
       gpuExecWaitValue gives at length. A GPU reset force-signals every timeline past anything
       a waiter could be waiting for, this one included, so a bare wait returns success at once
       while the memory the dispatch was going to write still holds whatever it held before.
       This asks what value actually satisfied the wait, and retries an allocation failure
       inside the wait rather than reporting one as completion.

       Returns a VSGPUDrainResult. gdDrained means the submission really did complete, with
       the limit VSGPUDrainResult states;
       gdDeviceLost means the device was reset, so nothing is executing and everything the
       submission named may be destroyed; gdIncomplete leaves it queued and untouchable. See
       vsGPUDrainSafeToDestroy. Waiting for a value an exec pool's timeline has not submitted is
       fatal -- nothing would ever signal it -- while a timeline you signal yourself has no
       bound the core could check, since another thread may be about to submit the value.

       Not for waiting out a whole exec pool: gpuExecPoolWaitIdle does that and also promises
       the release callbacks have run. */
    int (VS_CC *gpuTimelineWaitValue)(VSGPUTimeline *timeline, uint64_t value, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* ---- Memory from the core's pool ---- */

    /* Scratch memory through the same sub allocator frame planes use, so it is counted
       against the VRAM limit, predicted by the thread pool's admission control and recycled
       through the size buckets — allocate/destroy per frame is cheap by design. Host visible
       requests come back persistently mapped. Returns NULL with the error set on failure.

       Lifetime is the caller's, with one rule: unlike frames, buffers have no producer pair
       anyone waits on, so destroy only after the submissions using the buffer have completed
       on the device, and at the latest in the filter's free callback. */
    VSGPUBuffer *(VS_CC *createGPUBuffer)(VSCore *core, VkDeviceSize size, VkBufferUsageFlags usage,
        VkMemoryPropertyFlags requiredFlags, VkMemoryPropertyFlags preferredFlags,
        VSVulkanBufferInfo *info, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    void (VS_CC *destroyGPUBuffer)(VSGPUBuffer *buffer) VS_NOEXCEPT;

    /* A region of the pool frame planes come from, for a resource this API has no constructor
       for. Create the resource, ask Vulkan what memory it needs, allocate it here, and bind
       against the memory and offset that come back:

           vkCreateImage(device, &imageInfo, NULL, &image);
           vkGetImageMemoryRequirements2(device, &reqInfo, &req);
           VSGPUMemory *mem = allocateGPUMemory(core, &req.memoryRequirements,
               VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, 0, &info, err, sizeof(err));
           VkBindImageMemoryInfo bind = { ..., image, info.memory, info.offset };
           vkBindImageMemory2(device, 1, &bind);

       Over a private vkAllocateMemory this buys everything the pool does: the region counts
       against the VRAM limit, is visible to admission control, is recycled through the size
       buckets and takes part in reclamation under pressure. The core cannot see a private
       allocation, so it can neither account for it nor make room for it.

       Bind at info.offset, not at the start of info.memory: the region sits inside a shared
       block, and images are aligned further inside it since their requirements are routinely
       coarser than the pool's regions (65536 for a small image where a large one asks 256).
       The distance is reserved, so any alignment is satisfied at a bounded overshoot.

       Two resources must not bind here and neither is detectable from the requirements, so
       both are the caller's to check: one created with external memory info, since these
       blocks are not exportable, and one whose VkMemoryDedicatedRequirements report
       requiresDedicatedAllocation, since a suballocated region is by definition not dedicated.
       Chain VkMemoryDedicatedRequirements onto the vkGet*MemoryRequirements2 call to see the
       latter; it is false for ordinary images and buffers and true mostly for external and
       platform specific formats. (prefersDedicatedAllocation is a hint, safe to ignore here.)

       A device whose buffer/image granularity is coarser than the pool's regions is refused
       rather than risking two resources sharing a granularity page.

       A freed region returns to the pool at once and may back another resource immediately, so
       freeing early aliases live data rather than faulting: free only once the submissions
       using the resource have completed, or hand it to gpuExecUsesMemory.

       Returns NULL with the error set. */
    VSGPUMemory *(VS_CC *allocateGPUMemory)(VSCore *core, const VkMemoryRequirements *requirements,
        VkMemoryPropertyFlags requiredFlags, VkMemoryPropertyFlags preferredFlags,
        VSVulkanMemoryInfo *info, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    void (VS_CC *freeGPUMemory)(VSGPUMemory *memory) VS_NOEXCEPT;

    /* Declares GPU memory the core did not allocate -- a CUDA pool, another Vulkan device, a
       video session -- into the same accounting, so the frame cache, admission control and
       the unified-memory brake all see it. The core cannot veto memory it does not own, so a
       reservation is never refused; what an increase buys is cooperation. When the declared
       bytes push the pool past its limit, cached GPU frames are evicted to a tenth under it
       and idle allocator blocks handed back to the driver before the call returns -- so
       reserve or update BEFORE the foreign allocation and the VRAM has actually been vacated.
       Shrinking and releasing just subtract.

       bytes is an absolute total, not a delta, so publishing what you hold makes drift
       impossible however the calls interleave. Concurrent updates are safe and the last total
       wins; negative counts as zero. release drops the reservation with the handle, ignores
       NULL, and belongs in the filter free callback -- it destroys the handle, so unlike an
       update it may not overlap another call on the same reservation.

       Only declare memory on the core's device -- match deviceUUID or deviceLUID from
       getVulkanCoreInfo -- and never declare bytes the core already accounts (createGPUBuffer,
       allocateGPUMemory, GPU frames) or they count twice. On unified memory this matters
       doubly, the pool's bytes and the host's being the same RAM. The exception is your imports
       of planes exportGPUPlane handed out, which belong in the declaration where
       VS_GPU_IMPORT_CHARGED_AGAIN is 1. Returns NULL on error. */
    VSGPUMemoryReservation *(VS_CC *reserveGPUMemory)(VSCore *core, int64_t bytes,
        char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    void (VS_CC *updateGPUMemoryReservation)(VSGPUMemoryReservation *reservation, int64_t bytes) VS_NOEXCEPT;
    void (VS_CC *releaseGPUMemoryReservation)(VSGPUMemoryReservation *reservation) VS_NOEXCEPT;

    /* ---- Shader compilation ---- */

    /* Runtime shader compilation, so plugins can ship readable kernel source instead of
       SPIR-V blobs. Pure CPU work through the statically embedded glslang: no device is
       touched and no optimizer runs, so precompiled -O blobs remain the alternative for
       whoever wants them and both feed the same pipeline creation path. Results are cached
       per core by source text — compiling the same kernel from many filter instances
       parses once and every handle shares the cached words, which also makes repeated
       compilation cheap enough to do per instance. Specialize by concatenating a #define
       preamble in front of the kernel body; there is no include handler. Compute stage
       only. Returns NULL with the log filled on failure, including for languages this core
       does not know. */
    VSGPUShader *(VS_CC *compileGPUShader)(VSCore *core, int language, const char *source,
        char *errorLog, int errorLogSize) VS_NOEXCEPT; /* VSGPUShaderLanguage */
    const uint32_t *(VS_CC *getGPUShaderCode)(const VSGPUShader *shader, size_t *sizeInBytes) VS_NOEXCEPT;
    void (VS_CC *freeGPUShader)(VSGPUShader *shader) VS_NOEXCEPT;

    /* ---- Exec pools ---- */

    /* Creates an exec pool on one of the core's queues. A pool on vqTransfer may only ever
       record copies, per VSVulkanQueueType; a pool anything is dispatched into belongs on
       vqCompute. Pools on either queue count what they retain against the in-flight budget
       below.

       The core sizes the pool's context
       ring itself, from its worker thread count (two to eight contexts) — how many
       recordings can even be concurrent is core knowledge, not filter knowledge, and how much memory queued
       submissions may pin is bounded separately: acquiring waits out the ring's oldest
       submission, and may additionally wait on the core's device-wide in-flight budget,
       which caps the total bytes submitted-but-unfinished work retains (a quarter of the
       VRAM limit) across all pools. Only submitted work counts, so a recording a thread
       already holds never gates that thread. Filters notice nothing but an occasional
       slower acquire when a graph runs far ahead of the GPU.
       A pool belongs to ONE filter instance: create it in the filter's create function,
       destroy it in the free callback, and never share one between instances. Nothing about
       a pool needs sharing -- the ring is sized for the threads one instance is called on,
       and a dependency between two of them travels as a timeline value rather than as a
       shared recording -- while sharing one costs the guarantee below, whose whole strength
       comes from the pool being idle at both ends of an instance's life.
       Destroy it in the filter's free callback; freeGPUExecPool drains the GPU first, so
       everything it still holds is released safely, and it returns only once every release
       callback the pool registered has run, so instance data can go right after it. A
       context still held by any thread at that point is fatal.

       Retained objects (read frames, scratch handed over with gpuExecUsesBuffer) are
       released once their submission is known complete: every submit on the pool reaps the
       other contexts' completed retentions (about one submission of lag while active), and
       the context's next acquire, pool destruction and the core's memory pressure sweeps
       cover the rest — so a pool gone idle does not park its last submissions' footprint.
       That reclamation is a pool-only property; references a filter retains privately on
       the raw path are invisible to the core and cannot be freed by pressure. */
    VSGPUExecPool *(VS_CC *createGPUExecPool)(VSCore *core, int queue /* VSVulkanQueueType */,
        char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    void (VS_CC *freeGPUExecPool)(VSGPUExecPool *pool) VS_NOEXCEPT;

    /* Blocks until every submission made through this pool has completed. Filters do not
       need this per frame — producer pairs make consumers wait on the device instead — but
       one shot setup work, such as uploading weights or tables a filter will read for the
       rest of its life, has to know the copy landed before recording anything that reads
       it. Also releases everything those submissions were keeping alive, and returns only
       once every release callback of the pool has run -- on this thread, or on the thread
       of a concurrent core sweep that reached it first, which is waited for; recordings
       other threads hold at the time are not submissions yet and are left alone. Call it
       from a thread holding no context of the pool: holding one is fatal, since that
       recording could never be covered and every worker doing the same would deadlock.

       It is a setup call, not a frame path one, and the promise about release callbacks is
       stated for that use: call it where no other thread can be using the pool. In the create
       function nothing else can, the node not existing yet; in the free callback nothing else
       may, the core never destroying a node while a frame request on it runs. Draining from
       inside getFrame while sibling threads acquire on the same pool is the case this does not
       cover -- an acquirer is briefly invisible to the reaping this promise is built on, so the
       wait may return just before that context's callbacks run. The GPU is idle either way;
       what can be early is only the host side release. Together with one pool per filter
       instance, the two rules leave no moment at which this call can race an acquire.

       Returns a VSGPUDrainResult, and the error is set for both failures: gdDeviceLost is
       still a failure of the promise above, it is simply the failure after which nothing is
       running any more. */
    int (VS_CC *gpuExecPoolWaitIdle)(VSGPUExecPool *pool, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* Waits for one value on the pool's timeline -- the signaledValue gpuExecSubmit handed
       back -- instead of for the whole pool, so the frames running beside this one keep their
       submissions flowing. This is how a filter waits on the host; do not wait on the timeline
       yourself with vkWaitSemaphores, because a bare wait cannot tell you the one thing that
       matters afterwards. A GPU reset releases every waiter by force-signalling the timelines
       past anything they could be waiting for, so a raw wait returns success immediately while
       the memory the dispatch was going to write still holds whatever it held before -- and a
       frame built from it looks perfectly fine. This checks the value that actually satisfied
       the wait, and retries an allocation failure inside the wait rather than reporting one as
       completion.

       Returns a VSGPUDrainResult. gdDrained means the submission really has completed, as
       far as any Vulkan query can establish it; VSGPUDrainResult states the one reset
       behaviour that defeats that and what a filter can do about it.
       gdIncomplete leaves it queued: nothing it names may be recycled, and only a later
       gpuExecPoolWaitIdle says otherwise. gdDeviceLost means the device was reset, so nothing
       is executing any more and everything the submission named is safe to destroy -- see
       vsGPUDrainSafeToDestroy, and do not fold the two failures together, which is how a reset
       comes to strand a filter's buffers and its pool for the life of the process.

       The value must be one this pool submitted: gpuExecSubmit's signaledValue, or anything
       below it. A value past everything the pool has ever queued is fatal rather than an
       unbounded wait on a signal that is never coming. A value the pool did allocate but whose
       submission failed is past checking and does hang, which is the one case worth being
       careful with by hand.

       For a timeline of your own rather than a pool's, gpuTimelineWaitValue. */
    int (VS_CC *gpuExecWaitValue)(VSGPUExecPool *pool, uint64_t value, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* The pool's timeline as the counted object setGPUPlaneProducer takes, for publishing
       producer pairs by hand on frames the pool does not know about -- the out of order
       producer case, where the submission that wrote a plane was submitted calls ago and
       gpuExecSubmit's signaledValue was saved for this moment. The pool holds its own
       reference, so publishing it needs no reference of yours; getGPUTimelineSemaphore
       gives the raw handle when exportGPUSemaphore needs one. NEVER signal that handle
       yourself: the pool allocates signal values under the queue lock at submit, and an
       external signal races them on a timeline where values must only increase. The pool
       compares the counter with the last value it submitted whenever it reaps, and a counter
       past it is fatal. Publish only values it has submitted: setGPUPlaneProducer with this
       timeline and a value past the newest gpuExecSubmit is fatal too, since no consumer
       could ever be released from waiting on it. */
    VSGPUTimeline *(VS_CC *gpuExecPoolTimeline)(VSGPUExecPool *pool) VS_NOEXCEPT;

    /* ---- Recording contexts ---- */

    /* Claims a context and begins recording; returns NULL with the error set on device
       loss. Every acquire must end in exactly one submit or abandon, from the thread that
       acquired; retaining, submitting or abandoning from any other thread is fatal, and so
       is any call with the handle after the submit or abandon that ended it.

       That last one is caught rather than prevented, and there is a case it cannot catch:
       the handle lives in its ring slot for the life of the pool, so what the check tests is
       whether the slot's recording belongs to the calling thread. It does not once the
       recording ends -- until the same thread acquires the same slot again, at which point a
       kept handle is indistinguishable from the fresh one, being the same object, and the
       call lands on a recording it was never meant for. Nothing in an ABI that hands back a
       bare pointer can tell the two apart. So do not keep a handle past the call that ended
       it: most of the time you will be told, and the rest of the time you will not. One
       context per thread, of this or any other pool: a ring has only two to eight contexts,
       so a second acquire from a thread already holding one could only wait for a slot that,
       once every worker did the same, nobody would ever release, and two threads each waiting
       on the other's full ring hang the same way. It is fatal instead, reported when the
       second acquire would wait. Nothing is lost by it: a dependency between two pools is
       carried by a timeline value, so submit and release the first recording, then acquire
       the second and wait on the value the first signalled. The in-flight budget counts
       submitted work only, so a recording never gates the thread holding it. */
    VSGPUExecContext *(VS_CC *gpuExecAcquire)(VSGPUExecPool *pool, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    /* The command buffer being recorded: put anything Vulkan allows into it. */
    VkCommandBuffer (VS_CC *gpuExecCommandBuffer)(VSGPUExecContext *context) VS_NOEXCEPT;

    /* Declares that this submission reads the frame: its planes' producer pairs become
       device side waits, and the frame is kept alive until the submission completes. Takes
       its own reference, so the caller still releases its own reference normally. Fatal on a
       frame with a plane handed to a foreign API; see VSVulkanExportedMemory. */
    void (VS_CC *gpuExecReadsFrame)(VSGPUExecContext *context, const VSFrame *frame) VS_NOEXCEPT;
    /* Declares that this submission writes the plane: gpuExecSubmit publishes the pool's
       (timeline, value) on it as the producer pair. The frame must own the plane outright:
       copying a frame shares its planes, and a GPU plane has no copy on write, so a write
       declared on a shared plane would land in the other frame as well. That is fatal here
       rather than silent. Copy a frame only to inherit properties you then keep; to write,
       take newGPUVideoFrame or newVideoFrame2 with the old frame as the property source.
       Sharing a plane this filter does not write stays fine, the check being per plane.
       Takes its own reference to the frame, as gpuExecReadsFrame does, so the caller still
       releases its own reference normally; it is dropped once the pair is published. Fatal
       on a plane handed to a foreign API, like gpuExecReadsFrame. */
    void (VS_CC *gpuExecWritesPlane)(VSGPUExecContext *context, VSFrame *frame, int plane) VS_NOEXCEPT;
    /* Hands a scratch buffer to the context, which destroys it once the submission
       completes. Ownership transfers; do not destroy it yourself. */
    void (VS_CC *gpuExecUsesBuffer)(VSGPUExecContext *context, VSGPUBuffer *buffer) VS_NOEXCEPT;

    /* gpuExecUsesBuffer for a bare region: the region stays out of the pool until the
       submission being recorded has completed, and its bytes count against the in-flight
       retention budget meanwhile. Ownership transfers; do not free it yourself. Release
       follows the ordinary retention timing described at createGPUExecPool -- reaped by the
       next submit on the pool, and by acquire, destruction or a pressure sweep otherwise --
       so what is guaranteed is that the region is never recycled early, not that it returns
       at a particular moment.

       The resource bound to the region is still yours to destroy, since this never saw it. A
       resource whose lifetime is the filter's -- created once, reused every frame -- is the
       easy case and wants no retention at all. One created per frame has to outlive its
       submission too, so keep those handles and destroy them when the filter is freed rather
       than trying to guess when the submission retired. */
    void (VS_CC *gpuExecUsesMemory)(VSGPUExecContext *context, VSGPUMemory *memory) VS_NOEXCEPT;

    /* Cleanup of your own on the retention list, for what the typed calls above cannot name.
       release(object) runs once the submission completes, on the schedule described at
       createGPUExecPool; call it between acquire and submit, and abandon runs it immediately.

       A per frame image is the case: the image, every view recorded against it and the region
       underneath must retire together, and one registration of a struct holding all three
       frees them in the right order -- views, image, then freeGPUMemory -- where a call per
       object could not express the ordering.

       bytes is what the object pins in device memory, counted against the in-flight retention
       budget from submit until release; pass 0 for host side bookkeeping, and do not double
       count bytes a typed call already counted for the same object.

       The callback runs on whichever thread reaps the submission, so it must be threadsafe.
       No core lock is held, so it may take its own locks and free whatever the object owns,
       and that is all it may do: acquiring a context, allocating GPU memory, and creating,
       freeing or waiting on a pool from inside a release callback are fatal, stopping the
       process with a message naming the call. The reaping thread may be one inside your own
       getFrame (a gated acquire or a failed allocation sweeps), so do not hold a lock across
       those calls that the callback also takes. */
    void (VS_CC *gpuExecRetain)(VSGPUExecContext *context, VSGPUReleaseFunc release,
        void *object, VkDeviceSize bytes) VS_NOEXCEPT;

    /* Ends recording and submits, allocating the timeline value inside the queue lock so
       signals reach the queue in increasing order, then publishes the producer pairs. The
       context is consumed either way, and the handle is dead from then on: using it again
       is fatal. Returns nonzero with the error set on failure.

       signaledValue, when non-NULL, receives the value this submission signals on the
       pool's timeline. Pass it to gpuExecWaitValue to wait for exactly this submission,
       which is what a filter reading results back on the host wants: gpuExecPoolWaitIdle
       also works but waits the pool's newest submission, so concurrent frames serialize on
       each other's work. Do not wait on the timeline with vkWaitSemaphores yourself -- a
       bare wait cannot distinguish a completed dispatch from a reset that force-signalled
       the timeline, and reports the second as the first. That holds for a timeline of your
       own as much as for a pool's, which is what gpuTimelineWaitValue is for. Filters that
       only produce planes never need any of it; the producer pairs carry the
       synchronization. */
    int (VS_CC *gpuExecSubmit)(VSGPUExecContext *context, uint64_t *signaledValue, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
    /* Gives up a recording without submitting: everything retained is released at once. */
    void (VS_CC *gpuExecAbandon)(VSGPUExecContext *context) VS_NOEXCEPT;

    /* ---- Sharing frames with other APIs ---- */

    /* Exports the allocation backing a GPU frame plane as an opaque handle; see
       VSVulkanExportedMemory for the identity, ownership, hand-off and synchronization rules.
       Only available when VSVulkanCoreInfo::exportHandleType is nonzero. Fails on CPU frames,
       missing planes and devices without export support. */
    int (VS_CC *exportGPUPlane)(const VSFrame *frame, int plane, VSVulkanExportedMemory *out,
        char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* Exports a timeline semaphore as an opaque handle; see VSVulkanExportedSemaphore. Use
       it on the readySemaphore of a plane taken with getExportableFrameFilter, always one of
       the core's own timelines, all of which are created exportable when the capability
       exists, or on your own timeline created with VkExportSemaphoreCreateInfo, to signal
       your producer pairs from the foreign API. On Windows, the first call for a timeline the
       core created -- its own or one from createGPUTimeline -- exports it, and every call
       returns a duplicate of that one handle. A semaphore you created yourself is exported
       anew on every call, which Vulkan allows only once per semaphore for an NT handle: export
       it once and duplicate that handle if you need more. Only available when
       VSVulkanCoreInfo::semaphoreExportHandleType is nonzero. */
    int (VS_CC *exportGPUSemaphore)(VSCore *core, VkSemaphore semaphore, VSVulkanExportedSemaphore *out,
        char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* Host waits every plane's producer pair AND makes the completed writes available
       outside the device's own domain, which is the part a bare producer wait does not give
       you: the spec only defines cross device visibility through external semaphores or an
       availability chain like this one, so skipping it means relying on driver behavior.
       Call once per frame before reading it through an exported handle; the cost is one
       submission round trip. Frames only read through Vulkan on the same device never need
       this — the producer pairs carry the dependency there. */
    int (VS_CC *waitGPUFrame)(const VSFrame *frame, char *errorMessage, int errorMessageSize) VS_NOEXCEPT;

    /* Takes a requested input frame for a foreign API, the way getFrameFilter takes one for the
       core's queues: it comes back with every plane handed to the foreign side with its
       contents and ready for exportGPUPlane, its producer pairs naming the hand-over. Wait on
       those, or call waitGPUFrame, before the foreign side touches it. Where nothing else holds
       the frame -- this filter its only consumer, requesting it rpStrictSpatial or
       rpNoFrameReuse, so the source keeps no cache -- the planes are handed over in place;
       otherwise the frame is copied first, one GPU copy per plane, on the compute queue. That
       copy is made once per frame and shared by every request of it, from any filter, for as
       long as the frame stays cached, so a temporal filter pays one copy per source frame
       rather than one per tap. A frame std.GPUUpload made is always copied where exportable
       memory cannot be host visible (AMD's Windows driver): its planes are left unexportable
       there, so the upload can write them directly.

       Like any input frame it is read only, on the foreign side as much as on the core's
       queues, and it never goes back to the core: returning it, or a frame that shares its
       planes or holds it in its properties, fails that frame with an error, and cacheFrame
       leaves such a frame out of the cache with a warning. Return a new frame, and take a frame
       you pass through with getFrameFilter instead, freeing that before calling this if you
       process it after all, so it can still be handed over in place. Keep it until the foreign
       reads are done, or publish their completion with setGPUPlaneProducer, which the core
       waits for before the memory is reused; the pair other requests wait on stays the
       hand-over's. Declaring it in an exec context is fatal, as for any plane handed over.
       Frames in its properties are not prepared: take an _Alpha frame as a clip of its own
       (std.PropToClip) and request that. Consumes one request of the frame for this activation:
       getFrameFilter and this return NULL for it afterwards unless it was requested again, as a
       temporal filter clamping at the clip's ends requests one frame twice, each request giving
       a frame. Call getFrameFilter first to keep the original as well, which makes this a copy.
       Fails on CPU frames and on devices without export support, and returns NULL for a frame
       that was not requested. Fatal when the calling thread holds an exec context, since
       preparing takes one of the core's. */
    const VSFrame *(VS_CC *getExportableFrameFilter)(int n, VSNode *node, VSFrameContext *frameCtx,
        char *errorMessage, int errorMessageSize) VS_NOEXCEPT;
};

#endif
