# Claude independent review - S2-I3 v0.3 and Stage 2 v0.7 revision

Project: VapourSynth-mpeg2Deblock. Baseline: 6e7b5c53df1c65775524936fc945c449cc9fa100.
Date: 2026-10-17. Both documents are DRAFT, not ratified.

The owner approved Git tracking of seven non-baseline development index files:
six new XP/SP/3A original+blocky indexes plus the existing LP_blocky scratch
index. This does NOT change the six immutable Stage 1 baselines, nor authorise
an S2-I3 implementation, index generation, staging, filtering or commit.

Please verify the revised documents against the ratified Stage 2 v0.6 and
`05_DECISIONS_v1_2.md`, and your review of v0.2/v0.7 (v0.1). Focus on:

1. MUST M1: no owner-identifying location/text in either committable draft.
2. MUST M2: admission now HARD structural + exact P-skip identity in owner's
   Windows BestSource pipeline (100% true block identity, fail on even one
   mismatched pixel); negative controls strictly less than 100%; >=200
   qualifying skipped MBs in >=10 P pictures; otherwise INCONCLUSIVE. All
   old S2-I2 3x3/phase thresholds remain unchanged reported diagnostics.
   Confirm MPEG-2 P-skip applicability, reference selection, edge cases,
   pixel/stride handling, negative-control enumeration and counts. Identify
   anything that must be clarified before implementing the gate.
3. Owner-approved seven Stage 2 non-baseline index files: actual reviewed
   Windows hashes and byte checks precede named installation; never rebase or
   replace Stage 1 six. Confirm media/identity and repository rules.
4. SHOULD S1: historical section 21 no longer operative; 5.2 accepts admitted
   non-baseline index; section 15 covers all four development pairs.
5. SHOULD S2: fair LP/LB comparisons use the same three XP/SP/3A folds for
   EVERY comparator arm, while independent full-four-fold J/O/X results
   remain separately available.
6. SHOULD S3: CV selects procedures (winner optimism); independent final
   external content first used at S2-I8, without retuning.
7. SHOULD S5: S2-I3 strictly fixed-QP only; S2-I4 comparison never executed
   early. Exact Q_fixed follows clip-wide all-MB medians.
8. Versioning: v0.7 is still a revised review draft (not v0.8); S2-I3 is
   v0.3. Ratified v0.6 original change log/history preserved byte-for-byte
   within v0.7, and patch correct against it. Any ratification or future
   installation is a separate owner approval.
9. No contact with EP, 2A, 4A or their blocky partners until S2-I8;
   MLS pair remain later controls; 704x576 3A is first-class source.

Please report MUST/SHOULD/OPTIONAL, propose minimal wording corrections, and
supply a final ready-for-owner-ratification verdict if possible. No code or
quality runs are requested. Reviewer FFmpeg P-skip evidence is NOT equivalent
to owner's authorised Windows BestSource admission.
