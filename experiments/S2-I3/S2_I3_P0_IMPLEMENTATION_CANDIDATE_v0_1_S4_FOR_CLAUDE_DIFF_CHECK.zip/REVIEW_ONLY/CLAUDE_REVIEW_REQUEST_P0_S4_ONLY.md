# Claude review request: S2-I3 P0 S4-only adjustment

Date: 2026-10-17
Status: S4-only candidate; owner Windows execution not yet started.
Source baseline: Git commit 35cd543b459a5856688f7c3795f73226e72311f8
Prior reviewed package: S2_I3_P0_IMPLEMENTATION_CANDIDATE_v0_1_REVISED_FOR_CLAUDE_DIFF_CHECK.zip
Prior clearance: Claude_P0_REVISED_CLEARANCE_AND_PROJECT_STATE_OF_PLAY_v0_1.md

## Precisely scoped change

Only REPO_OVERLAY/experiments/stage2/S2_I3_P0A_prepare_campaign_v0_1.bat differs
from the already CLEARED revised candidate. Its name and location remain unchanged.

Apply S4 exactly as Claude recommended:
- Define vspython = D:\TEST\Vapoursynth_x64_R81\python.exe alongside vspipe.
- Check this interpreter exists in P0A's existing existence-check loop.
- Run the two S2-I3 numpy-using test files with that exact interpreter and print
  a reason on nonzero result; the tests still precede vspipe preflight and scratch creation.
- Preserve the accepted plain `python "%regression%"` command.

The other six BAT files and all eight Python/VPY files remain byte-for-byte
identical to Claude's cleared candidate; the earlier rehearsal still applies.
No admission algorithm, threshold, source allow-list, index, hold-out or result
folder has changed. The owner-run sequence is byte-identical to the cleared one.
This candidate has NOT been run under Windows CMD here.

## Please check

1. Confirm that the one-file unified diff is exactly S4, with no unrelated edits.
2. Check CMD quoting, existence guard, Python path and fail-closed error handling.
3. Reverify ZIP hashes, line endings (BAT CRLF, PY/VPY LF), 15 overlay paths and
   unchanged owner-run sequence. REVIEW_ONLY files are not for installation.
4. If satisfied, confirm final clearance for the guided owner's P0A step.

The original P0 candidate is superseded; the previous revised candidate was
already CLEARED, and this S4 change is a SHOULD improvement, not a gate change.
