# Claude review request: S2-I3 P0A Windows isolated Python fix v0.1

## Review status and provenance

Baseline is the fully cleared S2-I3 P0 S4 candidate reviewed in
`Claude_DIFF_CLEARANCE_S2_I3_P0_S4_Candidate_v0_1.md`.
No repository installation or run is authorised by this package until
independent review and owner ratification.

## First real Windows P0A result

The owner copied all 15 implementation overlay files and ran P0A.
The six accepted index regressions and negative index cases passed.
The first new test failed before execution:

    ModuleNotFoundError: No module named 'stage2_i3_pskip_core_v0_1'
    ERROR: S2-I3 P-skip unit tests failed
    Final ERRORLEVEL=2

The portable VapourSynth Python has sys.flags.isolated=1,
sys.flags.safe_path=True, and a `python314._pth` file.  Its sys.path
does not contain the script directory.  The core module exists at
its expected location; explicitly inserting `experiments/stage2`
into sys.path makes the import work.  P0 scratch folder was absent
following the failure, as intended.

## Exact change

Exactly one implementation file changes:
`experiments/stage2/S2_I3_P0A_prepare_campaign_v0_1.bat`.
Replace the two direct VapourSynth-Python unit-test invocations with
`python -c` commands invoking `runpy.run_path` and prepending the
absolute test-file directory to `sys.path`.  `sys.argv=[script]`
prevents `unittest.main()` from treating the path passed after `-c`
as a test name.  Each command retains the previously reviewed
`if errorlevel 1` failure guard and message.

No edits to unit-test sources, admission Python, VPY, other six BATs,
allow-list, index checks, thresholds, hold-outs, or Stage 1 freeze.
The accepted reader-regression command remains unchanged.
No modifications to the portable interpreter, `_pth` file,
PYTHONPATH, or environment-wide Python installation.

## Reproduction and checks by ChatGPT

The 15 overlay members were rebuilt from the exact previously cleared
S4 ZIP.  The other 14 implementation files and reviewed proposed owner
run sequence remain byte-for-byte identical.

The new invocation pattern was executed from an unrelated working
directory using system Python in isolated mode (`python -I -c`),
against the extracted unchanged test suite and sibling modules.
Results: 9/9 P-skip PASS and 5/5 pair PASS (return code 0 each).
This simulates isolated sys.path; it is not an execution in the
owner's Windows portable Python or a Windows CMD runtime test.

Corrective Python command embedded by both invocations:

    import os,sys,runpy; script=os.path.abspath(sys.argv[1]); sys.argv=[script]; sys.path.insert(0,os.path.dirname(script)); runpy.run_path(script,run_name='__main__')

## Questions for independent review

1. Does the single-BAT change solve the owner's confirmed
   `python314._pth` import-path restriction without modifying
   the portable Python installation or test logic?
2. Confirm `sys.argv=[script]`, `runpy.run_path(...,run_name='__main__')`,
   sibling imports, and propagated `unittest` exit status behave as
   required in Windows Python 3.14 embeddable distribution.
3. Audit the two CMD `-c` quoting forms, and confirm failure remains
   fail-closed with unchanged exit code/message handling.
4. Diff all 15 implementation files against the S4-cleared baseline:
   exactly one BAT must change; the other 14 must match exactly.
   Recheck line endings and SHA-256 manifest.
5. If cleared, recommend replacing ONLY this one BAT in the owner's
   already-installed overlay, then rerunning P0A from a fresh
   scratch state (which the owner confirmed currently absent).

Do not proceed to P0B before P0A passes on Windows.  No filtering.
