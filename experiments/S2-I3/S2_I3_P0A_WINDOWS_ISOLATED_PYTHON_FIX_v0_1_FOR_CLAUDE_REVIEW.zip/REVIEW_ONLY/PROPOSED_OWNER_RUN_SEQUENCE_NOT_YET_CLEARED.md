# PROPOSED owner Windows steps (for Claude review ONLY)

These are sequence notes, not instructions to execute now.
After Claude approves, ChatGPT will issue ONE small CMD block at a time.

0. Confirm repository main HEAD equals approved source identity and clean index.
   Inspect what is staged. Do not overwrite/commit accepted existing files.
1. Unzip only REPO_OVERLAY/experiments/stage2 additions into a temporary staging
   folder, inspect exact file names and SHA-256. Use named-file copy into the
   experiments/stage2 folder only after Claude authorises candidate execution.
2. Run P0A_prepare_campaign once. It performs S2-I1 six-index metadata
   regression and vspipe environment preflight, then creates a fresh owned
   scratch folder under TEMP. Never decode any protected hold-out media.
3. Run P0B_generate_index exactly one at a time for XP, XP_blocky, SP,
   SP_blocky, 3A and 3A_blocky. Compare Windows generated hashes to the six
   independently rehearsed Linux hashes. Preserve logs and .idx; remove each
   owned regular .m2v on success or failure.
4. For LP_blocky, verify prior S2-I2 scratch candidate has the accepted hash,
   then P0B_copy_LP_blocky copies the exact bytes. If unavailable, STOP and
   agree with Claude whether to rerun the previously accepted S2-I2 preparation
   BAT before copying. The original LP index is immutable in VHSC_samples.
5. Run P0C_admit_source separately for each of the eight source labels.
   Admission uses BestSource native luma. Stop on any FAIL or INCONCLUSIVE.
6. Run P0D_diagnostics separately for each source. Old S2-I2 results are
   descriptive only, even when their historical gating score is inconclusive.
7. Run P0D_pair separately for XP, SP, LP and 3A (after both encodes admitted).
   Stop on failed or inconclusive frame correspondence.
8. Run P0D_summary. Check P0_summary.json and per-source evidence. READY
   is a numerical report only, NOT authorisation to begin filtering.
9. After owner/Claude review, separately COPY the seven admitted index bytes
   to VHSC_samples, verify hashes, and stage/commit seven EXACT named paths;
   never regenerate between admission and Git tracking. Frozen six stay frozen.

All scratch outputs must remain private. Never commit .mpg or .m2v, decoded
pixel data, review packages, or temporary reports unless independently cleared.
