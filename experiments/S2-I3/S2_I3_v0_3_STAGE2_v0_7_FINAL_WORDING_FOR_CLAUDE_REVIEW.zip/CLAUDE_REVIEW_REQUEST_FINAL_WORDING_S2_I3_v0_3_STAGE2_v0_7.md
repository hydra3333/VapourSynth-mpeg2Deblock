# Claude - final wording-only diff review request

Date: 2026-10-17
Project: VapourSynth-mpeg2Deblock
Baseline repository: 6e7b5c53df1c65775524936fc945c449cc9fa100

Status: REVIEW DRAFT - NOT YET OWNER-RATIFIED OR INSTALLED. No S2-I3 implementation, scratch-index generation, quality or filtering execution authorised by these documents.

Please compare the two revised documents (same version numbers: Stage 2 v0.7, S2-I3 v0.3) against the previous S2-I3 v0.3 / Stage 2 v0.7 ZIP you already reviewed. Confirm changes are exclusively:

- S1: 100% in an executed negative control => INCONCLUSIVE - QUALITY BLOCKED, not registration FAIL; structural fail or any true-position mismatch => HARD STOP. Mirror in S2-I3 section 3.1.
- S2: define P-skip as an index SKIPPED macroblock due to macroblock_address_increment in a P frame picture; exclude other NONE states including INTER CBP=0 with possible motion.
- S3: identify immediately preceding I/P picture in display order (most recently decoded anchor); display-order next/previous controls; consistent S2-I3 wording.
- S4: shift both current and reference windows by the same offset, count only wholly in-bounds windows.
- Optional O1: remove adjacent duplicate horizontal rule.

Review checks: exact original 3x3/column/row diagnostic thresholds, content-group folds and source assignments, Q_fixed, hold-out protections, historical Stage 2 v0.6 change-log text, Stage 2 v0.7 authority status, the seven approved non-baseline indexes and S2-I3 fixed-QP-only boundary remain unmodified. Check D-23 identity and ASCII/CRLF. Two .diff files are review-only and MUST NOT be included in the eventual repository commit.

Please issue either CLEAR FOR OWNER RATIFICATION or bounded remaining wording corrections. On clearance, owner can ratify the two design documents. Installation should then be a separate named-file documentation commit replacing v0.6 under D-23. The seven non-baseline indexes will be tracked only after authorised Windows generation, hashing and independent validation; do not stage them with this documentation commit.

The owner has requested step-by-step Windows CMD guidance for later installation and preflight. ChatGPT will provide one guarded command block at a time, after clearance and ratification, without running S2-I3 implementation prematurely.
