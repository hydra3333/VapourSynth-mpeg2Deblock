# Claude review request - S2-I3 implementation plan v0.1

Project baseline: `35cd543b459a5856688f7c3795f73226e72311f8`.

The owner explicitly authorised S2-I3 implementation on 2026-10-17. ChatGPT is proposing the first code increment P0 (admission and provenance only), deliberately without filtering. Review against the *installed, ratified* Stage 2 v0.7, S2-I3 v0.3, Stage 1 authorities, accepted S2-I1/S2-I2 sources, `NOTICE.md` and the owner's Git status as available. Do not infer that previously delivered review drafts are installed authoritative text.

Please verify:

1. No breach of protected EP/2A/4A content, fixed-QP-only scope or immutable six Stage 1 `.idx` files.
2. Exact MPEG-2 P-skipped coding-state definition, prior I/P anchor in display order, 16x16 native Y8 comparison, 24 spatial negative controls, temporal wrong-reference definitions, fail-versus-inconclusive ordering, floor 200 across >=10 eligible P pictures.
3. Source/index generation and log-safety details on Windows CMD, including no two-process logging race and no file overwrite outside named owned scratch.
4. Whether the proposed pair mapping gate is precise enough *before coding*, and its separation from P-skip registration.
5. Whether new source-specific S2-I2 numerical results are clearly diagnostics rather than admission gates.
6. Whether P0 code files/checkpoints are sufficiently bounded for independent implementation review and owner-run steps.
7. Any risk from citing/exercising accepted tool versions, reader semantics or runtime paths incorrectly.

Classify findings MUST/SHOULD/OPTIONAL and suggest exact revised wording where possible. The owner prefers Claude and ChatGPT resolve routine design and QA choices without repeated arbitration. Do not run filtering and do not touch hold-out media. Implementation code has not yet been delivered. Your feedback gates ChatGPT's P0 code candidate; do not ask the owner to run commands on the basis of this plan alone.
