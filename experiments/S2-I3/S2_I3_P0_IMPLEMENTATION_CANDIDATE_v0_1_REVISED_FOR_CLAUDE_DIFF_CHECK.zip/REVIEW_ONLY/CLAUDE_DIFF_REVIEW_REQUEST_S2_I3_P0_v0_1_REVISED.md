# S2-I3 P0 v0.1 - corrected candidate for Claude diff-only clearance

Date: 2026-10-17
Status: REVIEW CANDIDATE. NOT CLEARED FOR OWNER WINDOWS RUN.
GitHub source baseline: 35cd543b459a5856688f7c3795f73226e72311f8
Compared candidate: S2_I3_P0_IMPLEMENTATION_CANDIDATE_v0_1_FOR_CLAUDE_REVIEW.zip
Review source: Claude_REVIEW_OF_ChatGPT_S2_I3_P0_Candidate_v0_1_v0_1.md

## Exact change scope

The 15 REPO_OVERLAY files retain their original v0_1 names. Exactly six BATs have
changed; the other BAT and all eight Python/VPY files remain byte-for-byte
identical to the previously reviewed candidate. The new REVIEW_ONLY patch is a
unified diff of the six BAT changes. No existing repository files are modified.

- M1: the single erroneous parenthesis in P0D_diagnostics error echo is removed.
- S1: clear source_name/index_name before for /f captures in P0B, P0C and
  P0D_diagnostics; clear stem in P0D_pair. Remove the ineffective if errorlevel
  checks immediately after for /f, while retaining non-empty capture gates.
- S2: add reason-bearing ERROR echoes to all specifically identified silent
  exit sites in P0B, P0C, P0D_diagnostics and P0D_summary.
- S3: P0A checks both new S2-I3 test scripts exist and runs the P-skip and pair
  suites after reader regression, before vspipe environment preflight.

No OPTIONAL item O1-O6 was adopted. No filtering, source assignment, hold-out,
index format, evidence threshold or P0 admission logic was changed. All eight
ratified development sources remain the only admissible input names.

## Validation in ChatGPT environment

- All 15 overlay paths and all nine unchanged overlay files checked against the
  previous candidate; exactly six BAT diffs as listed in the patch.
- BAT files: US-ASCII CRLF. Python/VPY: LF byte-identical to previous candidate.
- The two unchanged Python test scripts independently executed: 9/9 P-skip
  tests and 5/5 pair tests PASS. They will additionally be run by P0A on Windows.
- Python/VPY logic has not been edited. The unchanged files retain all Claude's
  Linux/BestSource rehearsal evidence; this is NOT a Windows CMD execution test.

## Requested Claude review

1. Diff the six revised BATs against the previous v0.1 candidate. Confirm only
   M1 and S1-S3 were applied, and assess Windows CMD parsing and control flow.
2. Confirm that P0A unit-test file checks/commands are located after reader
   regression and before environment preflight; verify failure stops P0A.
3. Confirm error echoes and cleared captures behave fail-closed, especially
   when print-index-path produces no output or caller environment is polluted.
4. Verify fresh manifest hashes, newline policy, no identity text and the exact
   15 REPO_OVERLAY names. Keep all REVIEW_ONLY content out of Git.
5. If satisfactory, CLEAR this exact corrected candidate for owner-run Windows
   P0, subject to the small-step guided instructions and the ratified gates.

Please report any MUST/SHOULD corrections precisely. The owner's Windows P0
admission has NOT run. The seven non-baseline indexes are NOT to be committed
until the separate post-admission verified tracking step. Protected hold-out
media, source files and frozen Stage 1 indexes are untouched.
