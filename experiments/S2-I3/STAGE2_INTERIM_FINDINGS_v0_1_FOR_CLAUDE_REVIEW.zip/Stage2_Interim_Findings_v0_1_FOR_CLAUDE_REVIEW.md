# Stage 2 - Interim Empirical Findings and Open Hypotheses

**Document:** proposed `docs/REPOSITORY/Stage2_Interim_Findings_v0_1.md`  
**Version:** 0.1  
**Date:** 2026-10-17  
**Status:** DRAFT FOR CLAUDE REVIEW; NOT RATIFIED; NOT INSTALLED  
**Repository reference:** `35cd543b459a5856688f7c3795f73226e72311f8`  
**Disposition:** evidence/provenance note only; neither a new decision authority nor an amendment to Stage 2 v0.7 or S2-I3 v0.3.

## 1. Purpose, authority boundary and reporting rules

Retain useful early Stage 2 measurements, their limits, and falsifiable follow-up questions before S2-I3 quality experimentation has completed. The existence of substantial experimental results not yet belonging to a closed gate report is the proposed demonstrated need for this ONE additional document under D-05. Do not duplicate every review transcript or create a generic document archive.

Current authorities are `05_DECISIONS_v1_2.md` (D-05, D-09, D-13, D-20, D-21, D-23, D-24, D-26), `06_DEBLOCK_CONCEPT.md` v1.2 (K-02, K-03, K-07, K-08, O-04, O-09, O-14), `Stage2_Experiment_Design_v0_7.md`, and `S2_I3_Full_Data_Multi_Source_Experimental_Design_v0_3.md`. Accepted prior results are in `S2_I2_Evidence_and_Gate_Report_v0_1.md`. This report cannot supersede them.

Evidence classifications in this draft:

- **REVIEWER-REPORTED MEASUREMENT:** reported by Claude; reproduce or audit raw scripts/index counters before upgrading the evidence level. Not yet an owner-ratified K-nn knowledge item.
- **MECHANISTIC INTERPRETATION:** inferred explanation consistent with existing codec geometry; distinguish codec fact from experiment-specific implications.
- **HYPOTHESIS / PROPOSED TEST:** unresolved assertion, not an accepted performance result.

The intended reviewer should distinguish transform geometry in the bitstream from the pixel-support geometry that is safe to filter. Use precise boundary naming: a vertical boundary is at a fixed x; a horizontal boundary is at a fixed y.

## 2. Provenance and limits

- Source A: `Claude_ANALYSIS_OF_Paired_Reference_Metric_and_Sample_Pool_Extension_v0_2.md`, supplied by the project owner on 2026-10-17. Claude reports FFmpeg/BestSource Linux rehearsal over all four original/blocky development pairs, without retaining media.
- Source B: the project owner's 2026-10-17 relay of Claude's follow-up transform-statistics analysis of the eight development `.idx` files. Claude described this as index-metadata-only, with no media access. Request Claude's full repeatable counting procedure, population/denominator and any correction to boundary-transition nomenclature before the observations become accepted repository knowledge.
- Stage 2 v0.7 and S2-I3 v0.3 already define mixed geometry, source groups and pair-correspondence rules; this note supplies later quantitative observations, not new geometry policy.
- No filtering conclusion is supported by the owner-run Windows P0 pipeline yet. Claude's exploratory filters were crude probes, NOT candidates/accepted S2-I3 implementations. No hold-out quality data were examined for these findings.

## 3. Mixed transform-state statistics (reviewer reported, index metadata)

Percent of all macroblocks for the original encodes, by applicable coded residual transform geometry:

| Development original | FIELD % | FRAME % | NONE % | Frames containing both FRAME and FIELD % | Reported adjacent macroblock transform-type transitions at a vertical boundary % |
|---|---:|---:|---:|---:|---:|
| XP | 70.9 | 12.1 | 17.0 | 99.1 | 15.7 |
| SP | 73.4 | 5.9 | 20.8 | 99.5 | 8.5 |
| LP | 52.7 | 23.0 | 24.3 | 97.1 | 24.0 |
| TEST 3A | 7.6 | 67.9 | 24.5 | 92.3 | 10.0 |

Values and the boundary-transition category above are reproduced as relayed, not independently recalculated; percentages may not sum to exactly 100 because of rounding. Claude to confirm transition denominator, whether NONE boundaries participate, and the precise directional definition.

**Mechanistic interpretation:** FRAME and FIELD residuals have different row-domain transform organisations; adjacent macroblocks can therefore require different transform-seam treatment within one output frame. Per-macroblock FRAME/FIELD/NONE geometry and field-parity-aware sample access are already required by the concept. An MB-state transition at a *vertical* macroblock boundary does NOT mean that the location of that outer vertical boundary changes; it means the internal horizontal-transform geometry on the adjacent sides can differ. Do not treat FRAME-DCT as automatic permission to mix different temporal fields during post-filtering.

**Hypothesis to test:** Cross-content performance of a uniform geometry model will differ materially between field-dominated LG sources and frame-dominated TEST 3A. Compare per-index geometry and controlled uniform-geometry baselines with comparable optimisation budgets and source grouping. This has not been demonstrated with a full candidate kernel.

## 4. Paired original/blocky measures (reviewer reported exploratory pixels)

The original is a higher-quality *encoded reference*, NOT a pristine uncompressed ground truth. The `_blocky` encodes are Q62 and have lost detail that a deblocker cannot reconstruct.

| Content group | Baseline paired luma MAE: all | Boundary | Interior | H blockiness excess: original / blocky | V blockiness excess: original / blocky |
|---|---:|---:|---:|---|---|
| XP | 3.567 | 3.745 | 3.428 | 1.614 / 2.313 | 1.011 / 2.145 |
| SP | 3.266 | 3.436 | 3.134 | 1.950 / 2.816 | 1.472 / 2.879 |
| LP | 4.355 | 4.588 | 4.173 | 2.319 / 3.169 | 1.189 / 2.221 |
| TEST 3A | 5.512 | 5.748 | 5.329 | 1.726 / 3.352 | 3.715 / 6.197 |

H/V labels follow Claude's source report; require explicit definitions of sample direction versus line orientation and field-aware V treatment in a reproducible metric implementation. The excess metric is boundary-step *minus* interior-step, not their ratio. Claude reported the ratio diverged for perfectly flat Q62 interiors. No such ratio is proposed as a gate.

Claude's exploratory local blur tests reported horizontal-only paired-MAE changes of +1.2%, +1.3%, -0.2%, +2.3% across XP/SP/LP/3A; field-aware vertical probes near zero or worse; and conventional frame-line vertical blurring as **harmful**, losing 7.5%-26.8% against the paired MAE measure and producing 1.051-2.244 MAE on clean originals. These probes imposed global geometry; they do NOT falsify per-MB-index-driven vertical filtering.

**Proposed objective for later experimental consideration, NOT adopted:** separately by orientation and relevant transform stratum, move a blockiness-excess score toward the original's own nonzero value; retain paired original-reference MAE (all, boundary, interior), unfiltered-original no-harm checks and the owner's visual assessment as safeguards. Validate metrics against over-smoothing and real edges. Do not silently replace the predeclared S2-I3 selection rubric with this suggestion.

## 5. NONE / predicted content and metadata limit

`06_DEBLOCK_CONCEPT.md` K-08 and O-04/O-09 already flag motion-compensated blocking and off-current-grid locations. Claude reports that Q62 encodes are NONE-dominated: for XP, NONE reportedly rises from approximately 17% original to 74% blocky. NONE denotes **absence of current coded residual transform geometry**, not absence of visible blocking. It is not synonymous with SKIPPED, and may include INTER with CBP zero.

The current eight-byte-per-MB index records motion type/direction metadata, not actual motion-vector components. A residual-grid-only filter may miss off-grid blocking inherited from motion-compensated references. Prediction may involve fractional-pixel interpolation; it is not necessarily a simple rigid displaced 8-pixel grid.

**Open hypothesis:** classify NONE and NONE-touching boundaries separately and measure residual/no-harm results by I/P/B before considering added metadata. Do NOT commit to `.idx2` or motion-vector capture without experimental evidence meeting D-13's higher bar for motion-data inclusion. Stage 1 remains frozen.

## 6. Follow-up test proposals and sequencing (none authorised by this note)

1. Resolve the P0 candidate review findings (M1 Windows BAT parenthesis fix plus S1-S3); Claude rechecks the resulting candidate. Complete the Windows P0 preflight on the **ratified eight** with no quality filtering; keep all current admission criteria unchanged.
2. During authorised S2-I3 kernel evaluation, record direction-separated and FRAME/FIELD/NONE-stratified scores, plus original/no-harm evidence, under the existing cross-validation/hold-out controls. If a new selection objective would change the ratified rubric, propose a versioned Stage 2 amendment first.
3. Under separately authorised S2-I4 or later, test the fixed-vs-indexed-QP estimands with H/V breakouts and consider intermediate-QP re-encodes (e.g. Q25-Q40) of already-admitted content. Their effect, and treatment of correlated variants, are unproven.
4. Independently characterise the new 6A/7A home-recording pairs before proposing new source roles. The owner has allowed an OPTIONAL, separate, bounded public-repository commit of the four .mpg recordings during active development; see section 6.1 for its permanence caveat. Claude can independently characterise the committed recordings; the separately drafted characterisation BAT is no longer needed and must not be run. Do not admit these clips through the current eight-source allow-list, and preserve EP/2A/4A hold-outs until S2-I8.
5. After review and owner ratification of reproducible measurements, move *general* new knowledge into a narrowly revised `06_DEBLOCK_CONCEPT` (next revision, versioned filename under D-23), retaining K-nn evidence levels and tracking source; otherwise leave numerical findings in the evidence record. The future Stage 2 feasibility gate report should reconcile and supersede this interim note's conclusions, not simply append a second incompatible verdict.

### 6.1 New-source provenance, media decision and independent verification (2026-10-17 update)

The owner removed four pairs with duplicated existing content. Claude reports a
SHA-256 grouping over 20 remaining `.mpg` files, finding 20 different hashes;
16 earlier clips retain their assignments and two new content pairs remain.
Reported new source hash prefixes (informational only; full hashes required
for staging and provenance):

| New file stem | Original SHA-256 prefix | Blocky SHA-256 prefix |
|---|---|---|
| `TEST_6A_home_576i` | `0F8656F69591EC69` | `0D53680AB8037FDA` |
| `TEST_7A_home_576i` | `C68E209FDE087D7A` | `17ABBC2C4EEB85AF` |

The owner has indicated the four personal recordings MAY be committed to the
public project repository during active development, in a separately reviewed
commit of exactly four named media paths, not mixed with P0 or the later
seven-development-index commit. No such commit has been made here. Existing
`.gitattributes` settings reportedly leave these files binary without EOL
conversion; Claude should independently check the actual commit and full hashes.

**Public-repository persistence caution:** Even though `NOTICE.md` calls for
removing Restricted Media from the working tree at Development Closure and a
subsequent history purge, `git rm` alone cannot remove historical blobs. Nor
can any later history rewrite guarantee removal from third-party clones, forks
or caches. The owner should knowingly accept that exposure before the public
push. These logistics do not revise NOTICE or assign the new content to
experimental folds.

Once media is accessible, Claude proposes independent frozen-inspector indexing
and checks of geometry, picture structure, frame counts, q_scale_type, all-MB
Q_fixed, FRAME/FIELD/NONE mix, P-skip counts, negative controls and original/
blocky pair correspondence. Expected larger clip lengths are estimates until
characterised. Cross-validation reweighting by content group and by frame
count is a proposed amendment, NOT an operative S2-I3 change.

The separately drafted `S2_I3_P0B_characterise_new_source_v0_1.bat` route is
**stood down** in view of direct independent characterisation; do not install
or run that unreviewed draft. The current P0 allow-list remains the original
eight sources. No S2-I3 metric, source role, threshold or gate is changed here.

## 7. Open reviewer questions / proposed resolution

- Confirm all four transform counts, frame-with-both percentages and transition denominators directly from the `.idx` reader or analyzer; identify whether transitions involve FRAME/FIELD only or NONE as well.
- Confirm orientation names and no-reference blockiness excess definition, including how comparison lines are chosen and which pixels are included.
- Confirm no field mixing in any proposed kernel: FRAME/FIELD **DCT coding** does not independently determine safe interlaced **pixel access**.
- Distinguish codec-semantic claims already covered by K-02/K-03/K-07/K-08 from new source-specific findings. Do not create redundant K numbers for mere percentages.
- Confirm that this single interim evidence note meets D-05's demonstrated-need criterion, rather than creating a new generic knowledge hierarchy.

## 8. Change log

- v0.1 (2026-10-17): first draft consolidating the owner's relayed Claude findings, with evidence-status boundaries and forward tests. No ratification or change to operating authority.
