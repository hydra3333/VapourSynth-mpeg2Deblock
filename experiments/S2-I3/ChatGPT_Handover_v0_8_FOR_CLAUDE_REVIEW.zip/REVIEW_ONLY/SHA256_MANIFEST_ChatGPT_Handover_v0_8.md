# ChatGPT role handover v0.8 review package - SHA-256 manifest

ce2299e9c1a8061e451961064fff8360cdc7b5528666d20f94e2c0015d16b409  HANDOVER_CANDIDATE/docs/HANDOVER/ChatGPT_Handover_To_Future_ChatGPT_MPEG2_Deblocking_Project_v0_8.md
1065950cc4004f5c8093c28a601637442898ae4b7773a37c1bf1b99dd46a6e1f  REVIEW_ONLY/CLAUDE_REVIEW_REQUEST_ChatGPT_Handover_v0_8.md

Only the handover file is a proposed eventual repository file; REVIEW_ONLY stays out of Git. This archive is a review candidate and has not been installed.
