# Claude review request - ChatGPT role handover v0.8

**Date:** 2026-10-17
**Baseline:** `35cd543b459a5856688f7c3795f73226e72311f8`
**Subject:** `ChatGPT_Handover_To_Future_ChatGPT_MPEG2_Deblocking_Project_v0_8.md`
**Disposition:** review candidate only, **not installed**. Proposed next current-tree file is `docs/HANDOVER/ChatGPT_Handover_To_Future_ChatGPT_MPEG2_Deblocking_Project_v0_8.md`; accepted install must remove superseded v0.7 under D-23, after owner ratification.

This is a **full replacement**, not a short appendix to the 2026-10-14 v0.7 handover. Its purpose is to preserve continuity and a correct picture of what the current ChatGPT chat knows, including uncommitted decisions/candidates and negative knowledge. It is not new normative authority.

## Please review

1. **As-at accuracy and no premature clearance:** current repo HEAD `35cd543...`; S2-I1 and S2-I2 closed; v0.7/v0.3/v0.7 repo authorities ratified; owner's **subsequent** S2-I3 implementation/P0 authorisation distinct from v0.7's earlier design-only as-at. The P0 REVISED package is Claude-CLEARED; **S4 variant is NOT YET CLAUDE-REVIEWED**. No Windows P0 execution, overlay commit, index commit or filtering acceptance is claimed.
2. **Preserve technical exactness:** current four development original/blocky pairs, fixed-QP medians, 704 width for 3A, six frozen vs seven future non-baseline index bytes/hashes, P-skip counts, pair decisive-frame counts, source-level constraints, no hold-out leakage.
3. **Procedure and transition safety:** owner small-step CMD path, `P0A` -> six `P0B` generations -> LP_blocky existing scratch copy -> eight `P0C` -> eight P0D diagnostics -> four paired proofs -> P0D summary -> *separate* index-tracking commit. No owner command execution before package clearance. `READY` != permission to filter.
4. **Three independent tracks:** P0 critical path vs parked 6A/7A material vs deferred knowledge findings; status and supersession table should not promote a draft into authority.
5. **Known erroneous measurements and correct concepts:** corrected horizontal (fixed y) versus vertical (fixed x) boundary directions, coded-pair denominator vs all-pair denominator, per-transform-state seam-local paired MAE. Do **not** carry Claude's known-error analysis v0.2 conclusion forward; no duplicate K-items or unapproved metrics introduced.
6. **Continuity completeness:** compare against `ChatGPT_Handover_To_Future_ChatGPT_MPEG2_Deblocking_Project_v0_7.md` for durable migration/build, policy, interlace/chroma, ownership and Windows CMD lessons that would be costly to lose. Report omitted material that genuinely belongs in a role handover, not history already owned elsewhere.
7. **Mechanical checks:** D-23 versioning/predecessor disposition, identity-neutral wording, US-ASCII/CRLF, no unintended repo writes, SHA manifest, and whether naming as a candidate versus intended installed filename is unambiguous.

Please distinguish MUST corrections from SHOULD/optional editorial changes, and return a clearance verdict. Do not request owner Windows P0 steps as part of reviewing this handover.

## Explicit non-changes

No repository files, source/index bytes, P0 implementation packages, Stage 2 experimental criteria, hold-out roles, public-media permissions, and no project decisions are altered by this draft. The owner's S4 package has **not** been given to Claude yet per the latest owner statement; this review request is independent of S4.
