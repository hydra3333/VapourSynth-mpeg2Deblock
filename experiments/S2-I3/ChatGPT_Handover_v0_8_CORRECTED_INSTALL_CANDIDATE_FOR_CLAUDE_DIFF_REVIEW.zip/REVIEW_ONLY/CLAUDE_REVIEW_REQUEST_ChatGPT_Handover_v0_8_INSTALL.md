# Claude diff-only review request: ChatGPT role handover v0.8 install candidate

Baseline: `35cd543b459a5856688f7c3795f73226e72311f8`.
Input review: `Claude_REVIEW_OF_ChatGPT_Handover_v0_8_v0_1.md`.

## Requested checks

1. Verify that review M1/M2 and SHOULD S1-S5 are fully applied to the single Markdown install candidate and no technical S2-I3/P0 data or scope has changed.
2. Review the deliberately additional verbatim agreed common continuity-purpose quotation; confirm it matches `docs/HANDOVER/ROLE_HANDOVER_CONTINUITY_PURPOSE_TEXT_FOR_BOTH_ROLES.md`. This was identified as a missing continuity element in ChatGPT's preceding reply before Claude reviewed v0.8.
3. Optional O1: short missing commit entries added to the explicitly abbreviated history; verify from Claude v0.10.
4. Check replacement pointers are live: V1-V4 via `06_DEBLOCK_CONCEPT.md`, companion Claude v0.10 delivered as draft, and v0.7 will be deleted from current tree in the same commit.
5. Verify US-ASCII / CRLF / no owner identity or location / no trailing whitespace / hashes. Check no `REVIEW_ONLY` file is to be installed.
6. Confirm install-time wording remains accurate after an ADD of v0.8 and DELETE of v0.7; expected `1 A / 1 D` with `git diff --cached --name-status --no-renames`. This ZIP is a draft for review, not a repository modification.

This is **not** a request to diff-check or clear the separate P0 S4 candidate. The P0 S4 one-file variant is still pending its independent review.

## Edits, classified

- MUST M1: bare date, owner-identifying location removed.
- MUST M2: V1-V4 pointer moved to surviving K-03/K-04/K-10/K-11 authority and Claude role handover.
- SHOULD S1: install-true status/header/supersession wording.
- SHOULD S2: incorrect review-suffix parenthetical removed.
- SHOULD S3: `git diff --cached --check` expressly prohibited as STOP gate, with reason.
- SHOULD S4: preserve six-index local regressions, destructive TESTING BAT side effects, core.autocrlf and dual-hash representation, index `-text` proof, Release guard, AVX2 CPU condition.
- SHOULD S5: delivered Claude v0.10 recognised and its uncommitted status distinguished from repository v0.9.
- OPTIONAL O1: four abbreviated-history commits restored.
- Additional: verbatim shared continuity-purpose text restored, and changelog reflects revisions.

Do not install or commit until the owner accepts this corrected candidate and the diff-only review clears it.
