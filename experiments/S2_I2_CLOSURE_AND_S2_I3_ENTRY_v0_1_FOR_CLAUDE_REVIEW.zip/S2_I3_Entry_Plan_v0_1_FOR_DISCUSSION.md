# S2-I3 - Bounded Entry Plan (discussion proposal ONLY)

**Version:** 0.1
**Date:** 2026-10-16
**Status:** NOT AUTHORISED FOR IMPLEMENTATION; DRAFT FOR CLAUDE DISCUSSION AND PROJECT-OWNER DECISION.
**Owning authority:** `docs/REPOSITORY/Stage2_Experiment_Design_v0_6.md` (sections 3, 7-9, 13, 14, 19); `05_DECISIONS_v1_2.md`, particularly D-09, D-10, D-13, D-24, D-26. Claude's `Claude_S2_Seam_Pixel_Test_Options_Table_v0_2.md` is a research options catalogue, NOT a ratified technical authority. The new M4a suggestion is from `Claude_REVIEW_OF_ChatGPT_S2_I2_Implementation_v0_1_v0_1.md`.

## 1. Gate and objective

After the S2-I2 code is committed and acceptance evidence/authority state synchronised, separately ask the owner to authorise **S2-I3 only**. The S2-I3 deliverable is a **bounded initial luma kernel K0 and its frozen parameter set**, selected using a fixed clip-wide QP on LP's **even-numbered usable GOPs**. This enables an unbiased S2-I4 test of fixed QP versus real indexed per-MB QP on LP's untouched odd-numbered usable GOPs. S2-I3 should not use hold-outs or peek at S2-I4 comparison results.

This entry plan authorises **nothing** by itself. Do not write/run S2-I3 code, select K0, inspect hold-out filtering results or alter Stage 1 until separately authorised.

## 2. Invariants to lock before experiment code

- **Index-directed seam positions only.** The already validated S2-I1/S2-I2 reader/index supplies FRAME/FIELD/NONE and seam geometry. Pixels may judge a known seam but must not locate/rephase production seams independently.
- **Frame-owned, same-field-parity access** for interlaced horizontal boundaries. No interfield smoothing, no invented NONE internal coded transform seam.
- **LP as primary development material:** use original `LG_576i_3_LP` with accepted frozen index. LP_blocky may provide separately labelled non-gating diagnostic context only if the owner explicitly approves that **new** S2-I3 role; its S2-I2-only assignment must not be silently extended.
- **Even/odd GOP separation:** index GOPs in display order from first I picture (GOP 0), each run ending before the next I picture. Exclude the initial leading-B quality frames. Even usable GOPs 0,2,... are for S2-I3 K0 selection; odd GOPs 1,3,... are reserved for S2-I4 comparison. Precompute and save the exact frame/GOP selection in a read-only manifest before testing. Do not change the split on observing filtering results.
- **Fixed QP:** `Q_fixed = median indexed effective MB QP` for LP (ratified design gives 18). Use it uniformly for the initial candidate; only later S2-I4 introduces real per-MB QP while keeping K0 unchanged.
- **Initial metadata set:** use QP and transform state plus required picture/progressive/frame correspondence. Coding state/CBP are available in the index for diagnostics, but a **B1** coding-context boundary-strength control would consume more metadata for filtering than D-13 permits initially. It needs a separate explicit owner decision; default is **B0** (none).
- **Strength:** begin with one global manual strength (D-07). No automatic strength, no chroma, no motion-vector filtering, no external-filter yardstick, no Family B, no Family C blocking the primary path.
- **No Restricted Media in routine Git:** numerical/textual reports may be committed once reviewed; filters' images/visualisations are Restricted Media under `NOTICE.md`. Hold-outs stay locked until their authorised stage.

## 3. Algorithm research inventory (preserve rather than prematurely discard)

The following labels are carried from Claude's options table v0.2 into the *future S2-I3 design discussion*:

| Dimension | Candidate IDs | Treatment at entry |
|---|---|---|
| Seam-step features | M1, M2, M3, M4, M5 | Screen mathematically defined features on LP even GOPs; do not assert a winner from S2-I2 proxy results |
| Newly proposed feature | **M4a** (M4 numerator using adjacent slopes, denominator retaining the ratified in-block comparators) | Add to next *draft* options-table revision for owner/Claude review; preliminary LP 47.0% / AUC 0.812 versus ratified M4 23.79% / 0.754, but proxy labels do not equal visible-artifact truth |
| Side flatness/activity | F1, F2, F3 | Screen/report; select one/few for candidate shortlist |
| Decision family | R1, R2, R3, R4 | Consider, with H.264-style step/side-flatness gate as an initial practical hypothesis, not an adopted standard |
| Thresholds | T1, T2 | Prefer own QP-scaled curves (T1); H.264 alpha/beta (T2) starting points only, never blindly adopted |
| Real-edge protection | P0, P1, P2 | P1 continuity is first affordable add-on to test if needed; P2 only with demonstrated no-harm advantage |
| Kernel | K1, K2, K3, K4 | Begin with bounded short-support K1; K2/K3 conditional; K4 is optional Family C and must not delay K0 |
| Metadata use | B0, B1 | B0 initially; B1 requires explicit owner approval before use as a filtering input |
| Aggregate diagnostics | G1, G2 | Optional before/after reporting only, not per-seam choice/gating |
| Decision-only denoise | D0, D1 | D0 is default. D1 deferred unless evidence shows need; no predenoising merely to boost a metric |

**No option is silently deleted.** A review record must show each option's proposed evaluation status, reason for shortlisting/deferment, resource cost, and any needed owner decision. Do not implement the full Cartesian product of candidate combinations.

## 4. Proposed S2-I3 design and execution sequence (after separate authorisation)

**A. Lock the experiment contract before filter implementation.** Claude and ChatGPT cross-review the frame/GOP split, eligible seam classes, QP definition, parity-aware indexing, predeclared metrics/selection rules and artefact handling. Owner ratifies the bounded S2-I3 design. Identify how thresholds/strength are chosen without peeking at odd GOPs or hold-outs.

**B. Feature screen (read-only).** On original LP's even GOPs only, compute M1-M5 and proposed M4a, F1-F3 in **both orientations**. Report seam-vs-non-seam proxy hit rate at declared false-alarm settings and AUC, but also frame/GOP uncertainty, class, picture type, QP band, flatness/activity, and index-coded seam versus NONE-control distinctions. Existing S2-I2 CSV statistics are a starting point for definitions and debugging; do not use scores computed over reserved odd GOPs to select features. Declare weighting/populations to avoid segment-count pseudo-replication.

**C. Shortlist.** Select at most 2-3 *complete* candidate combinations of M/F/R/T/P/K/B/D with documented reasons, including a simple K1 baseline. Preserve rejected/deferred items in the options register. At this stage clarify whether a measure better separates indexed seams or simply reacts to textured VHS content.

**D. Initial bounded luma filtering.** Implement the selected combinations in a Python reference prototype, **fixed QP 18**, one manual strength, on *only* index-eligible seams. For each corrected seam: protect real edges, constrain strength by QP, clamp to sample bounds, avoid crossing other transform seams, and report changed samples inside/outside known seam supports. Frame-owned and parity-aware; chroma and NONE treatment policy are deferred to later increments. Any use of NONE boundaries must follow the ratified interim geometry/policy of the new S2-I3 design without inventing NONE internal seams.

**E. Evaluate and freeze K0.** Consider seam-local diagnostic improvement, false positives/no-harm near genuine edges, retained texture, frame/GOP uncertainty and the owner's visual assessment on *designated even-GOP development evidence only*. The owner chooses and ratifies one K0 kernel and precise threshold/strength/limiting parameters. Record complete source hashes, parameter manifest, fixed QP rule, selected frames/GOPs and review outcomes. If no suitable kernel, report inconclusive/failed feasibility honestly; do not choose a candidate merely because one metric improved.

**F. Stop at the S2-I3 gate.** No S2-I4 work until separately authorised. For S2-I4 only, compare fixed-vs-real per-MB QP on reserved **odd** GOPs with K0 *unchanged*, including separate boundaries touching NONE and high-QP disparity. S2-I5 later permits renewed real-QP development. S2-I8 is the previously owner-requested clean **all-16-source** census only after the final relevant kernel/threshold settings are frozen, with each source/index verified; the designated EP, original 2A/4A hold-outs remain shielded from earlier tuning.

## 5. S2-I3 entry readiness checklist

- [ ] S2-I2 accepted v0.1 implementation nine-file commit verified from pushed source tree.
- [ ] S2-I2 completion note / status synchronized through the normal review and owner-ratification route.
- [ ] Next versioned options register adds **M4a** without removing any v0.2 options; Claude reviews the exact definition and cost.
- [ ] Owner resolves whether S2-I3 will permit any LP_blocky role; default **NO**, as S2-I2-only is the last ratified assignment.
- [ ] Owner explicitly decides whether to consider B1 during S2-I3 or defer to S2-I5; default **B0** without change to D-13.
- [ ] S2-I3 detailed design states metric populations, frame/GOP segregation, objective and subjective evaluation, stopping rules, and immutable K0 freeze contract.
- [ ] Claude independently reviews the design against Stage 2 v0.6 and accepted implementation; owner ratifies the S2-I3 scope **before coding**.

## 6. Not in S2-I3

No code or results are supplied with this entry plan. Do not turn the design into authorisation to implement S2-I3, S2-I4 or later increments. No external yardstick, no hold-out review, no changed frozen indexes, no Stage 1 edits, no production plugin, no chroma filtering and no full all-16 filtering survey yet.
