# Claude Review Request - S2-I2 Closure / Exact Commit / S2-I3 Entry

**Version:** 0.1 (2026-10-16)
**Review status:** Proposed package, no live Git changes made by ChatGPT.

The owner has ratified S2-I2 COMPLETE/PASS, conditional on Claude's concurrence. Claude's independent S2-I2 Windows verification says the registration gate passed on LP and LP_blocky, so that condition is satisfied.

Review the three companion drafts against:

- `Claude_VERIFICATION_OF_S2_I2_Windows_Run_v0_1.md` and `Claude_REVIEW_OF_ChatGPT_S2_I2_Implementation_v0_1_v0_1.md`;
- both Windows `run_manifest.json` files and the eight numerical CSVs in the owner's evidence ZIP;
- ratified S2-I2 Design v0.4 and ratified Stage 2 v0.6;
- `05_DECISIONS_v1_2.md` D-13/D-23/D-24/D-26 and `NOTICE.md`;
- the nine **actual owner working-tree** implementation files, verifying the hash list in the commit proposal.

### Checks requested

1. Closure: does the note distinguish owner-ratified **gate** versus uncommitted **code**, stay within the evidence, preserve the exact test limitations and scope, and avoid accidentally declaring Stage 2 complete?
2. Provenance: independently verify all listed SHA-256 hashes and register/clip counts; distinguish original LP frozen baseline from LP_blocky scratch; confirm that the report has no embedded Restricted Media.
3. Commit: audit every named `git add` path, status/staged-scope check, EOL/working-byte integrity, Git attributes risk and expected nine-A entries; owner must not stage `experiments/` wholesale or commit this proposed report unintentionally.
4. Placement: recommend where to install the closure evidence and what future Project Status version/ratification procedure to use, respecting D-23. The nine-code-file commit is deliberately separate from status documentation.
5. S2-I3: check that the proposed entry contract accurately preserves the ratified even/odd LP GOP split, fixed median LP QP, K0 freeze, no hold-out leakage, no premature use of D-13-extra metadata, and separately authorised increments.
6. M4a: verify its definition is **not** misrepresented as the ratified M4. Recommend the minimal later options-table revision, not a silent replacement of v0.2.
7. Flag any new MUST/SHOULD/OPTIONAL findings. None of these drafts authorises S2-I3 implementation.

### Suggested owner sequence after Claude clearance

A. Claude clears exact named staging; owner confirms nine hashes/status and performs one code-only commit; Claude verifies pushed commit.

B. Claude reviews the closure note and status-update proposal; owner ratifies and installs them by a separate bounded document commit.

C. Owner explicitly decides whether to authorise **S2-I3 design only**, with requested choices about LP_blocky role and B1, then proceeds through the usual independent design review. No S2-I3 code until the separate authorisation and ratified design.
