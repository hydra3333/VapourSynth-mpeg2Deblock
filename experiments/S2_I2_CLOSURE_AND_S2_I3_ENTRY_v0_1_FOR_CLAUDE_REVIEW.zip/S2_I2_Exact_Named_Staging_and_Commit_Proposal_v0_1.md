# S2-I2 v0.1 - Exact Nine-File Named Staging and Commit Proposal

**Version:** 0.1 / 2026-10-16
**Status:** PROPOSED COMMANDS FOR CLAUDE AUDIT. NOT YET EXECUTED. This is not an executable BAT. The owner runs commands only after Claude reviews them.

## 1. Objective and baseline

Commit the nine S2-I2 v0.1 files **exactly as the owner ran them**, with no line-ending changes and no edits. Their hash identities are from the original reviewed candidate ZIP; Claude checked that the Windows execution matched this candidate for the engine/adapter. Reconfirm all nine working-tree hashes locally before staging. The last explicitly reported Project Status commit is `2286341`, **not** a claim about live HEAD. Inspect live status first.

**Never run `git add -A`, `git add experiments`, or `git add experiments/stage2`.** Leave all other untracked files, `REPO_OVERLAY/`, `research/`, review ZIPs, documents and `%TEMP%` scratch files out of this commit. All nine paths below were individually checked against the candidate overlay; no item is an accepted `.idx`.

## 2. Exact paths and expected SHA-256 (from reviewed ZIP)

| # | Repo-relative path | SHA-256 |
|---|---|---|
| 1 | `experiments/stage2/S2_I2_prepare_LP_blocky_index_v0_1.bat` | `7c1f0a3d6ad286048617cfa5ed04f396420896ef64af8d67cee34446431021b3` |
| 2 | `experiments/stage2/S2_I2_run_registration_v0_1.bat` | `4f1f18d496a54c420938e22e691d0bceef8ce5f6fb9945eed7b2b26d5b0707a4` |
| 3 | `experiments/stage2/stage2_check_result_v0_1.py` | `417a9d219811b9275651786c078e21465ff0859aac05cd3efe851e433d4d4817` |
| 4 | `experiments/stage2/stage2_ffmpeg_rehearsal_v0_1.py` | `1f35d9598f5967acb6af339fc1edcf926c1892a14aee4dd5f9f1dd0b5d73fa62` |
| 5 | `experiments/stage2/stage2_registration_clip_v0_1.vpy` | `8a85aadc85ce6941c3467d444a1cb80c6c775ba2674c857fc659d687ed9e1e6b` |
| 6 | `experiments/stage2/stage2_registration_stats_v0_1.py` | `2f640f17ad600c9866455d73db17142dea6bd7025cd1e99a5fcb28e4679beb1c` |
| 7 | `experiments/stage2/stage2_registration_tests_v0_1.py` | `a1fa72353485b9ec2ac7f3db6b6b1c4a4dd8f4e3b3d95083cb52892b68896af9` |
| 8 | `experiments/stage2/stage2_validate_lp_blocky_v0_1.py` | `bfe38b1dcdce78a5d8f95264208935ab435b7f5c5359455b7b76a9d5745eac6a` |
| 9 | `experiments/stage2/stage2_vspipe_env_preflight_v0_1.vpy` | `333f7db0b1b372e5b26871b66d7b5bd753597a32b4fc179d5e0a08672db4b505` |

Hash matching is an explicit go/no-go condition. If any mismatch, STOP and investigate (do not change files or normalise EOL to make the hashes match). The existing six frozen indexes and the non-baseline scratch LP_blocky index are never staged.

## 3. Windows CMD procedure - one command block at a time

Working directory:

```cmd
cd /d "E:\SOFTWARE-Win11\MULTIMEDIA\VapourSynth-mpeg2Deblock\VapourSynth-mpeg2Deblock"
```

Confirm the current branch, current commit and original working/staging state:

```cmd
git branch --show-current
```

```cmd
git log -1 --format="%H %s"
```

```cmd
git status --short
```

```cmd
git diff --cached --name-status --no-renames
```

**STOP** if any existing staged changes appear; reconcile them with Claude/owner before continuing. The code files must already be copied to `experiments/stage2` exactly as tested.

For each path, compute and compare SHA-256 to the table above. This syntax is a single-file command and does not modify it (repeat for every table entry, substituting the quoted path):

```cmd
certutil -hashfile "experiments\stage2\stage2_registration_stats_v0_1.py" SHA256
```

After verifying all nine hashes, execute these **nine separate named additions** (no wildcards):

```cmd
git add -- "experiments/stage2/S2_I2_prepare_LP_blocky_index_v0_1.bat"
```

```cmd
git add -- "experiments/stage2/S2_I2_run_registration_v0_1.bat"
```

```cmd
git add -- "experiments/stage2/stage2_check_result_v0_1.py"
```

```cmd
git add -- "experiments/stage2/stage2_ffmpeg_rehearsal_v0_1.py"
```

```cmd
git add -- "experiments/stage2/stage2_registration_clip_v0_1.vpy"
```

```cmd
git add -- "experiments/stage2/stage2_registration_stats_v0_1.py"
```

```cmd
git add -- "experiments/stage2/stage2_registration_tests_v0_1.py"
```

```cmd
git add -- "experiments/stage2/stage2_validate_lp_blocky_v0_1.py"
```

```cmd
git add -- "experiments/stage2/stage2_vspipe_env_preflight_v0_1.vpy"
```

Then inspect precisely what would be committed:

```cmd
git diff --cached --name-status --no-renames
```

Expected: exactly **nine entries, all status A**, exactly the names in section 2; none of the other untracked files. Any difference = STOP.

```cmd
git diff --cached --check
```

Expected: no output, exit code 0. A nonzero exit is a STOP; do not modify source bytes without a new reviewed and tested version. If any EOL rewriting occurs because of Git attributes, compare the staged blob hashes against the reviewed content **before committing**. Easiest safe route: Claude audit the repo's Git attributes and the nine `git hash-object` versus `git rev-parse :path` object IDs; both must agree for every staged file to ensure Git is storing exact working bytes. This is a check, not permission to loosen Git attributes silently.

Review the index and working-tree status:

```cmd
git status --short
```

Expected: the nine intended A entries, plus the unrelated untracked items still prefixed `??`. No frozen source/index modifications. Only after checking the staged scope and byte identity should the owner commit:

```cmd
git commit -m "Add accepted S2-I2 spatial registration diagnostics v0.1"
```

Then record the actual SHA and inspect the commit's paths:

```cmd
git log -1 --format="%H %s"
```

```cmd
git show --format= --name-status --no-renames HEAD
```

Expected exactly the nine additions. Push using the repository's normal approved process after reviewing the local result; `git push` is **not** silently combined with the commit commands in this proposal. Claude should verify the pushed commit's GitHub source ZIP afterward, checking these nine additions and frozen hashes.

## 4. Commit boundaries and housekeeping

- This first commit is **nine code files only**. It is not a bulk repository cleanup or review-document install.
- Keep the proposed S2-I2 results/gate report separate for Claude review/owner approval and installation; similarly prepare Project Status next version and remove its predecessor in that later controlled status commit (D-23).
- The untracked user documents, options-table revisions, review notes, nested overlays and package ZIPs remain untracked for now; owner separately decides which to keep, move, or delete. Do not remove any without the owner's direction.
- `VHSC_samples/*.idx` accepted baselines untouched; `%TEMP%/.../LP_blocky.idx` remains scratch/non-baseline; restricted media not staged.
- No S2-I3 work is included or authorised by this code commit.
