# SHA-256 manifest - S2-I2 Closure / Named Commit / S2-I3 Entry v0.1

**Scope:** review documents only; no software, .idx, logs, recordings or Restricted Media included.
**Line endings:** all new Markdown documents are US-ASCII CRLF.

- `S2_I2_Results_and_Closure_Note_v0_1_FOR_CLAUDE_REVIEW.md` : `5868a8d7506bc3a75cea9e48ae6607a6a38b37d316a864c94301b617a88b1828` (10443 bytes)
- `S2_I2_Exact_Named_Staging_and_Commit_Proposal_v0_1.md` : `0033e575d3d199e43fb26a82e534e7f3f212e41c785ae611567d11e68ed3011f` (6953 bytes)
- `S2_I3_Entry_Plan_v0_1_FOR_DISCUSSION.md` : `fbcb51c3a8179dd117bebdb0d0bb83770407926eed30c9d0d35295f07cd2e880` (9837 bytes)
- `CLAUDE_REVIEW_REQUEST_S2_I2_CLOSURE_AND_S2_I3_ENTRY_v0_1.md` : `1b334a7c17351de3bc011b73d760831440119e4d3969fa7ce39c06f61394e790` (2913 bytes)
