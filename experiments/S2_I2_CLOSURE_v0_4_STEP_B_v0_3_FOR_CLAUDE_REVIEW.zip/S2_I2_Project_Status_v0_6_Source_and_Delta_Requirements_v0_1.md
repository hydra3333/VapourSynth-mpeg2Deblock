# Project Status v0.6 - Source Identity and Drafting Requirements

**Date:** 2026-10-16
**Status:** NOT a status-v0.6 draft; prerequisite and delta inventory only.

Claude confirms the authoritative ratified `docs/REPOSITORY/00_PROJECT_STATUS_v0_5.md` at code commit `190bd06` has:

- Git/GitHub LF SHA-256 `ee0d41eafeac06abfffeae457b410e301ad65ce9743b7378fb784be897eb9131`.
- Windows working-copy CRLF SHA-256 `a5f19fa8c9dfd83b8d701b4e327f48555be613f75558938f328e6c53f61881da`.

A previous local `00_PROJECT_STATUS_v0_5.md` in this workspace does **not** have either verified SHA-256, and is an unratified prior draft. It **must not** be used to create v0.6. The correct file is needed as owner attachment or exact SHA-verified repository source. Do not treat this note as a substitute.

## Changes to make, minimally, from exact ratified v0.5

1. Supersede status v0.5 by v0.6 under `docs/REPOSITORY/`, maintaining existing technical authorities and historical sections unchanged unless superseded by verified new facts.
2. Record S2-I2 **COMPLETE / WINDOWS ACCEPTANCE PASS / OWNER RATIFIED 2026-10-16**, with LP primary and LP_blocky S2-I2-only control, all three registration tests PASS, seven known-bad offsets caught on both, 202/204 eligible frames.
3. Record v0.1 code commit `190bd06ded88130ffddac7bb9adde4175d82f9f8`, parent `2286341`, nine added files; Claude verified GitHub archives and six immutable .idx files.
4. Record row-phase test extension plus known limits (spatial grid checks do not guarantee arbitrary temporal identity or detect field swap; picture type provides limited separate temporal check). Numerical evidence from Step B must remain non-media; LP_blocky index remains untracked scratch only.
5. Record proposed permanent gate report at `docs/REPOSITORY/S2_I2_Evidence_and_Gate_Report_v0_1.md`, and Step-B numerical evidence subtree once installed.
6. Under D-23, if ratified, record the **narrow** historical/verbatim non-ASCII exception for the two named Copilot text records and the scoped evidence `-text` pin. Never imply the decisions have been taken before they are.
7. State S2-I3 **NOT AUTHORISED**; Stage 2 Experiment Design v0.6 remains ratified/unchanged; owner-requested all-16-source census at S2-I8 awaits the next substantive Stage2 text revision.
8. Preserve D-23 version replacement, root Git history provenance, prior conclusions and references. Remove v0.5 from the same bounded document commit installing v0.6, after owner ratification.

Claude should review the eventual full draft against the exact ratified v0.5 source. No step-B command or commit before then.
