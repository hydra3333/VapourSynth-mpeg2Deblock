# Claude - Review Request: S2-I2 Closure v0.4 / Step B v0.3

**Date:** 2026-10-16
**Status:** FOR INDEPENDENT REVIEW; no Windows commands authorised in this packet.

## Source basis

- Claude `Claude_REVIEW_OF_ChatGPT_S2_I2_Closure_v0_3_and_Step_B_v0_2_v0_2.md`: M1, S1-S3, O1-O2, Copilot scan.
- Ratified S2-I2 design v0.4; owner Windows results and corrected Claude Windows verification v0.2.
- Accepted code commit `190bd06ded88130ffddac7bb9adde4175d82f9f8` already pushed and independently verified; NOT to be restaged.
- Original owner ZIP SHA-256 `0bce902275a2e7533fb0685788bcbf3ef2c0a173b344866ed4a0f757d02c34d6`; still only under the owner's `experiments/stage2/Z/` (no owner extraction or on-disk hash verification yet).

## Review targets

1. Verify closure v0.4 and inventory v0.3 **do not assert** evidence has been unpacked; source is Z ZIP only, with Step-B extraction, exclusion of nonbaseline `.idx` and 25 pre-staging size/hash checks.
2. Verify code commit DONE, temporal and field-order limits, unchanged registration thresholds and samples. No Stage1/Stage2 changes.
3. Verify only `.gitattributes` gets a blocking `git diff --cached --check -- .gitattributes`; evidence/doc whitespace warnings are informational; hash checks are integrity gates.
4. Verify the proposed owner D-23 waiver is narrowly limited to the two verbatim historical UTF-8 records (ChatGPT Copilot/Grok review and COPILOT source); Claude's completed NOTICE/identity clearance is not owner waiver.
5. Verify the source ZIP SHA, all 25 listed sizes/hashes, 12 document paths/hashes (Claude review section 5), target path, named-staging count 40 A / 1 M / 1 D only conditional on both waiver and pin, and continued exclusions of Z/ and process files.
6. Verify the evidence `-text` rule must be appended to working-tree `.gitattributes` and checked with `git check-attr` before any evidence `git add`.
7. **Project Status v0.6:** full draft is pending the verified ratified source v0.5; DO NOT approve a v0.6 reconstructed from the older unratified local draft. The attached requirements note specifies exact evidence needed and changes. Prior ratified source Git LF hash is `ee0d41ea...9131`. Once the owner provides matching bytes, ChatGPT produces a full v0.6 for review.

**Requested disposition:** review these v0.4/v0.3 drafts now; withhold final Step-B command block until Project Status v0.6 and owner waivers/pin decisions have been reviewed and ratified. No owner commands requested at this stage.
