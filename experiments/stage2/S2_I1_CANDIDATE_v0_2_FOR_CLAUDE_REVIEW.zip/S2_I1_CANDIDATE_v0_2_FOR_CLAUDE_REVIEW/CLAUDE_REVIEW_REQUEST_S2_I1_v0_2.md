# Claude Review Request - S2-I1 Candidate v0.2

**Date:** 2026-10-14
**Baseline:** repository HEAD `c45dcf0923cbbbe335266d2c4302327f16ab94fe`
**Scope:** S2-I1 only. S2-I2 remains NOT AUTHORISED.

## Reason for v0.2

Owner Windows execution of v0.1 exposed a BAT-only defect before index generation completed:
the ffmpeg and inspector processes on the same pipeline both attempted to append to the same log,
causing Windows CMD to report `The process cannot access the file because it is being used by another process.`

Rather than patch that pipeline, v0.2 adopts Claude S1: ffmpeg writes a scratch `.m2v`, then the frozen
inspector reads the regular file. This also removes the frozen `Fill_Buffer()` short-pipe-read hazard
from this generation procedure. The inspector itself remains frozen and unchanged.

## v0.2 files

- `experiments/stage2/stage2_index_reader_v0_2.py`
- `experiments/stage2/stage2_index_reader_regression_v0_2.py`
- `experiments/stage2/stage2_validate_bestsource_v0_2.vpy`
- `experiments/stage2/S2_I1_generate_4A_blocky_candidate_v0_2.bat`
- `experiments/stage2/S2_I1_validate_all_accepted_pairs_v0_2.bat`

The v0.1 files are uncommitted owner-working files only. If v0.2 is accepted, v0.1 should be removed
locally before the first S2-I1 commit so only the accepted version enters Git.

## Claude v0.1 review findings incorporated

### S1
- BAT comments record the frozen inspector `Fill_Buffer()` short-read trap.
- generation is now `ffmpeg -> scratch .m2v -> frozen inspector -b file`, never stdin piping.
- v0.1 concurrent logfile writers are eliminated.

### S2
`validate-4a-blocky` now checks every Stage 1 Gate Report section 8.1 value available from the index:
- records 300;
- dimensions/grid 720x576 / 45x36;
- I/P/B 26/75/199;
- FRAME/FIELD/NONE 56235/35243/394522;
- INTER/INTRA/SKIPPED 316290/46078/123632;
- q_scale_type 0 = 300;
- QP 62 = 486000;
- mixed FRAME/FIELD frames = 300;
- macroblock Q updates = 0;
- dct_type bits read = 91478;
- custom matrices all absent;
- picture_structure FRAME = 300;
- frame_pred_frame_dct 0 = 300.

`progressive_frame=0 x300` and no leading-B exclusion are separately labelled additional S2-I1
assertions, not section 8.1 rows.

The generation BAT computes `certutil` SHA-256, prints it, logs it, and requires exact match to:
`57f3b60d1ea2108f29f222c7c658cb1ddc9eb26c14071cb056112a2f3b296e73`.
This remains a non-baseline candidate identity.

### S3
A new read-only BAT runs the BestSource `.vpy` correspondence check against all six accepted
`.mpg`/`.idx` pairs. The 4A-blocky generation BAT separately checks the generated seventh candidate.

### O1
Reader comments explicitly state that `ceil(h/16)` is the progressive-sequence height formula,
interlaced MPEG-2 is `2*ceil(h/32)`, and they coincide for current 576/288 material. The check is
labelled a current-domain gate rather than a general MPEG-2 rule.

### O2
BAT comment now says frozen analyzer `--expected-frames` is report-only and does not establish the
exit code; the Stage 2 reader enforces the 300-record count.

### O3
`leading_b_ordinals` is computed once at index load and cached in the immutable `Stage1Index` object.

## ChatGPT execution evidence

On the actual six accepted indexes from the `c45dcf0` source ZIP:
- `python stage2_index_reader_regression_v0_2.py`: PASS for all six baseline hashes and all original
  negative tests.
- Python compilation: PASS.

Using a gcc build of the frozen inspector sources and the new regular-file path:
- ffmpeg created scratch MPEG-2 ES from `TEST_4A_A003_blocky.mpg`;
- inspector generated candidate index;
- SHA-256 exactly `57f3b60d1ea2108f29f222c7c658cb1ddc9eb26c14071cb056112a2f3b296e73`;
- v0.2 `validate-4a-blocky`: PASS;
- expanded summary showed every new expected row exactly as listed above.

No VapourSynth/BestSource execution was available in ChatGPT's Linux runtime. Claude should review /
rehearse the two BAT paths and, where possible, the actual BestSource runner before owner execution.

## Requested review

Please determine whether v0.2 is safe for owner execution and remains strictly S2-I1. In particular:
1. confirm the file-based inspector invocation preserves the accepted Stage 1 semantics;
2. confirm the expanded 8.1 computations and labels are correct;
3. confirm all-six BestSource runner pairs the intended six accepted `.mpg`/`.idx` files;
4. confirm no accepted `.idx` can be written or regenerated;
5. confirm 4A-blocky stays scratch-only, non-baseline and uncommitted;
6. inspect Windows CMD quoting/errorlevel/logging/hash verification for defects;
7. identify any MUST before owner run and any SHOULD before commit.

Please execute/rehearse as much as your environment permits. Do not authorise S2-I2.
