# Claude Review Request - Stage 2 S2-I1 Candidate v0.1

**Date:** 2026-10-14
**Repository source ZIP used by ChatGPT:** GitHub `main` archive comment `c45dcf0923cbbbe335266d2c4302327f16ab94fe`
**Owner decision:** technical development restart is now expressly AUTHORISED, beginning with S2-I1 only.
**Status:** REVIEW CANDIDATE ONLY. Do not treat this package as owner-approved for commit or execution merely because it exists.

## 1. Ratified scope being implemented

Stage 2 v0.6 section 19 defines S2-I1 as:

- read-only Stage 1 index reader / validation;
- reproduce analyzer v0.2 summary totals for each formal/accepted clip;
- if absent/untracked, generate + validate `TEST_4A_A003_blocky.idx` as a non-baseline candidate;
- `progressive_frame` and picture-type handling;
- leading-B quality-exclusion accounting.

Stage 2 v0.6 section 6.1 additionally requires cheap temporal/structural checks before filtering:

- index records == BestSource frames;
- dimensions match;
- record ordinals match;
- field pictures rejected for the current experiment;
- Stage 2 reader reproduces frozen analyzer v0.2 record/state/QP totals.

No S2-I2 seam-map/registration work, filtering, tuning, visual evidence generation or hold-out quality work is included here.

## 2. Candidate repository additions

The `REPO_OVERLAY/` subtree contains only:

- `experiments/stage2/stage2_index_reader_v0_1.py`
- `experiments/stage2/stage2_index_reader_regression_v0_1.py`
- `experiments/stage2/stage2_validate_bestsource_v0_1.vpy`
- `experiments/stage2/S2_I1_generate_4A_blocky_candidate_v0_1.bat`

All are project-authored US-ASCII CRLF in this delivery.

## 3. Design of the reader

`stage2_index_reader_v0_1.py` is intentionally independent of `Stage1_Inspector_Analyzer_v0_2.py`.
It does not import or call the analyzer. It:

- reads the frozen Stage 1 v1 32-byte file header, 64-byte record header and 8-byte MB payload;
- enforces the Stage 1 structural/semantic checks used by frozen analyzer v0.2;
- hard-aborts on malformed input;
- adds current Stage 2 domain gates: I/P/B only, frame pictures only, native 4:2:0, boolean picture flags, stable positive dimensions/MB grid;
- exposes per-picture `progressive_frame` and picture type;
- counts only B pictures output before the first I picture as excluded from quality evidence;
- reports record count, transform totals, coding totals and effective-QP histogram;
- provides `validate_clip_metadata()` for BestSource frame-count/dimension/picture-type correspondence;
- provides `validate-4a-blocky` against the exact Stage 1 report v0.3 section 8.1 totals.

Please specifically review whether any Stage 2 domain gate is too strong or not justified by v0.6.

## 4. Regression harness

`stage2_index_reader_regression_v0_1.py` checks all six immutable accepted Stage 1 indexes.
It first verifies each accepted SHA-256, then checks the independent reader against frozen analyzer-v0.2 summary values for record count, picture-type totals, `progressive_frame` totals, FRAME/FIELD/NONE totals, the full effective-QP histogram, and leading-B exclusion ordinals.

It also proves rejection of bad file magic, incomplete files, a wrong first record ordinal and field-picture structure.

ChatGPT executed this harness against the source ZIP. `S2_I1_LOCAL_TEST_EVIDENCE_v0_1.txt` contains the exact output.

## 5. BestSource validation

`stage2_validate_bestsource_v0_1.vpy` is a generic VapourSynth R81 / BestSource validator. It requires `--arg src=<source.mpg> --arg idx=<matching.idx>`. It loads the new reader, opens the source with BestSource, obtains every `_PictType`, and hard-fails if frame count, dimensions or any picture type differs. It reports the index `progressive_frame` distribution and leading-B quality-exclusion count. It returns the original clip unchanged as the VapourSynth output.

ChatGPT syntax-compiled this script but could not execute it because the current environment does not provide the owner's Windows VapourSynth/BestSource installation.

## 6. 4A-blocky generation harness

`S2_I1_generate_4A_blocky_candidate_v0_1.bat` is intentionally scratch-only. The default scratch location is `%TEMP%\VapourSynth-mpeg2Deblock_S2_I1`, overridable with `S2_I1_SCRATCH`.

It reads the tracked `VHSC_samples\TEST_4A_A003_blocky.mpg`, uses the existing Release `Mpeg2BlockInspector.exe`, validates the generated candidate with the new Stage 2 reader and frozen analyzer, then runs the generic BestSource correspondence script. It finally records `git status --short`.

It must not write, regenerate or replace any of the six accepted `.idx` baselines. The generated 4A-blocky candidate remains non-baseline and uncommitted unless the owner later makes a separate decision.

ChatGPT could not execute the BAT because the required Windows inspector build, ffmpeg path and VapourSynth R81 runtime are not present in this environment. Please rehearse/execute what you can before the owner runs it, consistent with the standing workflow.

## 7. Review questions

Please report MUST / SHOULD / OPTIONAL findings and explicitly assess:

1. Is this still strictly S2-I1, with no S2-I2 leakage?
2. Does the independent reader preserve or strengthen all relevant frozen analyzer-v0.2 validation rather than weaken it?
3. Are the Stage 2-specific hard gates (I/P/B, frame picture, 4:2:0, stable dimensions) justified by the ratified current experiment scope?
4. Is leading-B exclusion implemented exactly as "B pictures output before the first I picture"?
5. Do the six baseline regression expectations correctly reflect the frozen analyzer and immutable hashes?
6. Is `TEST_4A_A003_blocky` validation exactly consistent with Stage 1 report v0.3 section 8.1 and clearly non-baseline?
7. Is the BestSource validator sufficient for the S2-I1 count/dimension/picture-type correspondence gate?
8. Is the scratch generation BAT safe for the owner to run after review, particularly with respect to tracked baselines and repository cleanliness?
9. Are any additional S2-I1 tests required before the owner runs the Windows-only portion?

Do not authorise S2-I2. S2-I2 begins only after S2-I1 execution results have been reviewed and the owner separately allows advancement.
